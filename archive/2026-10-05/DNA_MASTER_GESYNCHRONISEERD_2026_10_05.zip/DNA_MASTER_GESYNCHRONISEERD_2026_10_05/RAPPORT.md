# Master 1.9 — Jaarboeken gesynchroniseerd

De lokale Masterversie van 10 september 2026 is bijgewerkt in een nieuwe versie van 5 oktober 2026. Het oorspronkelijke bestand blijft behouden als historische bron. De nieuwe versie bevat **3618 unieke opnamen**, inclusief alle **1120 huidige Jaarboekposities**.

- In de eerste synchronisatieronde zijn 137 ontbrekende opnamen toegevoegd: 24 nieuwe vervangers en 113 bestaande Jaarboekselecties.
- Alle 1120 actuele Jaarboekplaatsingen geregistreerd in DNA Playlist(s), DNA Gebruikt en DNA Aantal toepassingen; exacte posities en bronnen in Jaarboeken 1970-2025.
- Alle 3480 oorspronkelijke opnamen en hun andere geregistreerde toepassingen behouden. Geen oude track uit de Master verwijderd.
- De bron bevatte nog geen Jaarboektoepassingen. Oude Jaarboekplaatsingen zijn daarom niet in die bron teruggevonden en niet ten onrechte van andere playlists afgetrokken. De herstelhistorie blijft de referentie voor de 109 vervallen plaatsingen.
- Geen ontbrekende Jaarboek-URI’s en geen dubbele Master-URI’s na synchronisatie.

## Reikwijdte

Dit is de bijgewerkte lokale Masterwerkmap, plus CSV/JSON. Er is geen online database gepubliceerd of gewijzigd. De andere playlisttoepassingen zijn uit de bestaande Master behouden; die playlists zijn niet opnieuw live gecontroleerd. De oude overzichts- en auditbladen behouden hun oorspronkelijke peildatum; de nieuwe synchronisatie geeft de actuele telling.

Voor de 137 toegevoegde records zijn identiteit, URI, Jaarboekbronjaar en gebruik ingevuld. Ontbrekende albumgegevens, audiofeatures, landen en taxonomie zijn niet verzonnen; deze velden blijven leeg of expliciet nog te verrijken. Toevoegen aan de Master betekent dus niet dat de volledige metadata al verrijkt is.

Bij **8 bestaande opnamen** verschilt het Master-werkjaar van het Jaarboekbronjaar. Het bestaande werkjaar is behouden en het Jaarboekjaar staat in het aparte register. WERKJAARVERSCHILLEN geeft deze gevallen; een remaster- of compilatiedatum kan de oorzaak zijn. Dit is nog geen zelfstandig geverifieerde foutlijst.

## Bestanden

De Excelwerkmap is de nieuwe lokale Masterversie. MASTER_ACTUEEL.csv en JSON bevatten de volledige bijgewerkte Playlist-tabel; JAARBOEKREGISTER legt plaatsingen vast; TOEGEVOEGDE_137_OPNAMEN en GEBRUIKSWIJZIGINGEN vormen het wijzigingslog. CONTROLE bevat de bronsignatuur en tellingen.

## Aanvullende correctie na gebruikerscontrole

Neil Young, Jaarboek 1989 positie 13: Paris 1989 vervangen door Freedom (1989). Eén nieuwe versie aan de Master toegevoegd: nu **3618 unieke opnamen**. De oude URI blijft in de Master, zonder Jaarboektoepassing; de nieuwe URI heeft de toepassing DNA JAARBOEK 1989. Het eerste synchronisatielog met 137 toevoegingen blijft historisch intact; het aparte beschikbaarheidslog legt de 138e toevoeging sinds de bron vast. De oude audiofeatures zijn niet naar de andere versie overgenomen.
