# Nacontrole credits en Flow-DNA — 5 oktober 2026

De 109 historische reparaties blijven afgerond. Deze nacontrole geeft geen onderbouwde aanleiding voor extra trackvervangingen of een nieuwe volgorde. In deze ronde is Spotify niet gewijzigd.

## Overgangen

Van de 720 tracks in 36 aangepaste Jaarboeken zijn 621 op exacte URI gekoppeld aan de oorspronkelijke Masterexport met audiofeatures (2 oktober 2026); 99 hebben daar geen match. Van 684 overgangen zijn 531 vergelijkbaar op energie, loudness en acousticness. 67 krijgen luisteraandacht, waarvan 16 grenzen aan een vervanger.

Drempels: energieverschil ≥0,35; loudnessverschil ≥7 dB; acousticnessverschil ≥0,65. Eén overschrijding geeft een signaal. Dit zijn geen bewezen fouten. Rustige of filmische slotnummers kunnen bewust veel contrast geven. Tempo is niet gebruikt vanwege mogelijke halve/dubbele tempo-inschattingen. Afspeelnormalisatie en de hoorbare overgang zijn hiermee niet getoetst.

LUISTERAANDACHT.csv staat aflopend op contrastscore (energie + loudness/25 + acousticness). Dit is uitsluitend een praktische luistervolgorde. Eerst de overgangen rondom vervangers beoordelen, daarna overige signalen en overgangen zonder metadata. Er is geen volledige luistertest uitgevoerd; de huidige volgorde blijft daarom intact.

## Credits

- **1979, positie 20 — Sharon / Cheryl White:** Volledige namen Sharon White en Cheryl White ondersteund door Apple Music. Bestaande naamresolutie behouden. [Bron](https://music.apple.com/us/song/5560391).
- **1979, positie 18 — 吉沢典夫 / Norio Yoshizawa:** Shazam noemt Norio Yoshizawa recording engineer bij Rydeen. Bron betreft compilatie YMO Go Home!, geen bevestiging van de exacte Spotify-master. Japanse broncredit blijft conservatief meegeteld; geen botsing. [Bron](https://www.shazam.com/song/1462847479/rydeen).
- **2010, positie 16 — Michael Kiske & Amanda Somerville:** Officiële fanclub bevestigt zelfstandig duetproject Kiske/Somerville en debuut uit 2010. Eén projectcredit blijft behouden, conform afzonderlijke projectenregel. [Bron](https://kiskefanclub.com/bands/kiske-somerville/).
- **2020, positie 1 — Nick Perri & The Underground Thieves:** Bandpersbericht beschrijft band en debuut Sun Via met Feeling Good in 2020. Projectcredit behouden. [Bron](https://sropr.com/press-releases/nick-perri-the-underground-thieves-team-up-with-gibson-and-sweetwater-sound-to-give-away-100000-free-digital-copies-of-their-debut-album-sun-via-band-shares-new-single-an/).

Overige beperkingen: producenten/technici die in de bronartiestkolom staan blijven conservatief in het register. De controle omvat de vastgelegde artiestcredits, niet iedere componist of medewerker in volledige albumcredits. Niet iedere identiteit is bevestigd met een Spotify-artiest-ID. De bronjaarcontrole is geen onafhankelijke verificatie van alle oorspronkelijke uitgavedata.

## Status

1120 tracks, 1120 unieke Spotify-URI’s; geen herhaalde geregistreerde creditkeys of overlaps tussen de drie gecontroleerde perioden. Geen nieuwe herstelposities. Geen handelingen van de gebruiker nodig om deze nacontrole te verwerken.

## Bijgewerkt na beschikbaarheidsherstel

De gebruikerscontrole leidde tot één correctie buiten de metadata-Flowronde: Jaarboek 1989 positie 13 gebruikt nu de Freedom-versie. De bovenstaande metadata-tellingen zijn opnieuw berekend met die URI. De nieuwe versie heeft geen audiofeatures in de historische Masterexport; beide omliggende overgangen blijven luisteraandacht zonder numeriek oordeel.
