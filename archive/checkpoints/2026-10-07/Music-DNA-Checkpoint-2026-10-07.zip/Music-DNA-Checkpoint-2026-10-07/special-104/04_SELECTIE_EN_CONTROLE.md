# DNA SPECIAL 104 — De glitter bleef

Complete importklare selectie, 6 oktober 2026. Nog niet gepubliceerd.

**15/15 uit eigen ongebruikte Mastervoorraad.** Elf Zweedse en vier Noorse acts, vijftien unieke URI’s en vijftien verschillende gecrediteerde Spotify-artiestentiteiten. Totale duur op bestaande Mastermilliseconden: **56:21**. Geen externe opnamen nodig. Map: **02 Landen, steden & scenes**.

## De meerwaarde van het label

Een route over het voortleven van glam/sleaze in Zweden en Noorwegen. De twee oudere hardrockankers vormen een kader rond latere bands en terugkerende muzikanten. Dit is een selectie over continuïteit en hernieuwde energie; geen volledige nationale geschiedenis. Noorwegen en Zweden zijn de concrete landen, dus de titel claimt niet Finland, Denemarken of heel Scandinavië te vertegenwoordigen.

De bandverbinding tussen Zan Clan en Laney’s Legion is gedocumenteerd in het [Chris Laney-interview](https://callesrockcorner.dk/chris-laney). Het [labelpersbericht over Bulletrain](https://www.melodicrock.com/articles/news-feed/2016/08/16/bulletrain-deliver-what-you-fear-most-aor-heaven) plaatst de band in de Zweedse sleaze-generatie. Dit ondersteunt het redactionele verhaal; het bewijst geen directe afstamming van iedere act in de lijst.

## Selectie

| # | Artiest | Track | Land | Spotify-weergave |
|---|---|---|---|---|
| 1 | Swedish Erotica | [Rock'n'Roll City](https://open.spotify.com/track/7HKkpIjafs6ufCZlXJgvAj) | Zweden | 4:24 |
| 2 | Zan Clan | [Go Go Go](https://open.spotify.com/track/6vPsyfpxShe0Sa2ltKhzFm) | Zweden | 3:28 |
| 3 | Babylon Bombs | [Hometown Hero](https://open.spotify.com/track/5TqQnYIyisbHJiHXzkSK9u) | Zweden | 3:13 |
| 4 | Hell N' Diesel | [Miss Cocaine](https://open.spotify.com/track/3pIYR84epkcf0zCfIMGipV) | Zweden | 3:38 |
| 5 | Loud 'N' Nasty | [Stand Strong](https://open.spotify.com/track/4KOCQK92cOw8Pvx9haAa6p) | Zweden | 3:08 |
| 6 | Bulletrain | [Memory Lane](https://open.spotify.com/track/3B1GcV5ViFxTMpX6bGcPnD) | Zweden | 4:19 |
| 7 | Baby Jane | [My Behavior](https://open.spotify.com/track/1IJtqhXB7xi9IXqOmG7DLd) | Zweden | 3:36 |
| 8 | Gasoline Queen | [Broke, Cursed and Damned](https://open.spotify.com/track/09qJb7SQ5grUFEn58NawLo) | Zweden | 5:02 |
| 9 | Sweet Creature | [This Town Is Dead](https://open.spotify.com/track/0fSeONddkwt7Vb3zvuj4Fw) | Zweden | 2:50 |
| 10 | Laney's Legion | [Taste of Your Tongue](https://open.spotify.com/track/5XK4P3zE7DYnnwZUsBILMU) | Zweden | 3:27 |
| 11 | Billion Dollar Babies | [In the Back of My Limousine](https://open.spotify.com/track/3GdTrTfB4iHhVCSP5QKKTM) | Zweden | 3:01 |
| 12 | NiteRain | [Lost and Wasted](https://open.spotify.com/track/7HgInZAuyMC2h5oIEkvEa8) | Noorwegen | 2:58 |
| 13 | Suicide Bombers | [So Bad](https://open.spotify.com/track/5drLgudNh1wkMD3kvtUyiq) | Noorwegen | 4:02 |
| 14 | Wildnite | [I'll Be There](https://open.spotify.com/track/7sUYjUNdts2w5bGSrtm2Sd) | Noorwegen | 4:02 |
| 15 | Sons Of Angels | [Spend the Night](https://open.spotify.com/track/4sbhYTms1UZc3tLJOmiWP6) | Noorwegen | 5:05 |

## Flow

Swedish Erotica geeft een uitnodigende, melodieuze opening. Zan Clan, Babylon Bombs en Hell N’ Diesel brengen vervolgens meer vaart en scherpe randen. Loud ’N’ Nasty en Bulletrain houden de druk vast. Baby Jane leidt naar de langere, minder energierijke Gasoline Queen-opname en de donkere titel van Sweet Creature. Laney’s Legion en Billion Dollar Babies zetten melodie en groove weer voorop. NiteRain en Suicide Bombers bouwen naar de laatste piek; Wildnite en Sons Of Angels geven een ruimer slot.

Dit is een redactionele volgorde, geholpen door historische Mastermetadata voor tempo en energie. Tempo’s kunnen dubbel of half worden geïnterpreteerd. Overgangen en klankbalans zijn niet volledig luisterend getest.

## Controle en registratie

Alle vijftien individuele Spotify-pagina’s teruggelezen op 6 oktober: titel, artiest en album kloppen, afspeelknop zichtbaar, geen expliciete beschikbaarheidsmelding aangetroffen. Een openbare pagina is geen bewijs van volledige account- of marktgebonden afspeelbaarheid. De regionale luistercontrole volgt na import.

CSV: drie importer-kolommen, UTF-8 met BOM, vijftien rijen in dezelfde volgorde als SELECTIE.json. Geen herhaalde URI of gecrediteerde Spotify-artiest binnen de selectie. Geen gevonden URI-/artiestoverlap met de beschikbare bronnen voor Specials 01–100, 102 en 103; alle geselecteerde URI’s staan nog ongebruikt in de actuele Master. Bekende bron/liveverschillen in oudere Specials maken dit geen totale nieuwe live-audit.

Mastergebruik blijft onveranderd totdat deze playlist is gepubliceerd en teruggelezen. De vijftien gebruiksregistraties zijn voorbereid in 08_MASTER_REGISTRATIE_VOORBEREID.json. De actuele Master blijft versie 1.13, met 2.595 gebruikte en 1.051 ongebruikte opnamen. Geen Spotify-playlist gemaakt en geen W41-wijzigingen uitgevoerd.

## Naam- en jaarcontrole

- Baby Jane is de Zweedse band van In the Spotlight, niet de Australische naamgenoot.
- Billion Dollar Babies is hier de Zweedse band van House of Dreams Pt.1; niet Alice Coopers album of de gelijknamige historische Amerikaanse groep.
- Sons Of Angels is de Noorse band met het album uit 1990; niet de latere act die Crush 40 werd.
- Sweet Creature is de act achter This Town Is Dead en Martin Sweet; niet de Amerikaanse naamgenoot.
- Zan Clan: Spotify toont 2006; de [labelaankondiging uit 2005](https://sleazeroxx.com/news-segment-1240/) en de [recensie](https://sleazeroxx.com/reviews/zan-clan-we-are-zan-clan-who-the-fk-are-you/) dateren de oorspronkelijke albumuitgave op 2005. Het geselecteerde catalogusrecord blijft behouden. Geen stilzwijgende Mastercorrectie.
- Gasoline Queen: Spotify/Master toont 2008; reviews uit 2009 zijn geen zelfstandig bewijs dat het opnamejaar 2009 is.
- Jester en Fat Nelly zijn uit de brede scan weggelaten vanwege gemengde genrelabels die op metadata- of artiestverwarring kunnen wijzen. De twaalf overige niet-geselecteerde kandidaten blijven reserve; filterlabels alleen bepalen geen inhoudelijke geschiktheid.

## Bronnen per act

- **Swedish Erotica** — [SVT: Göteborgse band en debuut uit 1989](https://www.svt.se/nyheter/lokalt/blekinge/swedish-eroticas-ovantade-aterforening-pa-sweden-rock-35-ar-efter-debutskivan?lokalmeny=1).
- **Zan Clan** — [Interview Chris Laney: Zweedse bandverbinding](https://sleazeroxx.com/interviews/chris-laney-interview-2/).
- **Babylon Bombs** — [Labelprofiel Victor: Stockholm en latere sleaze-generatie](https://www.jvcmusic.co.jp/-/Profile/A020434.html).
- **Hell N' Diesel** — [Albumrecensie: Zweedse hardrock/glam en geselecteerde song](https://www.auxportesdumetal.com/reviews/HellNDiesel/passionforpower.html).
- **Loud 'N' Nasty** — [Bandherkomst en comeback in 2019](https://www.hardrockinfo.com/reviews/2019/4.html).
- **Bulletrain** — [AOR Heaven-persbericht: Zweedse sleaze, album en Memory Lane](https://www.melodicrock.com/articles/news-feed/2016/08/16/bulletrain-deliver-what-you-fear-most-aor-heaven).
- **Baby Jane** — [Zweedse Baby Jane, Göteborg; onderscheid met Australische naamgenoot](https://sleazeroxx.com/reviews/baby-jane-in-the-spotlight/).
- **Gasoline Queen** — [Zweedse band, EP en Broke, Cursed & Damned](https://m.callesrockcorner.dk/?id=256570).
- **Sweet Creature** — [Project van Crashdïet-gitarist Martin Sweet, single 2022](https://sleazeroxx.com/sweet-creature-feat-crashdiet-guitarist-martin-sweet-drop-video-for-new-single-this-town-is-dead/).
- **Laney's Legion** — [Interview Chris Laney: eigen Zweedse band; releasebron](https://callesrockcorner.dk/chris-laney).
- **Billion Dollar Babies** — [Zweedse band, House Of Dreams Pt.1 en gekozen song](https://zeromagazine.nu/2012/07/26/billion-dollar-babies-house-of-dreams-pt-1/).
- **NiteRain** — [Interview bij albumrelease in Oslo; Lost And Wasted genoemd](https://eternal-terror.com/2016/11/10/niterain-vendetta/).
- **Suicide Bombers** — [Release-informatie: hardrockband uit Oslo, Murder Couture](https://tigernet.no/releases/204797-murder-couture).
- **Wildnite** — [Officiële bandpagina: Noorse rock, debuut 2018 en songvideo](https://wildnite.no/).
- **Sons Of Angels** — [Contemporaine CMJ-recensie uit 1990: Noorse band en Spend The Night](https://www.worldradiohistory.com/Archive-All-Music/CMJ/1990/CMJ-New-Music-Report-1990-06-08.pdf).

Metadata- en schermbewijs staat in SPOTIFY_CONTROLE.json; de exacte tracklinks staan boven en in SELECTIE.json. Deze checkpoint is lokaal, niet naar GitHub gepubliceerd.
