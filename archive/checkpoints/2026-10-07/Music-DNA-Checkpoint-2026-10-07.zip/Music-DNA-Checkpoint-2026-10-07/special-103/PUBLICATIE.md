# DNA Special 103 — Japan Achter de glitter

Checkpoint van 6 oktober 2026. [Gepubliceerde playlist](https://open.spotify.com/playlist/4H87qrtFacCoWXMzo1UJ2e).

De vijftien live Spotify-URI’s en de volgorde zijn teruggelezen. Hoes en beschrijving zijn gepubliceerd. Positie 2 is **SHOW-YA;Namie Amuro — 限界LOVERS**, van PROGRESS, URI `spotify:track:2l7RWhzDfU9yV8ZKXqg1gj`. De gebruiker heeft deze opname afspelend bevestigd. De oude Outerlimits-URI is vervallen; ook de eerder voorgestelde solo-opname 限界LOVERS 2015 is geen onderdeel van deze publicatie. Het bestand DEFINITIEF_IMPORTER.csv volgt exact de gepubliceerde lijst. Oudere CSV’s zijn historische bouwversies en moeten niet opnieuw worden geïmporteerd.

Master 1.13 bevat 3.646 unieke opnamen: 2.595 gebruikt (71.17%) en 1.051 ongebruikt. Dertien nieuwe records toegevoegd; EZO en BUCK-TICK als bestaande records nu gebruikt geregistreerd. Zestien gecrediteerde Spotify-artiestentiteiten voor vijftien tracks; de samenwerking heeft twee credits. hide with Spread Beaver is de ene gecrediteerde Spotify-entiteit die live wordt getoond. Onbekende audio-eigenschappen en exacte milliseconden zijn leeg gelaten. Nieuwe genreclassificaties en oorspronkelijke opnamejaren staan expliciet open voor controle. Bestaande waarden buiten zes gebruikscellen, alle formules en gecontroleerde werkmapstructuur zijn behouden.

**Nog open:** verplaatsen naar ✦ DNA Specials → 02 Landen, steden & scenes. De desktopbediening reageert niet betrouwbaar op het mapmenu en geeft bij coördinatenbediening geen beschikbaar venster. De verplaatsing is niet bevestigd en niet als voltooid geregistreerd. De playlist hoeft niet opnieuw geïmporteerd te worden.

Geen volledige luisterproef van alle vijftien tracks uitgevoerd. Flow is redactioneel. W41 is ongemoeid gelaten. Deze checkpoint is lokaal opgeslagen; geen GitHub-publicatie uitgevoerd. De eerdere achterstand van 230 Specials-opnamen blijft een afzonderlijke taak.
