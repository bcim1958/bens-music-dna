# DNA Jaarboeken 1970–2025 — herstel afgerond

Op 5 oktober 2026 zijn alle **109 vastgestelde historische herstelposities** uitgevoerd in de bestaande Spotify-playlists. Het gaat om 36 gewijzigde jaarboeken. Per gewijzigd jaar zijn de twintig tracks, hun volgorde en de opgeslagen beschrijving gecontroleerd. Alle eerste behouden vermeldingen uit de oorspronkelijke herstelkaart zijn nog aanwezig. Titels, hoezen en mapstructuur zijn behouden. Jaarboeken zonder herstelpositie zijn niet gewijzigd.

## Eindtelling

- 56 jaarboeken × 20 tracks = 1120 tracks.
- 1120 unieke Spotify-URI’s in de bijgewerkte canon.
- 1163 geregistreerde gecrediteerde artiestkeys; geen herhaalde key.
- Geen interne artiest- of URI-dubbels per jaar.
- Geen artiestcredit- of URI-overlap tussen 1970–2010, 2011–2019 en 2020–2025.
- 109 reparaties uitgevoerd; nul vastgestelde historische herstelposities open.

| Periode | Tracks | Reparaties uitgevoerd | Open |
|---|---:|---:|---:|
| 1970–1979 | 200 | 38 | 0 |
| 1980–1989 | 200 | 43 | 0 |
| 1990–1999 | 200 | 13 | 0 |
| 2000–2009 | 200 | 14 | 0 |
| 2010–2019 | 200 | 1 | 0 |
| 2020–2025 | 120 | 0 | 0 |

## Herstelkaart en terugvindbaarheid

HERSTELHISTORIE_109_POSITIES.csv en JSON leggen voor iedere oorspronkelijke herstelpositie vast: de oude track en URI, reden, eerste behouden vermelding, de huidige positie van die behouden track, vervanger en nieuwe positie, jaaronderbouwing en bronlink. OPEN_HERSTELKAART.csv bevat alleen kolomkoppen; de JSON bevestigt dat de vastgestelde kaart leeg is. CANONIEK_1970_2025 bevat alle 1120 huidige posities.

De uitvoeringsregistratie betreft daadwerkelijk gecontroleerde wijzigingen in Spotify. De volledige reekscontrole gebruikt het bijgewerkte bronregister. De twintig jaarboeken zonder historische herstelpositie zijn deze ronde niet opnieuw integraal live geëxporteerd.

## Jaar-fit, credits en resterende kwaliteitscontrole

Alle geregistreerde bronjaren passen bij hun jaarboek. Vervangers hebben aanvullende jaaronderbouwing; remasters bepalen niet het oorspronkelijke jaar. Dit is geen onafhankelijke releasedatumverificatie van alle 1120 opnamen. Covers tellen als de betreffende uitvoerders en hun eigen uitgavejaar: Angtoria/Confide in Me (2006) en Taking Dawn/The Chain (2010) zijn afzonderlijke opnamen van de oorspronkelijke versies. Bij Taking Dawn is het albumjaar 2010 gebruikt; een fonogramcopyright 2009 is niet de albumreleasedatum.

Iedere geregistreerde uitvoerende artiest maximaal eenmaal; bands en soloprojecten zijn afzonderlijk. De aanvullende Spotify-artiestenvermeldingen Gene Paul, Jackson Howe, Geoffrey Haslam en David Cole zijn meegenomen. Emerson, Lake & Palmer en Michael Kiske & Amanda Somerville blijven als hun afzonderlijke band/projectcredits geregistreerd; ampersands worden niet blind gesplitst.

Naam- en creditpunten blijven zichtbaar voor verdere kwaliteitscontrole: de afgekorte Sharon bij Emmylou Harris is als Sharon White opgelost; de exacte identiteit en rol blijven een aandachtspunt. 吉沢典夫 bij Yellow Magic Orchestra is conservatief meegeteld met een Unicode-key; de uitvoerende of technische rol vraagt nadere broncontrole. Samengestelde projectcredits en onbekende aliassen zijn niet allemaal met artiest-ID bevestigd. In 2004 toont Spotify Rhapsody waar het bronregister Rhapsody Of Fire vermeldt; dit is als naamvariant vastgelegd, zonder extra herstelpositie. [Historische aankondiging van de naamswijziging](https://blabbermouth.net/news/rhapsody-change-name-to-rhapsody-of-fire).

Het Spotify-creditscherm noemt ook componisten, producenten en technici. De telling hierboven is geen volledige inventarisatie van deze rollen en geen garantie dat onbekende credits of aliassen ontbreken.

Flow-DNA is redactioneel toegepast op de gewijzigde jaarboeken. Een volledige luistertest is nog niet uitgevoerd. De vastgestelde herstelopdracht is voltooid; een eventuele volgende kwaliteitsronde betreft luisteren naar de overgangen en nader onderzoeken van de gemarkeerde creditidentiteiten.

## Aanvullend beschikbaarheidsherstel — 5 oktober 2026

1989, positie 13: de grijze Neil Young-opname van Paris 1989 is vervangen door de elektrische Freedom-albumversie (1989), URI 4Y7fEQ4PAzhlLnLviRw2P4. Twintig tracks en dezelfde volgorde bevestigd. Visueel beschikbaar; geen volledige afspeeltest. Dit komt naast de 109 historische artiestreparaties.
