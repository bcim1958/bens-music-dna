# De riff verhuist — gepubliceerd op 5 oktober 2026

[Open in Spotify](https://open.spotify.com/playlist/75qxBf9faBTNNy2pJ7yDSD).

Vijftien tracks, vijftien verschillende Spotify-artiestennamen en vijftien unieke URI’s. Speelduur ongeveer 79 minuten. Titel, beschrijving, hoes en volgorde zijn zichtbaar op de openbare Spotify-pagina. De playlist is geplaatst in **07 Grenzen & verrassingen**, die nu tien playlists telt.

Unida’s Black Woman - Original bleek in het account grijs. Die versie is verwijderd en vervangen door **Left Us To Mold** op positie 7. De definitieve volgorde is ook in de openbare Spotify-embed gecontroleerd. De laatste visuele desktopcontrole toont geen grijze opnamen in het gecontroleerde gedeelte; een volledige afspeeltest is niet uitgevoerd. Flow-DNA blijft redactioneel en is niet volledig beluisterd.

Alle vijftien nieuwe opnamen staan in lokale **Master 1.11** en zijn als gebruikt geregistreerd. Excel en JSON zijn gecontroleerd op overeenstemming en behoud van de bestaande gegevens. De geregistreerde Master bevat nu 3.633 opnamen: 2.565 gebruikt (70,60%) en 1.068 ongebruikt. De 230 eerdere ontbrekende Specials-opnamen blijven een aparte registratieachterstand.

Drie historische jaarvragen blijven open: Slo Burn, Unida’s compilatieversie en Fatso Jetson. Genreclassificatie en exacte releasedata blijven leeg waar brongegevens ontbreken. Daarnaast is een bronverschil vastgelegd: Special 65 heet live Los Angeles, terwijl het bronbestand Liverpool vermeldde. Liverpool staat live als Bonus Special 01.

De volledige trackselectie met bronnen staat in SELECTIE.json en SPECIAL.md. SPOTIFY_URI_VOLGORDE.txt bevat de definitieve URI-volgorde. SPOTIFY_WEB_PUBLICATIE.jpg toont de openbare publicatie; SPOTIFY_PUBLICATIE.png toont de desktoptracklijst na herstel.
