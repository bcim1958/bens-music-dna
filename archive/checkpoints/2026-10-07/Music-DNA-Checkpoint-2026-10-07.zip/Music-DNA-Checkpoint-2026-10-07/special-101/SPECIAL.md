# DNA Special — De riff verhuist

**Van Birmingham naar de Californische woestijn — en terug over de oceaan.**

Gepubliceerde selectie: 15 tracks, 15 verschillende gecrediteerde artiestennamen, 79:14 minuten. Plaatsing: **07 Grenzen & verrassingen**, omdat de kruisverbinding tussen scènes het onderwerp vormt. Een volgnummer is nog niet toegekend.

## Museumtekst

Een riff kan gewicht dragen, een groove openen en ruimte laten ontstaan. Deze route begint bij Black Sabbath en andere bands uit de West Midlands. Daarna volgt ze de Californische woestijnmuziek en de muzikanten die vanuit Kyuss nieuwe projecten begonnen. Ook Fatso Jetson en Yawning Man krijgen hun eigen plaats in het verhaal. Het slot brengt beide kanten van de oceaan samen: Yawning Sons verbindt de Britse Sons of Alpha Centauri met Gary Arce van Yawning Man. De vraag onderweg: wat blijft herkenbaar wanneer muzikanten een zware gitaartraditie naar hun eigen hand zetten?

## Gepubliceerde volgorde

| # | Artiest | Opname | Duur |
|---|---|---|---|
| 1 | Black Sabbath | [Into The Void](https://open.spotify.com/track/1E42I7BdibCf24ybzdUqxu) | 6:11 |
| 2 | Quartz | [Mainline Riders](https://open.spotify.com/track/7Afp9oJJok7HrqvRL3dTO2) | 3:36 |
| 3 | Witchfinder General | [Invisible Hate](https://open.spotify.com/track/4bQwGeIESs43pfKlsHgGbb) | 6:06 |
| 4 | Cathedral | [Ride](https://open.spotify.com/track/5kQf33aiP0YoVyrHJj8Xee) | 4:47 |
| 5 | Kyuss | [Gardenia](https://open.spotify.com/track/0StO1AR9wWQ5SmGPKklV5u) | 6:53 |
| 6 | Slo Burn | [Pilot The Dune](https://open.spotify.com/track/4vO1sKO8mFdQlysel6Xu3w) | 3:28 |
| 7 | Unida | [Left Us To Mold](https://open.spotify.com/track/48RCrsAtJ9HIKu95EwWoOt) | 5:46 |
| 8 | Queens of the Stone Age | [Regular John](https://open.spotify.com/track/0R0m9mTXa81zp1qtcU3dSR) | 4:37 |
| 9 | Fatso Jetson | [Light Yourself on Fire](https://open.spotify.com/track/4yaZrlO0Nh9MAau4TR2CiK) | 5:01 |
| 10 | Brant Bjork | [Low Desert Punk](https://open.spotify.com/track/0FzTGDCZ71TH2j71xNOOOM) | 5:21 |
| 11 | Desert Sessions | [Holey Dime](https://open.spotify.com/track/06pSSubbmrYxJ9kYbE6plR) | 3:33 |
| 12 | Big Scenic Nowhere | [The Glim](https://open.spotify.com/track/6IdRK0d7r5sioHaaBlwtGz) | 5:04 |
| 13 | John Garcia | [Kylie](https://open.spotify.com/track/6C0ijNw1VmKe5ki3cRoLMq) | 4:58 |
| 14 | Yawning Man | [Rock Formations](https://open.spotify.com/track/0EAwKFwPX0JMI5QxuKxteG) | 5:21 |
| 15 | Yawning Sons | [Ghostship - Deadwater](https://open.spotify.com/track/1parbqGqH4stiBCL02HSSX) | 8:32 |

## Opbouw

**1–4: het Britse vertrekpunt.** Birmingham, Stourbridge en Coventry laten verschillende takken uit de West Midlands zien. Cathedral is een latere ontwikkeling, geen voorouder van Kyuss. De volgorde pretendeert geen rechte historische afstamming.

**5–9: de Californische vertakkingen.** Kyuss staat naast Slo Burn, Unida, Queens of the Stone Age en Fatso Jetson. De personele verbinding via John Garcia is door diens label beschreven. Fatso Jetson vertegenwoordigt een eigen lokale route.

**10–15: de ruimte voor uitwisseling.** Soloprojecten en samenwerkingen voeren naar Yawning Man en Yawning Sons. Dat Yawning Man hier later staat, weerspiegelt de luisteropbouw; de band speelde al vóór de release van Rock Formations in 2005.

## Controle en registratie

[Open deze Special in Spotify](https://open.spotify.com/playlist/75qxBf9faBTNNy2pJ7yDSD). Titel, beschrijving, hoes en vijftien tracks zijn gepubliceerd. De map 07 Grenzen & verrassingen telt nu tien playlists. De onbeschikbare Black Woman-compilatieversie is verwijderd en vervangen door Left Us To Mold van Unida op positie 7.

Vijftien unieke URI’s en vijftien verschillende Spotify-artiestennamen. Alle vijftien songs zijn als nieuwe records toegevoegd aan Master 1.11 en als gebruikt geregistreerd. Bestaande Masterrecords blijven ongewijzigd. De openbare Spotify-embed toont de volledige definitieve volgorde. Geen volledige afspeeltest uitgevoerd. De volgorde blijft redactioneel en is niet luisterend getest.

De vijftien URI’s zijn vergeleken met de eerdere Master en de gecontroleerde Specials-bronnen. Dit is geen volledige live-audit van alle bestaande Spotify-playlists. Bij Special 65 is een bronverschil gevonden: Spotify noemt Los Angeles, terwijl het bronbestand Liverpool noemde. Liverpool staat live als Bonus Special 01. Dat verschil vraagt apart administratief herstel.

## Versies en jaren die aandacht vragen

Spotify toont bij Slo Burn 1996, terwijl de EP doorgaans met 1997 wordt verbonden. Bij Unida is de geselecteerde versie een compilatie uit 2005. Yawning Sons heeft een geselecteerde release met jaarweergave 2014, terwijl de eigen albumcredits de oorspronkelijke uitgave op 26 september 2009 dateren. Fatso Jetson toont op Spotify 2002 en de eigen Bandcamp-releasepagina vermeldt een andere datum. Die jaren zijn bewust opgeslagen als Spotify-jaarweergave, niet als bewezen oorspronkelijke releasejaren. Definitieve historische jaarvelden blijven open tot aanvullende broncontrole.

## Bronnen voor de verbindingen

- [Tony Iommi’s eigen biografie](https://www.iommi.com/biography/) ondersteunt de Birmingham-wortel.
- [Interview met Quartz-muzikant Geoff Nicholls](https://axe-crazy.blogspot.com/2022/04/quartz-back-in-band.html) beschrijft het lokale netwerk en Iommi’s werk aan het debuut.
- [Cathedral](https://cathedral-band.bandcamp.com/) vermeldt Coventry; [AllMusic’s plaatsregister](https://www.allmusic.com/birthplace/stourbridge-west-midlands-england-mz0000436886) vermeldt Witchfinder General bij Stourbridge.
- [John Garcia’s labelprofiel](https://label.napalmrecords.com/john-garcia) verbindt Kyuss, Slo Burn en Unida.
- [Fatso Jetsons eigen uitgavepagina](https://fatsojetson.bandcamp.com/album/fatso-jetson-yawning-man-split) beschrijft de oorsprong in Palm Desert.
- [Brant Bjork](https://brantbjork.bandcamp.com/track/low-desert-punk-2) vermeldt Palm Desert op zijn artiestenprofiel.
- [Ripple Music over Yawning Man](https://ripplemusic.bandcamp.com/album/rock-formations) beschrijft de lokale oorsprong en de invloed op Kyuss.
- [Big Scenic Nowhere](https://bigscenicnowhere.bandcamp.com/) beschrijft de verbinding tussen Yawning Man en Fu Manchu.
- [Yawning Sons](https://yawningsons.bandcamp.com/) beschrijft de samenwerking; Gary Arce en de Britse muzikanten zijn uitgewerkt in de [albumcredits](https://yawningsons.bandcamp.com/album/ceremony-to-the-sunset).
- [Josh Homme over Desert Sessions](https://www.nme.com/music-interviews/desert-sessions-vol-11-12-josh-homme-talks-new-record-track-track-2574343) beschrijft de werkwijze en opnamen in Rancho de la Luna.

De genoemde verbanden tonen lokale netwerken en personele verbindingen. Een specifieke hoorbare overeenkomst tussen twee geselecteerde songs blijft een redactionele luistervraag, geen bewezen directe beïnvloeding.
