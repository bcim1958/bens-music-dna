# DNA SPECIAL — Glam: de vergeten zijstraten

Publieke playlist: https://open.spotify.com/playlist/0IE8ZTGYFRb3Cot8HbONwW

15 tracks, 58:20. Alle vijftien Spotify-tracklinks en de volledige volgorde zijn rechtstreeks op de openbare pagina gecontroleerd. Geen dubbele trackinvoegingen. Geen overlap met de live Sunset Strip-Special 65. Alle vijftien waren in Master 1.11 als ongebruikt geregistreerd. De bredere broncatalogus heeft bekende verschillen met Spotify; andere live Specials zijn niet volledig opnieuw gecontroleerd.

De invalshoek: vijftien cultbands achter de grote glamnamen, met straatrock, blues, melodieuze hardrock en metal. De volgorde is redactioneel opgebouwd; geen volledige luisterproef uitgevoerd. Bronjaren zijn overgenomen uit de Master en niet allemaal historisch opnieuw geverifieerd.

## Master

Versie 1.12 bevat 3.633 records: 2.580 gebruikt (71,02%), 1.053 ongebruikt. Vijftien bestaande records zijn bijgewerkt in drie gebruikskolommen. De opgeslagen Excelwaarden stemmen overeen met de JSON; uitsluitend de 45 bedoelde cellen veranderden. Formules, tabbladnamen en gecontroleerde tabellen, validaties, samengevoegde cellen, tekeningen en beveiliging zijn behouden. Zie EXCEL_CONTROLE.json in de Mastermap.

## Nog af te ronden

- HOES.png is gereed, maar nog niet naar Spotify geüpload; Spotify toont de standaard albumcollage.
- Verplaatsing naar 07 Grenzen & verrassingen is niet bevestigd; playlist staat nog op bibliotheekniveau.
- De tijdens de bediening ontstane lege proefplaylist “Mijn playlist 358” moet nog worden verwijderd (https://open.spotify.com/playlist/5OtHp1ibHq2tmMduGMWfHG).

Spotify geeft herhaaldelijk ongeldige bedieningselementen en vertraagde focus/schermstatus terug. Daarom zijn deze drie handelingen niet als voltooid geboekt. Publicatie en Masterregistratie zijn wel onafhankelijk geverifieerd.

Bewijs: SPOTIFY_PUBLICATIE.jpg en SPOTIFY_PUBLIEKE_LINKS.json. De bekende achterstand van 230 andere Specials-opnamen valt buiten deze registratie.
