# Depot — aanvullende playlist-exports veranderen de proefcollectie

Stand 7 oktober 2026. De eerdere inventarisatie doorzocht de Codex-werkmappen. De uitgebreidere zoekslag omvat ook Music DNA-bestanden op het bureaublad, downloads en bestaande Spotify-bronexports. De eerdere conclusie van 148 voorlopige kandidaten was daardoor onvolledig.

**94 genreopnamen krijgen aanvullend geregistreerd gebruik:** 84 uit de VE-kandidaten, acht uit de positieve stroomgevallen en Jester plus Dirty White Boy. De exacte URI’s staan in bestaande DNA-playlist-exports onder Desktop/Mappen/spotify_playlists-2. Eén aanvullende aangrenzende opname, BUCK-TICK — JUST ONE MORE KISS, heeft ook exportbewijs voor Music DNA · Proefcadeau.

De nieuwe stand is **409 Geëxposeerd en 65 Onverkend** binnen de 474 genreopnamen. De voorlopige VE-werkvoorraad telt **64**. De oorspronkelijke Master blijft ongewijzigd, maar 117 van zijn 182 ongebruikt gemarkeerde genreopnamen hebben nu aanvullend gebruiksbewijs.

## Bewijsmethode

- 517 aanvullende CSV-bestanden uitgelezen; gekoppeld op exacte Spotify-URI, niet alleen titel of artiestnaam.
- DNA-playlist-exports leveren gebruiksregistratie, met bronregel, bestandsvingerafdruk en oorspronkelijke Added At-waarde. Er is geen nieuwe livecontrole van deze historische playlists uitgevoerd.
- Toevoegdatums zijn playlistvelden, geen bewezen exportdatum, FIFO-toetredingsdatum of weekafhandeling.
- Importers, voorgenomen Specials en algemene bronplaylists zijn apart vastgelegd; zij krijgen niet automatisch dezelfde bewijskracht.
- De twee aanvankelijk niet leesbare CSV’s zijn alsnog met expliciete scheiding uitgelezen; ze bevatten geen exacte Depotmatches. Bronbestanden zijn niet gewijzigd.

## Alle uit Onverkend verwijderde genreopnamen

| Artiest | Opname | Album | Vorige werkvoorraad | Exportbewijs |
|---|---|---|---|---|
| 17  Crash | Through Hell and Back | Through Hell and Back | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 25 |
| 1st Avenue | Never Too Late To Live | Tears & Triumph | Voorlopige VE-kandidaat | After_Hair_Metal_DNA.csv; CSV-regel 10 |
| Airkraft | Heaven | In The Red | Voorlopige VE-kandidaat | Too_Late_For_The_Hair_Metal_Party_DNA.csv; CSV-regel 14 |
| All or Nothing | The Big Deal | AON | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 27 |
| Angelica | Time And Time Again | Walkin' In Faith (Remastered) | Voorlopige VE-kandidaat | Too_Late_For_The_Hair_Metal_Party_DNA.csv; CSV-regel 3 |
| Atomic Riot | Dance with the Devil | Atomic Riot | Positieve stroom; actuele FIFO-positie open | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 29 |
| Bad Boy Eddy | Rad Ruby | Over the Top (Deluxe Edition) | Voorlopige VE-kandidaat | Hair_Metal_Gekkies_DNA.csv; CSV-regel 28 |
| Banshee | Shoot Down The Night | Race Against Time | Positieve stroom; actuele FIFO-positie open | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 26 |
| Beau Nasty | Goodbye Rosie | Dirty, But Well Dressed | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 6 |
| Beautiful Creatures | 1 A.M. | Beautiful Creatures | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 2 |
| Big Cock | Bump and Grind | Motherload | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 8 |
| Brides Of Destruction | Shut the Fuck Up | Here Come the Brides | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 3 |
| Catalano | Set This City on Fire | Nightfighter | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 26 |
| CHINA | In The Middle Of The Night | Sign In The Sky | Positieve stroom; actuele FIFO-positie open | Hair_Metal_Gekkies_DNA.csv; CSV-regel 19 |
| Cobra | Blood On Your Money | First Strike | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 4 |
| Crystavox | Power Games | Crystavox | Voorlopige VE-kandidaat | Too_Late_For_The_Hair_Metal_Party_DNA.csv; CSV-regel 4 |
| Cycle Sluts From Hell | I Wish You Were a Beer | Cycle Sluts From Hell | Voorlopige VE-kandidaat | After_Hair_Metal_DNA.csv; CSV-regel 29 |
| Dextress | Wild Is the Night | Dextress | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 20 |
| Diamond Lane | The Enemy | Terrorizer | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 16 |
| Diamond Rexx | Land Of The Damned | Land of the Damned | Positieve stroom; actuele FIFO-positie open | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 10 |
| Dirty Penny | Midnight Ride | Take it Sleezy | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 6 |
| Dirty White Boy | Let's Spend Momma's Money | Bad Reputation | Identiteit/stijl onderzoeken | Too_Late_For_The_Hair_Metal_Party_DNA.csv; CSV-regel 5 |
| Dream Police | Rock Me | Dream Police | Voorlopige VE-kandidaat | Scandinavian_Hair_Metal_DNA.csv; CSV-regel 11 |
| Erotic Psycho | Sex Me Up | Sex You Up! | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 17 |
| Eyes | Young And Innocent | Eyes | Positieve stroom; actuele FIFO-positie open | Too_Late_For_The_Hair_Metal_Party_DNA.csv; CSV-regel 7 |
| Femme Fatale | My Baby's Gun | Virgines Metallium: A Tribute to the New Maidens of Metal | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 7 |
| Foxy Venus | Thirsty for Love | Thirsty for Love | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 21 |
| Hawk | Tell the Truth | Hawk | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 20 |
| Heavy Pettin | Sole Survivor | Rock Ain’t Dead | Positieve stroom; actuele FIFO-positie open | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 16 |
| Hollywood Rose | Killing Time | 100 Hair Metal Anthems | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 5 |
| Holy Soldier | Stranger | Holy Soldier | Voorlopige VE-kandidaat | Too_Late_For_The_Hair_Metal_Party_DNA.csv; CSV-regel 10 |
| Jackyl | The Lumberjack | Jackyl 25 | Voorlopige VE-kandidaat | Too_Late_For_The_Hair_Metal_Party_DNA.csv; CSV-regel 16 |
| Jester | Digitalia | Digitalia | Identiteit/stijl onderzoeken | After_Hair_Metal_DNA.csv; CSV-regel 19 |
| Kick Axe | Heavy Metal Shuffle | Vices | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 11 |
| Kidd Skruff | Honky Tonk Woman | Angels With Dirty Faces | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 14 |
| Knock Out Kaine | House of Sins | House of Sins | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 15 |
| Laci Violett | Snakebite | Laci Violett | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 25 |
| Lizzy Borden | Me Against the World | Visual Lies (Remastered) | Voorlopige VE-kandidaat | WASP_Band_DNA_.csv; CSV-regel 3 |
| London | Russian Winter | Playa Del Rock | Voorlopige VE-kandidaat | Hair_Metal_Gekkies_DNA.csv; CSV-regel 14 |
| Lord Tracy | Jinx | Porn Again | Voorlopige VE-kandidaat | Hair_Metal_Gekkies_DNA.csv; CSV-regel 25 |
| Lostboys | Lost And Found | Lost And Found | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 8 |
| Löve Razër | First Class Bitch | Rock 'N' Roll Addiction | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 18 |
| Mad Margritt | Loaded Gun | Animal | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 7 |
| MASI | God Promised a Paradise | Downtown Dreamers | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 28 |
| Midnight Sin | Midnight Revolution | Sex First | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 16 |
| NITE | Nite F'king Riders | 2nd Extended | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 29 |
| Nitro | Freight Train | O.F.R. | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 31 |
| No Exqze | We Won't Wait 'Till Saturday | Too Hard To Handle | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 29 |
| Odin | Judgement Day | Caution! | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 6 |
| Pussy Sisster | Here Are the Pussys | Here Are the Pussys | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 19 |
| Rakel Traxx | S.E.X | Bitches Palace | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 11 |
| Rebelstar | The Heat Is On | Take a Hit | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 26 |
| Rock City Angels | Tear It Up | Midnight Confessions | Voorlopige VE-kandidaat | Hair_Metal_Gekkies_DNA.csv; CSV-regel 22 |
| Rock Soldiers | Never Givin’ Up | Never Givin’ Up | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 15 |
| Roko | One Night Stand | Roko | Positieve stroom; actuele FIFO-positie open | Hair_Metal_Gekkies_DNA.csv; CSV-regel 18 |
| Rox Diamond | Heart of Mine | Rox Diamond | Positieve stroom; actuele FIFO-positie open | Hair_Metal_Gekkies_DNA.csv; CSV-regel 24 |
| Roxxi | Playin' Rough | Drive It to Ya Hard | Voorlopige VE-kandidaat | After_Hair_Metal_DNA.csv; CSV-regel 30 |
| Scandal Circus | In the Name of Rock N´ Roll | In the Name of Rock N´ Roll | Voorlopige VE-kandidaat | Scandinavian_Hair_Metal_DNA.csv; CSV-regel 18 |
| Shake City | Hot Love | Shake City | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 2 |
| Sisters Doll | All Dolled Up | All Dolled Up | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 22 |
| Skull Daze | Dirty Girl | Skull Daze | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 10 |
| Slik Toxik | Twenty Something | Irrelevant | Voorlopige VE-kandidaat | Hair_Metal_Gekkies_DNA.csv; CSV-regel 16 |
| Speed Stroke | Demon Alcohol | Fury | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 19 |
| Spiders & Snakes | California Slide | Arachnomania | Voorlopige VE-kandidaat | Hair_Metal_Gekkies_DNA.csv; CSV-regel 23 |
| STEELHEART | Everybody Loves Eileen | Steelheart | Voorlopige VE-kandidaat | Hair_Metal_DNA.csv; CSV-regel 19 |
| Steevi Jaimz | Cat On A Hot Tin Roof | Glam Damnation | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 11 |
| Stranger | Let Me Rock-N-Roll | No More Dirty Deals | Voorlopige VE-kandidaat | Too_Late_For_The_Hair_Metal_Party_DNA.csv; CSV-regel 15 |
| Stryper | Calling on You | ONE Christian Music's #1 Charting Rock Hits V1 | Voorlopige VE-kandidaat | Hair_Metal_DNA.csv; CSV-regel 15 |
| Strÿkenine | Inside | Inside | Voorlopige VE-kandidaat | Scandinavian_Hair_Metal_DNA.csv; CSV-regel 31 |
| Surgin' | Shot Through the Heart | When Midnight Comes | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 17 |
| Sven Gali | Tie Dyed Skies | Sven Gali | Voorlopige VE-kandidaat | After_Hair_Metal_DNA.csv; CSV-regel 6 |
| Sweet F.A. | Hard Drivin' Man | The Lost Tapes | Voorlopige VE-kandidaat | Hair_Metal_Gekkies_DNA.csv; CSV-regel 17 |
| Tales From The Porn | Back to the 80's | H. M. M. V | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 18 |
| Tattoo Rodeo | Shotgun Johnny | Rode Hard - Put Away Wet | Voorlopige VE-kandidaat | Hair_Metal_Gekkies_DNA.csv; CSV-regel 31 |
| The Bang Gang | Pedal to the Metal | Love Sells | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 31 |
| The Cherry Bombz | Hot Girls | The Cherry Bombz - Deluxe Version | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 4 |
| The Nästy | Expect No Mercy | Expect No Mercy | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 20 |
| The Quireboys | Sex Party | A Bit Of What You Fancy | Voorlopige VE-kandidaat | Too_Late_For_The_Hair_Metal_Party_DNA.csv; CSV-regel 13 |
| Tigertailz | Love Bomb Baby | Bezerk | Voorlopige VE-kandidaat | Hair_Metal_DNA.csv; CSV-regel 25 |
| Tindrum | Drums of War | Drums of War | Voorlopige VE-kandidaat | Scandinavian_Hair_Metal_DNA.csv; CSV-regel 5 |
| TKO | Below the Belt | Below the Belt | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 21 |
| Triumph | Follow Your Heart | Thunder Seven | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 15 |
| Trixter | One in a Million | Alive in Japan | Voorlopige VE-kandidaat | Hair_Metal_DNA.csv; CSV-regel 24 |
| Tryx | She's so Fine | Don't You Need It | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 22 |
| Tuff Luck | Tonight Tonight | Tuff Luck | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 25 |
| Union | Love (I Don't Need It Anymore) | Union | Voorlopige VE-kandidaat | After_Hair_Metal_DNA.csv; CSV-regel 16 |
| Vain Vipers | Bitch Please (Shut Up) | Vain Vipers | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 28 |
| Vamp | Heartbreak, Heartache | The Rich Don't Rock | Voorlopige VE-kandidaat | Sunset_Strip_Sleaze_Metal_DNA.csv; CSV-regel 9 |
| White Sister | Can't Say No | White Sister | Voorlopige VE-kandidaat | 80's_Hair_Metal_Deep_Cuts_DNA.csv; CSV-regel 14 |
| Whitecross | Enough Is Enough | Whitecross | Voorlopige VE-kandidaat | After_Hair_Metal_DNA.csv; CSV-regel 28 |
| Wild Boyz | I Don't Wanna Cry No More | I Don't Wanna Cry No More | Voorlopige VE-kandidaat | Hair_Metal_Gekkies_DNA.csv; CSV-regel 20 |
| Wild Machine | Straight to Hell | II | Voorlopige VE-kandidaat | Hair_Metal_Gekkies_DNA.csv; CSV-regel 29 |
| Wildstreet | Easy Does It | Easy Does It | Voorlopige VE-kandidaat | Modern_Hair_Metal_Revival_DNA.csv; CSV-regel 14 |
| Wrathchild | Stakk Attakk | Stakk Attakk | Voorlopige VE-kandidaat | Hair_Metal_DNA.csv; CSV-regel 23 |

## Wat openblijft

De 64 resterende kandidaten zijn nog geen definitieve Vergeten Edelstenen. De enige historisch positieve genreopname zonder gevonden gebruik is Kip Winger en medeartiesten — Limelight. De actuele FIFO-positie van alle positieve opnamen blijft afzonderlijk onbewezen, ook waar oudere DNA-playlist-expositie nu vaststaat. Stijlvragen bij Jester en Dirty White Boy blijven bestaan, maar blokkeren hun bewezen expositie niet.

[Bronnen en wijzigingslijst](Music-DNA-Depot-Aanvullende-Exports.json) · [Actuele kandidaatcollectie](Music-DNA-Depot-Proefcollectie.md)
