# Music DNA Depot — eerste Glam Metal-luisterproef

**15 opnamen uit de 63 voorlopige kandidaten.** Alle 15 blijven Onverkend. Bij geen van deze opnamen is expositie gevonden in de onderzochte projectbronnen; dat bewijst niet dat ze nooit zijn gebruikt.

## Waarom deze selectie

De selectie combineert zeven kandidaten met AOR-/Glam Rock-/Arena Rock-nevenlabels en acht met uitsluitend Glam Metal in het genreveld. Ze hebben geen expliciete versie- of identiteitswaarschuwing in de onderzochte velden. Dat is een praktische volgorde voor luisteren, geen kwaliteitsranglijst en geen bewijs van een standaard studio-opname. De bronjaren lopen van 1985 tot 2025; het zijn geen onafhankelijk vastgestelde opnamejaren.

De genrelabels zijn afgeleid van artiesttaxonomie. Er is voor deze selectie geen audio beoordeeld. De volgorde groepeert broncontexten; ze suggereert geen gecontroleerde muzikale overgang.

## Openen en beluisteren

| # | Artiest — opname | Album | Bronjaar |
|---:|---|---|---:|
| 1 | Dagger — [Not Afraid of the Night](https://open.spotify.com/track/5TKndAhkYfz3tT9NUn5ren) | Not Afraid of the Night | 1985 |
| 2 | Frehley's Comet — [Insane](https://open.spotify.com/track/0m1J2zlyqWduzS6lkjslzs) | Second Sighting | 1988 |
| 3 | Xenon — [Holding On](https://open.spotify.com/track/0BOLXa4KczJUhdKToxJ6Ne) | America's New Design | 1989 |
| 4 | Roxanne — [Cherry Bay](https://open.spotify.com/track/3gtmYnsRjZzSQCsHucAOZu) | Roxanne | 2009 |
| 5 | Tobruk — [Wild On The Run](https://open.spotify.com/track/0dprIaAzqac62p66lvfNQt) | Wild On The Run | 2004 |
| 6 | Gypsy Rose — [If Your Love Is Gone](https://open.spotify.com/track/1iGvPUw50XQuIRftlGRFcw) | Poisoned By Love | 2012 |
| 7 | Station — [Close My Eyes](https://open.spotify.com/track/04dxCbrdlJGukHY9L5E6r1) | And Time Goes On | 2023 |
| 8 | 80's Bush — [Sleazy Dirty Rock n Roll](https://open.spotify.com/track/0KZaCw93RIPJTveUh4ja8Z) | Sleazy Dirty Rock n Roll | 2021 |
| 9 | Dizzy Fox — [Over the Top](https://open.spotify.com/track/0e9LFPolYhPbVWJkR8u2wa) | First Bite | 2018 |
| 10 | Alleycatz — [Do It For The Rock N' Roll](https://open.spotify.com/track/2LxLBJX6mtdtZEXeiJulGC) | Private Vices, Public Pleasures | 2023 |
| 11 | Famous Underground — [Like an Animal](https://open.spotify.com/track/2byTL4KtY1cu40UM44hYy1) | Like an Animal | 2021 |
| 12 | Hairbangers Ball — [All Aboard The Bang Train](https://open.spotify.com/track/1FWb3ule3UGucIBKuoYOFJ) | All Aboard The Bang Train | 2021 |
| 13 | Sex 'N' Roll — [Roadrock](https://open.spotify.com/track/2zDE6qxdVk6Pnp46JIWxic) | Sex 'n' Roll | 2019 |
| 14 | FerreTT — [Farmer Vincent's Fritters](https://open.spotify.com/track/7GhBJmicg1GoLxfHx6x8F7) | Glamdemic | 2024 |
| 15 | Babylon Shakes — [Scarlet Sins](https://open.spotify.com/track/0OtfqVWR3F1shHMjiO2tyU) | Scarlet Sins | 2025 |

## Luistervragen

Beoordeel per opname: past de muziek bij de beoogde Glam Metal-collectie, is deze uitvoering bruikbaar, en verdient deze track een presentatie? Noteer eventueel een specifieke plek of thema. Een positieve luisterbeoordeling alleen bewijst nog geen FIFO-reservepositie en verandert de depotstatus niet.

| # | Past bij Glam Metal? | Uitvoering bruikbaar? | Presentatiekandidaat / reden |
|---:|---|---|---|
| 1 | Nog te beluisteren | Nog te beluisteren | Open |
| 2 | Nog te beluisteren | Nog te beluisteren | Open |
| 3 | Nog te beluisteren | Nog te beluisteren | Open |
| 4 | Nog te beluisteren | Nog te beluisteren | Open |
| 5 | Nog te beluisteren | Nog te beluisteren | Open |
| 6 | Nog te beluisteren | Nog te beluisteren | Open |
| 7 | Nog te beluisteren | Nog te beluisteren | Open |
| 8 | Nog te beluisteren | Nog te beluisteren | Open |
| 9 | Nog te beluisteren | Nog te beluisteren | Open |
| 10 | Nog te beluisteren | Nog te beluisteren | Open |
| 11 | Nog te beluisteren | Nog te beluisteren | Open |
| 12 | Nog te beluisteren | Nog te beluisteren | Open |
| 13 | Nog te beluisteren | Nog te beluisteren | Open |
| 14 | Nog te beluisteren | Nog te beluisteren | Open |
| 15 | Nog te beluisteren | Nog te beluisteren | Open |

## Bewijs per opname

Voor alle 15 geldt: geen gevonden expositie, actuele FIFO-positie onbekend, volledige historische dekking ontbreekt. ISRC’s zijn overgenomen uit lokale bronexports. Een bronplaylist is een vindplaats, geen bewijs van DNA-expositie.

### 1. Dagger — Not Afraid of the Night

De bron combineert Glam Metal, Glam Rock en AOR; een kandidaat om de grens tussen deze labels te beluisteren.

Projectgenre: **glam-metal,glamrock,aor**. Masterregel **2592**. Exacte Spotify-opname: [spotify:5TKndAhkYfz3tT9NUn5ren](https://open.spotify.com/track/5TKndAhkYfz3tT9NUn5ren).
- Broncode **CAU118508938** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 2593.
- Broncode **CAU118508938** — `spotify_playlists-2 kopie.zip → Ben's_Glam_Metal_favorites.csv`, CSV-regel 92.

### 2. Frehley's Comet — Insane

Glam Metal en AOR in de bron; albumcontext Second Sighting, bronjaar 1988.

Projectgenre: **glam-metal,aor**. Masterregel **803**. Exacte Spotify-opname: [spotify:0m1J2zlyqWduzS6lkjslzs](https://open.spotify.com/track/0m1J2zlyqWduzS6lkjslzs).
- Broncode **USAT20622419** — `ben's_full_favorite_bands_list.csv`, CSV-regel 846.
- Broncode **USAT20622419** — `spotify_playlists-2 kopie.zip → Liked_Songs.csv`, CSV-regel 2724.
- Broncode **USAT20622419** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 804.

### 3. Xenon — Holding On

Glam Metal, AOR en Arena Rock in de bron; albumcontext America’s New Design, bronjaar 1989.

Projectgenre: **glam-metal,aor,arena rock**. Masterregel **2619**. Exacte Spotify-opname: [spotify:0BOLXa4KczJUhdKToxJ6Ne](https://open.spotify.com/track/0BOLXa4KczJUhdKToxJ6Ne).
- Broncode **USHM80894970** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 2620.

### 4. Roxanne — Cherry Bay

Glam Metal, AOR en Arena Rock in de bron; albumcontext Roxanne. Het bronjaar 2009 is geen bewezen oorspronkelijk opnamejaar.

Projectgenre: **aor,arena rock,glam-metal**. Masterregel **2606**. Exacte Spotify-opname: [spotify:3gtmYnsRjZzSQCsHucAOZu](https://open.spotify.com/track/3gtmYnsRjZzSQCsHucAOZu).
- Broncode **USCGH0974693** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 2607.

### 5. Tobruk — Wild On The Run

Glam Metal, AOR en Arena Rock in de bron; albumcontext Wild On The Run. Het bronjaar 2004 blijft een cataloguswaarde.

Projectgenre: **aor,arena rock,glam-metal**. Masterregel **763**. Exacte Spotify-opname: [spotify:0dprIaAzqac62p66lvfNQt](https://open.spotify.com/track/0dprIaAzqac62p66lvfNQt).
- Broncode **GBKYA0703285** — `ben's_full_favorite_bands_list.csv`, CSV-regel 806.
- Broncode **GBKYA0703285** — `spotify_playlists-2 kopie.zip → Liked_Songs.csv`, CSV-regel 2767.
- Broncode **GBKYA0703285** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 764.

### 6. Gypsy Rose — If Your Love Is Gone

Glam Metal, AOR en Arena Rock in de bron; albumcontext Poisoned By Love.

Projectgenre: **glam-metal,arena rock,aor**. Masterregel **2341**. Exacte Spotify-opname: [spotify:1iGvPUw50XQuIRftlGRFcw](https://open.spotify.com/track/1iGvPUw50XQuIRftlGRFcw).
- Broncode **USHM91250703** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 2342.
- Broncode **USHM91250703** — `spotify_playlists-2 kopie.zip → Ben's_Glam_Metal_favorites.csv`, CSV-regel 83.

### 7. Station — Close My Eyes

Glam Metal, AOR en Arena Rock in de bron; albumcontext And Time Goes On, bronjaar 2023.

Projectgenre: **arena rock,aor,glam-metal**. Masterregel **1432**. Exacte Spotify-opname: [spotify:04dxCbrdlJGukHY9L5E6r1](https://open.spotify.com/track/04dxCbrdlJGukHY9L5E6r1).
- Broncode **QZWHN2307007** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 1433.

### 8. 80's Bush — Sleazy Dirty Rock n Roll

Glam Metal is het enige genrelabel in het projectveld; deze opname krijgt een afzonderlijke luistertoets.

Projectgenre: **glam-metal**. Masterregel **3038**. Exacte Spotify-opname: [spotify:0KZaCw93RIPJTveUh4ja8Z](https://open.spotify.com/track/0KZaCw93RIPJTveUh4ja8Z).
- Broncode **QM9AA2088652** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 3039.
- Broncode **QM9AA2088652** — `spotify_playlists-2 kopie.zip → Ben's_Modern_hardrock_favorites_.csv`, CSV-regel 34.

### 9. Dizzy Fox — Over the Top

Glam Metal is het enige genrelabel in het projectveld; deze opname krijgt een afzonderlijke luistertoets.

Projectgenre: **glam-metal**. Masterregel **2783**. Exacte Spotify-opname: [spotify:0e9LFPolYhPbVWJkR8u2wa](https://open.spotify.com/track/0e9LFPolYhPbVWJkR8u2wa).
- Broncode **USHM21883448** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 2784.

### 10. Alleycatz — Do It For The Rock N' Roll

Glam Metal is het enige genrelabel in het projectveld; deze opname krijgt een afzonderlijke luistertoets.

Projectgenre: **glam-metal**. Masterregel **3049**. Exacte Spotify-opname: [spotify:2LxLBJX6mtdtZEXeiJulGC](https://open.spotify.com/track/2LxLBJX6mtdtZEXeiJulGC).
- Broncode **QZHNA2327058** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 3050.
- Broncode **QZHNA2327058** — `spotify_playlists-2 kopie.zip → Ben's_Modern_hardrock_favorites_.csv`, CSV-regel 22.
- Broncode **QZHNA2327058** — `spotify_playlists-2 kopie.zip → Ben's_Top_2000_list_2025_version.csv`, CSV-regel 33.
- Broncode **QZHNA2327058** — `spotify_playlists-2 kopie.zip → Jouw_topnummers_in_2025.csv`, CSV-regel 86.

### 11. Famous Underground — Like an Animal

Glam Metal is het enige genrelabel in het projectveld; deze opname krijgt een afzonderlijke luistertoets.

Projectgenre: **glam-metal**. Masterregel **3222**. Exacte Spotify-opname: [spotify:2byTL4KtY1cu40UM44hYy1](https://open.spotify.com/track/2byTL4KtY1cu40UM44hYy1).
- Broncode **GX3Q92182506** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 3223.
- Broncode **GX3Q92182506** — `spotify_playlists-2 kopie.zip → Ben's_Modern_hardrock_favorites_.csv`, CSV-regel 92.

### 12. Hairbangers Ball — All Aboard The Bang Train

Glam Metal is het enige genrelabel in het projectveld; deze opname krijgt een afzonderlijke luistertoets.

Projectgenre: **glam-metal**. Masterregel **2760**. Exacte Spotify-opname: [spotify:1FWb3ule3UGucIBKuoYOFJ](https://open.spotify.com/track/1FWb3ule3UGucIBKuoYOFJ).
- Broncode **QZDA62187266** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 2761.

### 13. Sex 'N' Roll — Roadrock

Glam Metal is het enige genrelabel in het projectveld; deze opname krijgt een afzonderlijke luistertoets.

Projectgenre: **glam-metal**. Masterregel **3040**. Exacte Spotify-opname: [spotify:2zDE6qxdVk6Pnp46JIWxic](https://open.spotify.com/track/2zDE6qxdVk6Pnp46JIWxic).
- Broncode **QZGLM1904217** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 3041.
- Broncode **QZGLM1904217** — `spotify_playlists-2 kopie.zip → Ben's_Modern_hardrock_favorites_.csv`, CSV-regel 32.

### 14. FerreTT — Farmer Vincent's Fritters

Glam Metal is het enige genrelabel in het projectveld; deze opname krijgt een afzonderlijke luistertoets.

Projectgenre: **glam-metal**. Masterregel **3036**. Exacte Spotify-opname: [spotify:7GhBJmicg1GoLxfHx6x8F7](https://open.spotify.com/track/7GhBJmicg1GoLxfHx6x8F7).
- Broncode **USGE32490609** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 3037.
- Broncode **USGE32490609** — `spotify_playlists-2 kopie.zip → Ben's_Modern_hardrock_favorites_.csv`, CSV-regel 36.

### 15. Babylon Shakes — Scarlet Sins

Glam Metal is het enige genrelabel in het projectveld; deze opname krijgt een afzonderlijke luistertoets.

Projectgenre: **glam-metal**. Masterregel **3208**. Exacte Spotify-opname: [spotify:0OtfqVWR3F1shHMjiO2tyU](https://open.spotify.com/track/0OtfqVWR3F1shHMjiO2tyU).
- Broncode **TCAJG2550685** — `spotify_playlists-2 kopie.zip → Ben's_full_favorite_bands-list.csv`, CSV-regel 3209.
- Broncode **TCAJG2550685** — `spotify_playlists-2 kopie.zip → Ben's_Modern_hardrock_favorites_.csv`, CSV-regel 76.

## Wat de proef oplevert

Een afgeronde luisterbeoordeling kan de 15 scheiden in passende presentatiekandidaten, minder passende tracks en opnamen die nader versieonderzoek vragen. De aanduiding Vergeten Edelsteen blijft afhankelijk van historische gebruiksdekking en stroomcontrole.

Volledige ordening van de 63 kandidaten: [Music-DNA-Depot-Kandidatenordening.md](/Users/benvanbelzen/Documents/Codex/2026-10-07/referenced-chatgpt-conversation-this-is-an/outputs/Music-DNA-Depot-Kandidatenordening.md). Exacte bronpaden en gegevens: [Music-DNA-Depot-Luisterproef.json](/Users/benvanbelzen/Documents/Codex/2026-10-07/referenced-chatgpt-conversation-this-is-an/outputs/Music-DNA-Depot-Luisterproef.json).
