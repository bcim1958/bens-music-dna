# Depot — Jester en Dirty White Boy

**Actualisering v1.15:** onderstaande controle is onderzoekshistorie. Aanvullende DNA-exports wijzigen de expositiestand naar 409 Geëxposeerd en 65 Onverkend, met 64 VE-kandidaten. Zie het [actuele overzicht](Music-DNA-Depot-v1-Overzicht.md). Opname-, herkomst- en stijlbevindingen blijven afzonderlijk gelden.


Stand 7 oktober 2026. Aanvullende cataloguscontrole op twee bestaande Masteropnamen. De oorspronkelijke projectgegevens en depotstatussen blijven bewaard.

## Dirty White Boy — Let's Spend Momma's Money

De [exacte Spotify-opname](https://open.spotify.com/track/6o0hQH5YEno9mmEll9biox) verwijst naar *Bad Reputation* (1990), artiest-ID `0Nt8JZfYH4GPQ8D6lEswpP` en album-ID `0WQm26hc0CRbnwHaWh77YT`. Getoonde duur: 4:28.

[Universal Music](https://www.universal-music.co.jp/p/uicy-79886/) beschrijft het album als het debuut van de hardrockband rond Earl Slick, David Glen Eisley en Keni Richards. De tracklijst bevat Let's Spend Momma's Money. [Earl Slicks eigen discografie](https://earlslick.net/discography/) bevestigt Dirty White Boy — Bad Reputation (1990).

Daarmee is de historische band-/albumcontext onderbouwd. Het gekoppelde Spotify-profiel bevat daarnaast *Hick Hop* (2010). Dat kan een aanwijzing voor profielvermenging zijn, maar de identiteit van die tweede uitgave is hier niet vastgesteld. **Country hiphop is geen bewezen stijl van de onderzochte opname.** De oorspronkelijke gemengde genrevelden blijven als bronwaarden behouden; hardrock wordt afzonderlijk als onderbouwde albumcontext opgeslagen. Glam/Hair Metal op trackniveau is niet zelfstandig bewezen.

## Jester — Digitalia

De [exacte Spotify-opname](https://open.spotify.com/track/1eWxmMqLWfc4wtWk0skw4w) verwijst naar artiest-ID `3jMAkO3HHgSvh3YyIPcZ7d` en album-ID `2Yjc0Hdx0InKea51KTuzfC`. Duur 3:12, catalogusdatum 10 augustus 1999, copyrightvermelding Voodoo Management.

Het gelezen [Apple Music-catalogusresultaat](https://music.apple.com/us/album/digitalia/4012469) noemt hetzelfde album, dezelfde datum en rechthebbende, met categorie Rock. De directe pagina kon via de webtool niet worden opgehaald; de bewijsmethode is daarom expliciet als zoekresultaat opgeslagen. Dit onderbouwt rockcontext op albumniveau, geen Glam Metal-classificatie van de track.

De gecontroleerde Spotify-informatiekaart geeft geen herkomstbiografie. De Zweedse herkomst uit de Master is in deze ronde niet onafhankelijk bevestigd. Noorse hiphop en Zweedse pop blijven onbevestigde bronlabels voor deze opname. Er is geen ander Jester-profiel alleen op naam aan deze opname gekoppeld.

## Depotuitkomst

Beide opnamen blijven **Onverkend**, in de afzonderlijke werkvoorraad voor identiteit/stijl. Ze worden nog niet toegevoegd aan de 148 voorlopige VE-kandidaten. De actuele stand blijft 315 Geëxposeerd en 159 Onverkend binnen de 474 genre-gelabelde opnamen. Gebruiks-/FIFO-afwezigheid is niet bewezen. De Master is ongewijzigd.
