# Depot — alternatieve versies en Trixter-controle

**Actualisering v1.15:** onderstaande controle is onderzoekshistorie. Aanvullende DNA-exports wijzigen de expositiestand naar 409 Geëxposeerd en 65 Onverkend, met 64 VE-kandidaten. Zie het [actuele overzicht](Music-DNA-Depot-v1-Overzicht.md). Opname-, herkomst- en stijlbevindingen blijven afzonderlijk gelden.


Stand 7 oktober 2026.

## Volledige Mastervergelijking

Alle 148 voorlopige VE-kandidaten zijn vergeleken met alle 3.646 Masterrecords. De vergelijking gebruikt dezelfde volledige artiestcredit en een genormaliseerde tracktitel. Expliciete versieaanduidingen zoals remaster, demo en live worden voor deze zoekstap verwijderd; oorspronkelijke titels blijven intact.

**Geen kandidaat heeft binnen deze Master een andere URI met overeenkomstige artiestcredit en titel.** Dit is een afgebakend zoekresultaat, geen bewijs van nooit geëxposeerd. Artiestaliassen, afwijkende credits, ontbrekende historische records en onbekende titelvarianten blijven buiten de dekking. De eerdere vergelijking met CSV-bronnen blijft afzonderlijk bewaard.

## Trixter — One in a Million

De exacte [Spotify-opname](https://open.spotify.com/track/0MiEhQOPw9IlArjnSLe84w) koppelt aan album *Alive in Japan*, artiest-ID `4M3TtMs03DHCYvzbgzBnyZ`, album-ID `2vhuQSz7zozxEcfR5skhcw`, duur 5:27 en catalogusdatum 27 april 2009.

[Apple Music](https://music.apple.com/us/song/one-in-a-million-live/315122534) noemt deze titel **One In a Million (Live)**, uit *Alive In Japan (Bonus Track Version) [Live]*, met dezelfde datum. Daarmee is live-context onderbouwd via een catalogusvergelijking. De exacte gelijke opname tussen beide platforms is niet via ISRC of audio vastgesteld. Het oorspronkelijke opnamejaar blijft open.

De Masterwaarde **Standaard/onbekend** blijft als bronwaarde bewaard. De depotweergave vermeldt nu **Live — onderbouwde cataloguscontext; exacte opname-equivalentie open**. Dit is geen verandering van gebruiksstatus: Trixter blijft Onverkend en een voorlopige VE-kandidaat.

## Verwerking

148 kandidaatopnamen blijven behouden. De negen positieve stroomgevallen blijven afzonderlijk. Er is geen nieuwe expositie, definitieve Vergeten Edelsteen of stroomafwijking bewezen. De originele Master is ongewijzigd.
