# Depot — aanvullende archiefcontrole

Onderzoeksronde 7 oktober 2026. Elf aanvullende lokale ZIP-archieven zijn geheel op CSV-leden onderzocht. Er zijn 829 CSV-leden gelezen, met 792 verschillende bestandsinhouden. Daarvan waren 674 inhoudsvarianten nog niet in de eerdere losse CSV-zoekslag gelezen. Er waren geen leesfouten.

## Nieuw expositiebewijs

**The Last Vegas — Raw Dog** staat met URI `spotify:track:7pHiMsZHv3nGLOIQvZHfhO` in het archief `/Users/benvanbelzen/Desktop/Mappen/spotify_playlists-2.zip`, lid `Hair_Metal_DNA.csv`, CSV-regel 24. Artiest, titel, album *Seal the Deal* en exacte URI komen overeen met de Depot-opname. Het exportveld Added At bevat `2026-09-04T09:55:58Z`; dat is een playlist-toevoegwaarde, geen onafhankelijk vastgestelde exportdatum of FIFO-datum.

Deze opgeslagen DNA-playlist-export is gebruiksregistratie. De opname wordt **Geëxposeerd** en valt af als VE-kandidaat. De uitgepakte export met dezelfde naam bevatte deze URI niet; archiefvarianten zijn daarom afzonderlijk gelezen. De datum en oorzaak van dat inhoudsverschil zijn niet vastgesteld.

De actuele stand wordt **410 Geëxposeerd en 64 Onverkend**, waaronder **63 voorlopige VE-kandidaten**. Er zijn 118 aanvullend geregistreerde/gecontroleerde gebruiksgevallen tegenover Niet gebruikt in de oorspronkelijke Master.

## Bronrollen onderscheiden

De ZIP’s met Spotify-exportbestanden bevatten ook likes, algemene favorieten en bronplaylists. Een archiefnaam bewijst geen DNA-expositie van ieder lid. Alleen als DNA-playlist herkenbare exportleden zijn als DNA-gebruiksregistratie verwerkt. Import-/auditarchieven en algemene bronplaylists blijven afzonderlijke onderzoekssporen. Gelijke CSV-inhoud is gededupliceerd op inhoudshash en lidnaam; bronpad en CSV-regel blijven bewaard.

Over de collectie zijn 1.428 gededupliceerde opname–DNA-exportbewijzen toegevoegd; veel daarvan ondersteunen al eerder bekende expositie. Dat zijn geen 1.428 unieke opnamen. De gebruiksindex verenigt meerdere bewijsbronnen per opname en toepassingsnaam.

## Opnamecodes

De uitgebreidere exportarchieven bevatten geldige ISRC-bronmetadata voor alle 63 resterende kandidaten. Er zijn geen conflicterende broncodes gevonden. De vergelijking met 3.523 referentie-URI’s met gebruiksregistratie levert geen gelijke broncode bij een andere URI op voor deze kandidaten. De vergelijking is beperkt tot referentieopnamen waarvoor broncodes beschikbaar zijn; ze bewijst geen afwezigheid van historische expositie.

De originele Master en alle bronarchieven blijven ongewijzigd. Alle vaste statusregels blijven gelden.

[Archiefbronnen en bewijsregels](Music-DNA-Depot-Archiefcontrole.json) · [ISRC-controle](Music-DNA-Depot-ISRC-Controle.json) · [Actueel overzicht](Music-DNA-Depot-v1-Overzicht.md)
