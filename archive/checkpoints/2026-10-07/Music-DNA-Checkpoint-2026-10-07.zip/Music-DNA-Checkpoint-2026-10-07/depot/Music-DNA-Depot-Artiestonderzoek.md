# Depot — vijf artiestidentiteiten gecontroleerd

**Actualisering v1.15:** onderstaande controle is onderzoekshistorie. Aanvullende DNA-exports wijzigen de expositiestand naar 409 Geëxposeerd en 65 Onverkend, met 64 VE-kandidaten. Zie het [actuele overzicht](Music-DNA-Depot-v1-Overzicht.md). Opname-, herkomst- en stijlbevindingen blijven afzonderlijk gelden.


Stand 7 oktober 2026. Exacte Spotify-opnamen zijn teruggelezen op artiest- en albumkoppelingen. De herkomstcontrole gebruikt uitsluitend de biografie van het aan die opname gekoppelde Spotify-profiel.

| Opname | Artiest-ID | Album-ID | Herkomstuitkomst |
|---|---|---|---|
| Cyanide — Nikki Sixx in Disguise | 5mrC8oCJAqhNlXkcb52443 | 7GIwKT4tDk5fWHIxn7M3Xh | Open |
| Invasion — All For All | 0UVhdgxNalIFFYqUoLeREd | 6yuQqKyCtqxSxGo5VeNTSf | Noorwegen |
| LIVE WIRE — Nobody Beats Me | 5qlzmJ7WiTdb8TtOm5Iyfz | 0anlqHhUVtp8kBssOIAmks | Colombia |

## Invasion

[De exacte All For All-opname](https://open.spotify.com/track/5CZvaGIMgByckotMvygDj7) koppelt aan [dit Invasion-profiel](https://open.spotify.com/artist/0UVhdgxNalIFFYqUoLeREd). De biografie noemt de band Noors en beschrijft melodic heavy metal. Daarmee is de onzekere bronherkomst Noorwegen onderbouwd. Dit bevestigt niet automatisch het Glam Metal-label op trackniveau.

## LIVE WIRE

[Nobody Beats Me](https://open.spotify.com/track/277NHPZ7qAtTTWGP2QiIN8) koppelt aan [dit LIVE WIRE-profiel](https://open.spotify.com/artist/5qlzmJ7WiTdb8TtOm5Iyfz). De biografie beschrijft een Colombiaanse rockband en noemt dit nummer expliciet. **De depotwerklaag gebruikt daarom Colombia als onderbouwde herkomst; Verenigde Staten blijft bewaard als afwijkende Masterbronwaarde.**

De trackpagina toont 7 december 2021 als releasedatum en daarnaast copyrightvermeldingen met 2023. Die verschillende datumsoorten worden niet gelijkgesteld; een oorspronkelijk opnamejaar is hiermee niet vastgesteld.

## Cyanide

[Nikki Sixx in Disguise](https://open.spotify.com/track/6NBbDMw691g08HeKa8EjyG) koppelt aan [Cyanide met artiest-ID 5mrC8oCJAqhNlXkcb52443](https://open.spotify.com/artist/5mrC8oCJAqhNlXkcb52443) en album Lethal Dose. De pagina toont 27 januari 2015. Artiest-/albumidentiteit is bevestigd; de gelezen biografie noemt geen expliciet herkomstland. Verenigde Staten blijft daarom onbevestigd.

## Verwerking

- Twee van de drie gerichte herkomstvragen zijn opgehelderd. Van de vijf eerdere herkomstblokkades blijven er drie open: Cyanide, Mafia Rock en Fat Nelly.
- Spotify-artiest-ID en album-ID zijn als vaste koppelingen toegevoegd aan de drie depotrecords. Zo hoeft een volgende controle niet opnieuw op de ambigue naam alleen te zoeken.
- Landfilter gebruikt de onderbouwde depotwaarde, terwijl oorspronkelijke Masterwaarden intact blijven.
- Expositie-/FIFO-statussen en de 148 voorlopige VE-kandidaten veranderen niet: herkomstonderzoek bewijst geen nooit-geëxposeerd status.
- Genreclassificatie op trackniveau en account-/marktgebonden afspeelbaarheid blijven open.

## Mafia Rock en Fat Nelly — vervolgcontrole

Beide exacte Master-opnamen zijn op 7 oktober 2026 gekoppeld aan vaste Spotify-artiest- en album-ID’s:

| Opname | Artiest-ID | Album-ID | Catalogusdatum |
|---|---|---|---|
| [Mafia Rock — Crazy! (All Nightlong)](https://open.spotify.com/track/1UxXpbh1pNmNKGcpKNnggY) | 0WgwCQ7zdsRZCGWz9Yk8pJ | 5HOwx7J7uGLuxblsdXUMw6 | 2019-01-12 |
| [Fat Nelly — Speed of Light](https://open.spotify.com/track/4flnbSlfY4Ct5ZBXBikXm4) | 4VYrHjMg5Xd3w2UIAcNEOx | 3w6rxpwKiqTHWPzw2uMSsM | 2014-08-28 |

De geopende artiestinformatiekaarten bevatten geen herkomstbiografie. Bij Mafia Rock worden Braziliaanse luisteraarslocaties getoond; dat bewijst geen bandherkomst. Brazilië en Zweden blijven daarom onbevestigde Masterbronwaarden. De catalogusdatum is geen vastgesteld opnamejaar. Mafia Rock blijft Geëxposeerd op basis van de bestaande registratie in Special 59. Fat Nelly blijft Onverkend in het aangrenzende onderzoek, zonder bevestigd Glam/Hair Metal-lidmaatschap. De gemengde bronlabels zijn hiermee evenmin bewezen fout.

Actuele eindstand van deze controle: vijf exacte artiest-/albumkoppelingen, twee onderbouwde herkomsten, drie open herkomsten (Cyanide, Mafia Rock, Fat Nelly).
