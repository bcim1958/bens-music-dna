# Music DNA Depot — waar Glam Metal is gebruikt

Stand 7 oktober 2026. Deze index ontsluit alle **410 Geëxposeerd** geregistreerde genreopnamen per gevonden toepassing, inclusief album en bewijsmethode. De 15 aangrenzende onderzoekscases vallen buiten deze telling.

Er zijn **178 afzonderlijke toepassingsnamen** en **1131 opname–toepassingcombinaties** gevonden. Eén opname kan in meerdere toepassingen voorkomen; categorieaantallen mogen daarom niet worden opgeteld.

## Dekking

| Categorie | Toepassingsnamen | Unieke opnamen |
|---|---:|---:|
| Jaarboeken | 43 | 101 |
| Overige DNA-playlists | 42 | 375 |
| Specials | 91 | 190 |
| Weeklijsten/museum | 2 | 34 |

## Bewijsmethoden

- **DNA-playlist-exportregistratie:** exacte URI in een opgeslagen DNA-playlist-export, met toevoegdatum; geen nieuwe livecontrole.
- **Masterregistratie:** bestaande projectregistratie; geen onafhankelijke livecontrole per historische playlist.
- **Opgeslagen weekhistorie:** gebruik vastgelegd in de export van 3 oktober; geen live Spotify-controle.
- **Museumpublicatie:** exacte opnamelinks teruggelezen op de gepubliceerde W40-pagina; bewijst museumexpositie.
- **Spotify-publicatie:** Special 104 live gecontroleerd op alle 15 exacte URI’s en volgorde.

Toepassingsnamen zijn letterlijk bewaard. Een ongenummerde Special is niet zonder bewijs gelijkgesteld aan een genummerde Special. Voorbereide selecties en positieve beoordelingen tellen niet als expositie.

## Toepassingen en aantallen

| Toepassing | Unieke opnamen |
|---|---:|
| DNA JAARBOEK 1980 | 2 |
| DNA JAARBOEK 1980 [exportbestandsnaam] | 3 |
| DNA JAARBOEK 1982 | 2 |
| DNA JAARBOEK 1982 [exportbestandsnaam] | 1 |
| DNA JAARBOEK 1983 | 4 |
| DNA JAARBOEK 1983 [exportbestandsnaam] | 3 |
| DNA JAARBOEK 1984 | 10 |
| DNA JAARBOEK 1984 [exportbestandsnaam] | 6 |
| DNA JAARBOEK 1985 | 6 |
| DNA JAARBOEK 1985 [exportbestandsnaam] | 5 |
| DNA JAARBOEK 1986 | 4 |
| DNA JAARBOEK 1986 [exportbestandsnaam] | 3 |
| DNA JAARBOEK 1987 | 7 |
| DNA JAARBOEK 1987 [exportbestandsnaam] | 6 |
| DNA JAARBOEK 1988 | 4 |
| DNA JAARBOEK 1988 [exportbestandsnaam] | 4 |
| DNA JAARBOEK 1989 | 7 |
| DNA JAARBOEK 1989 [exportbestandsnaam] | 5 |
| DNA JAARBOEK 1990 | 8 |
| DNA JAARBOEK 1990 [exportbestandsnaam] | 6 |
| DNA JAARBOEK 1991 | 7 |
| DNA JAARBOEK 1991 [exportbestandsnaam] | 4 |
| DNA JAARBOEK 1992 | 6 |
| DNA JAARBOEK 1992 [exportbestandsnaam] | 6 |
| DNA JAARBOEK 1993 | 3 |
| DNA JAARBOEK 1993 [exportbestandsnaam] | 2 |
| DNA JAARBOEK 1994 | 2 |
| DNA JAARBOEK 1994 [exportbestandsnaam] | 2 |
| DNA JAARBOEK 1995 | 1 |
| DNA JAARBOEK 1995 [exportbestandsnaam] | 1 |
| DNA JAARBOEK 1999 | 1 |
| DNA JAARBOEK 1999  [exportbestandsnaam] | 1 |
| DNA JAARBOEK 1999 [exportbestandsnaam] | 1 |
| DNA JAARBOEK 2005 | 1 |
| DNA JAARBOEK 2010 | 5 |
| DNA JAARBOEK 2011 | 2 |
| DNA JAARBOEK 2012 | 2 |
| DNA JAARBOEK 2016 | 3 |
| DNA JAARBOEK 2020 | 3 |
| DNA JAARBOEK 2021 | 1 |
| DNA JAARBOEK 2022 | 2 |
| DNA JAARBOEK 2023 | 1 |
| DNA JAARBOEK 2024 | 2 |
| 80's Hair Metal Deep Cuts DNA [exportbestandsnaam] | 30 |
| After Hair Metal DNA [exportbestandsnaam] | 20 |
| Alternative Metal DNA | 1 |
| Alternative Metal DNA [exportbestandsnaam] | 1 |
| Arena Rock DNA  [exportbestandsnaam] | 5 |
| Blues Rock DNA | 1 |
| Blues Rock DNA [exportbestandsnaam] | 1 |
| Deep Purple DNA | 26 |
| Deep Purple DNA [exportbestandsnaam] | 26 |
| Ghost DNA | 10 |
| Ghost DNA [exportbestandsnaam] | 9 |
| Glam Rock DNA [exportbestandsnaam] | 5 |
| Hair Metal DNA [exportbestandsnaam] | 32 |
| Hair Metal Gekkies DNA [exportbestandsnaam] | 30 |
| Iron Maiden DNA | 12 |
| Iron Maiden DNA [exportbestandsnaam] | 12 |
| KISS DNA | 30 |
| KISS DNA [exportbestandsnaam] | 30 |
| Metallica DNA | 4 |
| Metallica DNA [exportbestandsnaam] | 4 |
| Modern Hair Metal Revival DNA [exportbestandsnaam] | 30 |
| Music DNA · Proefcadeau [exportbestandsnaam] | 1 |
| NWOBHM DNA | 5 |
| NWOBHM DNA [exportbestandsnaam] | 6 |
| Ontdek DNA #2026-39 [exportbestandsnaam] | 13 |
| Ontdek DNA #2026-40 [exportbestandsnaam] | 21 |
| RATT DNA | 30 |
| RATT DNA [exportbestandsnaam] | 30 |
| Rush DNA | 1 |
| Rush DNA [exportbestandsnaam] | 1 |
| Scandinavian Hair Metal DNA [exportbestandsnaam] | 29 |
| Southern Rock DNA | 1 |
| Southern Rock DNA [exportbestandsnaam] | 1 |
| Speed Thrash Metal DNA | 1 |
| Speed Thrash Metal DNA [exportbestandsnaam] | 1 |
| Sunset Strip Sleaze Metal DNA [exportbestandsnaam] | 30 |
| Sweet DNA | 27 |
| Sweet DNA [exportbestandsnaam] | 27 |
| The  Last Hardrock Goldmine DNA | 13 |
| The Last Hardrock Goldmine DNA [exportbestandsnaam] | 13 |
| Too Late For The Hair Metal Party DNA [exportbestandsnaam] | 24 |
| WASP Band DNA  [exportbestandsnaam] | 4 |
| DNA SPECIAL 05 | 15 |
| DNA SPECIAL 05 Haar Omhoog Dak Eraf [exportbestandsnaam] | 15 |
| DNA SPECIAL 06 | 12 |
| DNA SPECIAL 06 Gas Erop [exportbestandsnaam] | 12 |
| DNA SPECIAL 100 | 1 |
| DNA SPECIAL 100 Honderd Specials · Dit is mijn DNA [exportbestandsnaam] | 1 |
| DNA SPECIAL 103 Japan Achter de glitter | 1 |
| DNA SPECIAL 104 — De glitter bleef | 15 |
| DNA SPECIAL 13 | 2 |
| DNA SPECIAL 13 Ken ik ... maar niet zo! [exportbestandsnaam] | 2 |
| DNA SPECIAL 15 | 2 |
| DNA SPECIAL 15 Geen zanger nodig [exportbestandsnaam] | 2 |
| DNA SPECIAL 18 | 1 |
| DNA SPECIAL 18 Vrouwen vooraan [exportbestandsnaam] | 1 |
| DNA SPECIAL 21 | 4 |
| DNA SPECIAL 21 Zweden; Melodie uit het noorden [exportbestandsnaam] | 4 |
| DNA SPECIAL 22 | 3 |
| DNA SPECIAL 22 Finland; Donker licht [exportbestandsnaam] | 3 |
| DNA SPECIAL 23 | 2 |
| DNA SPECIAL 23 Duitsland; Staal en stroom [exportbestandsnaam] | 2 |
| DNA SPECIAL 24 | 2 |
| DNA SPECIAL 24 Nederland; Van polder tot prog [exportbestandsnaam] | 2 |
| DNA SPECIAL 25 | 1 |
| DNA SPECIAL 25 Canada; Hard maar melodieus [exportbestandsnaam] | 1 |
| DNA SPECIAL 27 | 2 |
| DNA SPECIAL 27 Zuid-Europa; Van Italië tot Iberië [exportbestandsnaam] | 2 |
| DNA SPECIAL 28 | 2 |
| DNA SPECIAL 28 Oost-Europa; Achter het voormalige gordijn [exportbestandsnaam] | 2 |
| DNA SPECIAL 29 | 2 |
| DNA SPECIAL 29 Noord-Europa; Van de fjorden tot de Oostzee [exportbestandsnaam] | 2 |
| DNA SPECIAL 30 | 1 |
| DNA SPECIAL 30 Brazilië & Latijns-Amerika; Zuidwaarts [exportbestandsnaam] | 1 |
| DNA SPECIAL 34 | 6 |
| DNA SPECIAL 34 1983–1986; Alles wordt groter [exportbestandsnaam] | 9 |
| DNA SPECIAL 35 | 3 |
| DNA SPECIAL 35 1987–1990; Hoogtepunt vóór de breuk [exportbestandsnaam] | 6 |
| DNA SPECIAL 36 | 2 |
| DNA SPECIAL 36 1991–1994; De grote reset [exportbestandsnaam] | 3 |
| DNA SPECIAL 39 2005–2008; Nieuwe hardheid, oude wortels [exportbestandsnaam] | 2 |
| DNA SPECIAL 40 | 2 |
| DNA SPECIAL 40 2009–2012; Oud DNA, nieuwe motor [exportbestandsnaam] | 3 |
| DNA SPECIAL 41 | 1 |
| DNA SPECIAL 41 2013–2016; Retro wordt weer nieuw [exportbestandsnaam] | 1 |
| DNA SPECIAL 42 | 1 |
| DNA SPECIAL 42 2017–2019; Grenzen lossen op [exportbestandsnaam] | 1 |
| DNA SPECIAL 44 | 2 |
| DNA SPECIAL 44 2023–2026; Hier staan we nu [exportbestandsnaam] | 2 |
| DNA SPECIAL 45 | 1 |
| DNA SPECIAL 45 1973; Prog op de top [exportbestandsnaam] | 1 |
| DNA SPECIAL 47 | 6 |
| DNA SPECIAL 47 1984; Glans tegen staal [exportbestandsnaam] | 6 |
| DNA SPECIAL 48 | 3 |
| DNA SPECIAL 48 1992; Na de aardverschuiving [exportbestandsnaam] | 3 |
| DNA SPECIAL 50 | 2 |
| DNA SPECIAL 50 2016; Oud geluid, nieuwe generatie [exportbestandsnaam] | 2 |
| DNA SPECIAL 51 | 6 |
| DNA SPECIAL 51 De riff beslist [exportbestandsnaam] | 6 |
| DNA SPECIAL 52 | 2 |
| DNA SPECIAL 52 Melodie onder spanning [exportbestandsnaam] | 2 |
| DNA SPECIAL 55 | 7 |
| DNA SPECIAL 55 Hard zonder brullen [exportbestandsnaam] | 7 |
| DNA SPECIAL 59 | 9 |
| DNA SPECIAL 59 Oud DNA; onverwachte erfgenamen [exportbestandsnaam] | 9 |
| DNA SPECIAL 65 Los Angeles 1983-1990; Sunset Strip [exportbestandsnaam] | 15 |
| DNA SPECIAL 71 | 2 |
| DNA SPECIAL 71 Uit elkaar, weer verder; Bands uit bands [exportbestandsnaam] | 2 |
| DNA SPECIAL 72 | 1 |
| DNA SPECIAL 72 Het zijproject werd serieus [exportbestandsnaam] | 1 |
| DNA SPECIAL 73 | 7 |
| DNA SPECIAL 73 De gitarist verhuisde [exportbestandsnaam] | 7 |
| DNA SPECIAL 74 | 3 |
| DNA SPECIAL 74 De ritmesectie bleef staan [exportbestandsnaam] | 3 |
| DNA SPECIAL 75 | 2 |
| DNA SPECIAL 75 De producer als onzichtbaar bandlid [exportbestandsnaam] | 2 |
| DNA SPECIAL 77 | 3 |
| DNA SPECIAL 77 Supergroepen; Meer dan de som [exportbestandsnaam] | 3 |
| DNA SPECIAL 78 | 4 |
| DNA SPECIAL 78 Gastrollen die ertoe deden [exportbestandsnaam] | 4 |
| DNA SPECIAL 82 | 4 |
| DNA SPECIAL 82 Het refrein blijft hangen [exportbestandsnaam] | 4 |
| DNA SPECIAL 83 | 4 |
| DNA SPECIAL 83 De solo verandert alles [exportbestandsnaam] | 4 |
| DNA SPECIAL 86 | 2 |
| DNA SPECIAL 86 Live wordt het beter [exportbestandsnaam] | 2 |
| DNA SPECIAL 93 | 1 |
| DNA SPECIAL 93 Zachter dan verwacht [exportbestandsnaam] | 1 |
| DNA SPECIAL 95 | 3 |
| DNA SPECIAL 95 Nieuwe muziek met oude wortels [exportbestandsnaam] | 3 |
| DNA SPECIAL 96 | 3 |
| DNA SPECIAL 96 Onverwachte landen [exportbestandsnaam] | 3 |
| DNA SPECIAL — Glam: de vergeten zijstraten | 15 |
| Ontdek DNA 2026-W39 — opgeslagen weekhistorie | 13 |
| Ontdek DNA 2026-W40 — museum | 21 |

## DNA JAARBOEK 1980

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Girlschool | [Race with the Devil](https://open.spotify.com/track/3D8KAebbZgAFdVjTrsNgOI) | Demolition | Masterregistratie |
| Ozzy Osbourne | [Crazy Train](https://open.spotify.com/track/2b9lp5A6CqSzwOrBfAFhof) | Blizzard of Ozz (Expanded Edition) | Masterregistratie |

## DNA JAARBOEK 1980 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Girlschool | [Race with the Devil](https://open.spotify.com/track/3D8KAebbZgAFdVjTrsNgOI) | Demolition | DNA-playlist-exportregistratie |
| Ozzy Osbourne | [Crazy Train](https://open.spotify.com/track/2b9lp5A6CqSzwOrBfAFhof) | Blizzard of Ozz (Expanded Edition) | DNA-playlist-exportregistratie |
| Van Halen | [And the Cradle Will Rock... - 2015 Remaster](https://open.spotify.com/track/4MM0jT9z9m7VFiusFrGJ8C) | Women and Children First (Remastered) | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1982

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Aldo Nova | [Fantasy](https://open.spotify.com/track/1zrba5qe6xkC84AlbXNa6u) | Aldo Nova | Masterregistratie |
| Headpins | [Don't It Make Ya Feel](https://open.spotify.com/track/1t9huquVeeqLG9j5boQKsw) | Turn It Loud | Masterregistratie |

## DNA JAARBOEK 1982 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Aldo Nova | [Fantasy](https://open.spotify.com/track/1zrba5qe6xkC84AlbXNa6u) | Aldo Nova | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1983

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Fastway | [Say What You Will](https://open.spotify.com/track/08nVwMJvWeJwwc9pSd74wO) | FASTWAY | Masterregistratie |
| Quiet Riot | [Metal Health (Bang Your Head)](https://open.spotify.com/track/28clONjZmul6FjfO6tZQDE) | Metal Health | Masterregistratie |
| Streets | [If Love Should Go](https://open.spotify.com/track/3kAiPXqapVgYwOiISlcexP) | 1st | Masterregistratie |
| Zebra | [As I Said Before](https://open.spotify.com/track/3DQUOnH5OKGjXXnfKGj0UT) | Zebra | Masterregistratie |

## DNA JAARBOEK 1983 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Fastway | [Say What You Will](https://open.spotify.com/track/08nVwMJvWeJwwc9pSd74wO) | FASTWAY | DNA-playlist-exportregistratie |
| Quiet Riot | [Metal Health (Bang Your Head)](https://open.spotify.com/track/28clONjZmul6FjfO6tZQDE) | Metal Health | DNA-playlist-exportregistratie |
| Zebra | [As I Said Before](https://open.spotify.com/track/3DQUOnH5OKGjXXnfKGj0UT) | Zebra | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1984

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Autograph | [Turn up the Radio](https://open.spotify.com/track/7u0b4DthVvd2F2EzCiOx0Z) | Sign In Please | Masterregistratie |
| Bon Jovi | [Runaway](https://open.spotify.com/track/0X1sqQ652p1sceKM2nJlIJ) | Bon Jovi | Masterregistratie |
| Dokken | [Into the Fire](https://open.spotify.com/track/2QarjsUyOIxGeUA3sR1xSZ) | Tooth and Nail | Masterregistratie |
| Giuffria | [Do Me Right](https://open.spotify.com/track/1IsKwftNuXKGG9bjNXh7lU) | Giuffria | Masterregistratie |
| Helix | [Rock You](https://open.spotify.com/track/2sd8DUzBIaNBzkgEPGsHV6) | Walkin' The Razor's Edge | Masterregistratie |
| Honeymoon Suite | [Burning in Love](https://open.spotify.com/track/4vCR2DqRydeYDvZQkfzBmE) | Honeymoon Suite | Masterregistratie |
| Lee Aaron | [Metal Queen](https://open.spotify.com/track/4b3UYHaYfUb1V546Chw4to) | Metal Queen | Masterregistratie |
| Sammy Hagar | [I Can't Drive 55](https://open.spotify.com/track/1MqGKtY9L5qjPi8s7gX645) | Voa | Masterregistratie |
| Scorpions | [Rock You Like a Hurricane - 2015 - Remaster](https://open.spotify.com/track/2fICdpdRotwfmGYzvs8Ngf) | Love At First Sting (Deluxe Edition) | Masterregistratie |
| Twisted Sister | [I Wanna Rock](https://open.spotify.com/track/70Z9t1qhytWtG4cCmmi7mU) | Stay Hungry | Masterregistratie |

## DNA JAARBOEK 1984 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Autograph | [Turn up the Radio](https://open.spotify.com/track/7u0b4DthVvd2F2EzCiOx0Z) | Sign In Please | DNA-playlist-exportregistratie |
| Bon Jovi | [Runaway](https://open.spotify.com/track/0X1sqQ652p1sceKM2nJlIJ) | Bon Jovi | DNA-playlist-exportregistratie |
| Dokken | [Into the Fire](https://open.spotify.com/track/2QarjsUyOIxGeUA3sR1xSZ) | Tooth and Nail | DNA-playlist-exportregistratie |
| Lee Aaron | [Metal Queen](https://open.spotify.com/track/4b3UYHaYfUb1V546Chw4to) | Metal Queen | DNA-playlist-exportregistratie |
| Scorpions | [Rock You Like a Hurricane - 2015 - Remaster](https://open.spotify.com/track/2fICdpdRotwfmGYzvs8Ngf) | Love At First Sting (Deluxe Edition) | DNA-playlist-exportregistratie |
| Twisted Sister | [I Wanna Rock](https://open.spotify.com/track/70Z9t1qhytWtG4cCmmi7mU) | Stay Hungry | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1985

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alcatrazz | [God Blessed Video](https://open.spotify.com/track/2nsrALjWaiP5WqyzIkJlHe) | Disturbing The Peace | Masterregistratie |
| ICON | [Danger Calling](https://open.spotify.com/track/0oLhwxvNHtxeeJfkcdVufF) | Night Of The Crime | Masterregistratie |
| Keel | [Speed Demon](https://open.spotify.com/track/4dYQ2i4yH70kKhUXMypICn) | The Right To Rock | Masterregistratie |
| Ratt | [You're in Love](https://open.spotify.com/track/3D3lmTEhuWaunO1yxpYPD8) | Invasion of Your Privacy | Masterregistratie |
| Rough Cutt | [Piece of My Heart](https://open.spotify.com/track/01TluZKgLPWzBObU5plV1T) | Rough Cutt | Masterregistratie |
| The Cult | [She Sells Sanctuary (2009 Re-master)](https://open.spotify.com/track/3EAFamlgsYPA3HijLUPszI) | Love (Expanded Edition) | Masterregistratie |

## DNA JAARBOEK 1985 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alcatrazz | [God Blessed Video](https://open.spotify.com/track/2nsrALjWaiP5WqyzIkJlHe) | Disturbing The Peace | DNA-playlist-exportregistratie |
| Dio | [Rock 'N' Roll Children](https://open.spotify.com/track/4hbSkGwKpFYCkHJmLXVW7Y) | Sacred Heart (Deluxe Edition) | DNA-playlist-exportregistratie |
| KISS | [Tears Are Falling](https://open.spotify.com/track/1hxt3chzYLAzS4NmSSi5A3) | Asylum | DNA-playlist-exportregistratie |
| Ratt | [You're in Love](https://open.spotify.com/track/3D3lmTEhuWaunO1yxpYPD8) | Invasion of Your Privacy | DNA-playlist-exportregistratie |
| The Cult | [She Sells Sanctuary (2009 Re-master)](https://open.spotify.com/track/3EAFamlgsYPA3HijLUPszI) | Love (Expanded Edition) | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1986

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Cinderella | [Somebody Save Me](https://open.spotify.com/track/3fjiaIx6KFssAz3C8TaUec) | Night Songs | Masterregistratie |
| Craaft | [Hold Me - Remastered](https://open.spotify.com/track/6XwLmzU8uVVAEoGoXbo6Kc) | Craaft (Remastered) | Masterregistratie |
| Europe | [The Final Countdown](https://open.spotify.com/track/3MrRksHupTVEQ7YbA0FsZK) | The Final Countdown (Expanded Edition) | Masterregistratie |
| Tesla | [Modern Day Cowboy](https://open.spotify.com/track/5ZIU2kT1wNjQNclQeVCz5O) | Mechanical Resonance | Masterregistratie |

## DNA JAARBOEK 1986 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Cinderella | [Somebody Save Me](https://open.spotify.com/track/3fjiaIx6KFssAz3C8TaUec) | Night Songs | DNA-playlist-exportregistratie |
| Europe | [The Final Countdown](https://open.spotify.com/track/3MrRksHupTVEQ7YbA0FsZK) | The Final Countdown (Expanded Edition) | DNA-playlist-exportregistratie |
| Tesla | [Modern Day Cowboy](https://open.spotify.com/track/5ZIU2kT1wNjQNclQeVCz5O) | Mechanical Resonance | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1987

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Guns N' Roses | [Welcome To The Jungle](https://open.spotify.com/track/0bVtevEgtDIeRjCJbK3Lmv) | Appetite For Destruction | Masterregistratie |
| Leatherwolf | [The Calling](https://open.spotify.com/track/3jjDOFt8a30PQBrdKy298m) | Leatherwolf | Masterregistratie |
| Mötley Crüe | [Wild Side](https://open.spotify.com/track/41wWrTueWew7qUU0Ru87Mp) | Girls, Girls, Girls | Masterregistratie |
| Pretty Maids | [Future World](https://open.spotify.com/track/2v9855tCBy97Qp4BmMZscS) | Future World | Masterregistratie |
| TNT | [10,000 Lovers (In One)](https://open.spotify.com/track/7q1HuENSdN4GMm8IxvdeKg) | Tell No Tales | Masterregistratie |
| Warlock | [All We Are](https://open.spotify.com/track/2dU4FegjbgW5qkdrUdzogT) | Triumph And Agony | Masterregistratie |
| Whitesnake | [Still of the Night - 2018 Remaster](https://open.spotify.com/track/7AtwQRLPdttsxcLM5tPL0t) | Whitesnake (2018 Remaster) | Masterregistratie |

## DNA JAARBOEK 1987 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Def Leppard | [Animal](https://open.spotify.com/track/4qjscZh4jfhkpcQG4ZQfi2) | Hysteria | DNA-playlist-exportregistratie |
| Guns N' Roses | [Welcome To The Jungle](https://open.spotify.com/track/0bVtevEgtDIeRjCJbK3Lmv) | Appetite For Destruction | DNA-playlist-exportregistratie |
| Mötley Crüe | [Wild Side](https://open.spotify.com/track/41wWrTueWew7qUU0Ru87Mp) | Girls, Girls, Girls | DNA-playlist-exportregistratie |
| Pretty Maids | [Future World](https://open.spotify.com/track/2v9855tCBy97Qp4BmMZscS) | Future World | DNA-playlist-exportregistratie |
| Warlock | [All We Are](https://open.spotify.com/track/2dU4FegjbgW5qkdrUdzogT) | Triumph And Agony | DNA-playlist-exportregistratie |
| Whitesnake | [Still of the Night - 2018 Remaster](https://open.spotify.com/track/7AtwQRLPdttsxcLM5tPL0t) | Whitesnake (2018 Remaster) | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1988

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| David Lee Roth | [Just Like Paradise](https://open.spotify.com/track/5ZY7Gug850kv4heJcWZGHM) | Skyscraper | Masterregistratie |
| Kix | [Blow My Fuse](https://open.spotify.com/track/7jCc2Dz8PfHN3YoxDezkUl) | Blow My Fuse | Masterregistratie |
| Queensrÿche | [The Needle Lies - Remastered 2003](https://open.spotify.com/track/6D56362n3CmvFqPPqrujqc) | Operation: Mindcrime (Deluxe Edition) | Masterregistratie |
| Vixen | [Edge Of A Broken Heart](https://open.spotify.com/track/2mEk0VdrbDJ11DBC6Y92mh) | Vixen | Masterregistratie |

## DNA JAARBOEK 1988 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| David Lee Roth | [Just Like Paradise](https://open.spotify.com/track/5ZY7Gug850kv4heJcWZGHM) | Skyscraper | DNA-playlist-exportregistratie |
| Kix | [Blow My Fuse](https://open.spotify.com/track/7jCc2Dz8PfHN3YoxDezkUl) | Blow My Fuse | DNA-playlist-exportregistratie |
| Queensrÿche | [The Needle Lies - Remastered 2003](https://open.spotify.com/track/6D56362n3CmvFqPPqrujqc) | Operation: Mindcrime (Deluxe Edition) | DNA-playlist-exportregistratie |
| Vixen | [Edge Of A Broken Heart](https://open.spotify.com/track/2mEk0VdrbDJ11DBC6Y92mh) | Vixen | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1989

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Blue Murder | [Valley Of The Kings](https://open.spotify.com/track/70BR04tUEx7e3td2ra72X8) | Blue Murder | Masterregistratie |
| D-A-D | [Sleeping My Day Away - 2009 - Remaster](https://open.spotify.com/track/5ZuXgk0enEvv2HlnUe2rj3) | No Fuel Left for the Pilgrims (2009 - Remastered) | Masterregistratie |
| Danger Danger | [Naughty Naughty](https://open.spotify.com/track/53G4MWFNYRx2R22CHwkTrs) | Danger Danger | Masterregistratie |
| Dangerous Toys | [Scared](https://open.spotify.com/track/4Rtx0zFndC7iDhZpIcJbT3) | Dangerous Toys | Masterregistratie |
| Mr. Big | [Wind Me Up - 2009 Remastered Version](https://open.spotify.com/track/4w6cB76PxVcBMwyKval9Tz) | Mr. Big [Expanded] | Masterregistratie |
| Saraya | [Love Has Taken Its Toll](https://open.spotify.com/track/0xoTEpWW6JDmVpnoQo5Oxl) | Saraya | Masterregistratie |
| Skid Row | [18 and Life](https://open.spotify.com/track/0qgrrDnUUhyxpxbBznUnzg) | Skid Row | Masterregistratie |

## DNA JAARBOEK 1989 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Blue Murder | [Valley Of The Kings](https://open.spotify.com/track/70BR04tUEx7e3td2ra72X8) | Blue Murder | DNA-playlist-exportregistratie |
| D-A-D | [Sleeping My Day Away - 2009 - Remaster](https://open.spotify.com/track/5ZuXgk0enEvv2HlnUe2rj3) | No Fuel Left for the Pilgrims (2009 - Remastered) | DNA-playlist-exportregistratie |
| Mr. Big | [Wind Me Up - 2009 Remastered Version](https://open.spotify.com/track/4w6cB76PxVcBMwyKval9Tz) | Mr. Big [Expanded] | DNA-playlist-exportregistratie |
| Saraya | [Love Has Taken Its Toll](https://open.spotify.com/track/0xoTEpWW6JDmVpnoQo5Oxl) | Saraya | DNA-playlist-exportregistratie |
| Skid Row | [18 and Life](https://open.spotify.com/track/0qgrrDnUUhyxpxbBznUnzg) | Skid Row | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1990

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alias | [One More Chance](https://open.spotify.com/track/4AxB2cpS07IqbolZ4VA5B2) | Alias | Masterregistratie |
| Damn Yankees | [Coming of Age](https://open.spotify.com/track/1VMqkvlOqaH0HP0nsj1bx5) | Damn Yankees | Masterregistratie |
| Extreme | [Hole Hearted](https://open.spotify.com/track/454prfBh6yhYBJ05NUGHJ4) | Extreme II - Pornograffitti | Masterregistratie |
| Judas Priest | [Painkiller](https://open.spotify.com/track/0L7zm6afBEtrNKo6C6Gj08) | Painkiller | Masterregistratie |
| Love/Hate | [Blackout In the Red Room](https://open.spotify.com/track/7otFmfukIbDdXFrdLwRHH9) | Blackout In The Red Room | Masterregistratie |
| Lynch Mob | [Wicked Sensation](https://open.spotify.com/track/2Kf3Sy6Tj0T2jl36ghCHpF) | Wicked Sensation | Masterregistratie |
| Talisman | [I'll Be Waiting](https://open.spotify.com/track/7AdMzesYknao6loNAJAq9f) | Talisman | Masterregistratie |
| Warrant | [Cherry Pie](https://open.spotify.com/track/18ESXa5mEm1V4Pkt5GSXWx) | Cherry Pie (Expanded Edition) | Masterregistratie |

## DNA JAARBOEK 1990 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Damn Yankees | [Coming of Age](https://open.spotify.com/track/1VMqkvlOqaH0HP0nsj1bx5) | Damn Yankees | DNA-playlist-exportregistratie |
| Extreme | [Hole Hearted](https://open.spotify.com/track/454prfBh6yhYBJ05NUGHJ4) | Extreme II - Pornograffitti | DNA-playlist-exportregistratie |
| Judas Priest | [Painkiller](https://open.spotify.com/track/0L7zm6afBEtrNKo6C6Gj08) | Painkiller | DNA-playlist-exportregistratie |
| Love/Hate | [Blackout In the Red Room](https://open.spotify.com/track/7otFmfukIbDdXFrdLwRHH9) | Blackout In The Red Room | DNA-playlist-exportregistratie |
| Lynch Mob | [Wicked Sensation](https://open.spotify.com/track/2Kf3Sy6Tj0T2jl36ghCHpF) | Wicked Sensation | DNA-playlist-exportregistratie |
| Talisman | [I'll Be Waiting](https://open.spotify.com/track/7AdMzesYknao6loNAJAq9f) | Talisman | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1991

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bad English | [So This Is Eden](https://open.spotify.com/track/0TZniszdqYe7jxDC0r8oc9) | Backlash | Masterregistratie |
| Kane Roberts | [Dance Little Sister](https://open.spotify.com/track/1iSBHNMOe5URk7nfspifky) | Saints and Sinners | Masterregistratie |
| McQueen Street | [Money](https://open.spotify.com/track/5cOjszw4fhg4weBmGGzI7Z) | McQueen Street | Masterregistratie |
| Shadow King | [Danger in the Dance of Love](https://open.spotify.com/track/50OtUuuYnP0WZVxL8tkl8l) | Shadow King | Masterregistratie |
| Shotgun Messiah | [Heartbreak Blvd.](https://open.spotify.com/track/3e3pkp0mPrSH3RC6qwiRFi) | Second Coming | Masterregistratie |
| Tuff | [The All New Generation](https://open.spotify.com/track/3BeSJIYsMVlnlALz1OLBzS) | What Comes Around Goes Around | Masterregistratie |
| White Lion | [Lights and Thunder](https://open.spotify.com/track/4gpzP5C8xwbgSecdup8AX0) | Mane Attraction | Masterregistratie |

## DNA JAARBOEK 1991 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bad English | [So This Is Eden](https://open.spotify.com/track/0TZniszdqYe7jxDC0r8oc9) | Backlash | DNA-playlist-exportregistratie |
| Lita Ford | [Shot of Poison](https://open.spotify.com/track/7fG4AeCFHXxeXnAXfkmiFk) | Dangerous Curves | DNA-playlist-exportregistratie |
| Shotgun Messiah | [Heartbreak Blvd.](https://open.spotify.com/track/3e3pkp0mPrSH3RC6qwiRFi) | Second Coming | DNA-playlist-exportregistratie |
| White Lion | [Lights and Thunder](https://open.spotify.com/track/4gpzP5C8xwbgSecdup8AX0) | Mane Attraction | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1992

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Fair Warning | [When Love Fails](https://open.spotify.com/track/2Sr3ftfmJmVjUJQNLRhikj) | Fair Warning | Masterregistratie |
| GIANT | [Thunder and Lightning](https://open.spotify.com/track/3A8tmh1KAnThMGLyXpym3e) | Time To Burn | Masterregistratie |
| Hardline | [Takin' Me Down](https://open.spotify.com/track/0ykRm2cMP8ku2qRj5UpEsg) | Double Eclipse | Masterregistratie |
| John Norum | [Still The Night](https://open.spotify.com/track/6fpZe462ozfaI0mWxwSXuQ) | Face The Truth | Masterregistratie |
| Saigon Kick | [All I Want](https://open.spotify.com/track/0zYgM5AQLhBWf17mDvqdEj) | The Lizard | Masterregistratie |
| T-ride | [Luxury Cruiser](https://open.spotify.com/track/0WtuL3WGbH1e0IMjwxUNjW) | T-ride | Masterregistratie |

## DNA JAARBOEK 1992 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Fair Warning | [When Love Fails](https://open.spotify.com/track/2Sr3ftfmJmVjUJQNLRhikj) | Fair Warning | DNA-playlist-exportregistratie |
| GIANT | [Thunder and Lightning](https://open.spotify.com/track/3A8tmh1KAnThMGLyXpym3e) | Time To Burn | DNA-playlist-exportregistratie |
| Hardline | [Takin' Me Down](https://open.spotify.com/track/0ykRm2cMP8ku2qRj5UpEsg) | Double Eclipse | DNA-playlist-exportregistratie |
| John Norum | [Still The Night](https://open.spotify.com/track/6fpZe462ozfaI0mWxwSXuQ) | Face The Truth | DNA-playlist-exportregistratie |
| Saigon Kick | [All I Want](https://open.spotify.com/track/0zYgM5AQLhBWf17mDvqdEj) | The Lizard | DNA-playlist-exportregistratie |
| T-ride | [Luxury Cruiser](https://open.spotify.com/track/0WtuL3WGbH1e0IMjwxUNjW) | T-ride | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1993

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alleycat Scratch | [Take A Bite (Outta Me)](https://open.spotify.com/track/3QsRvvlv90tBrA9NhEF7Mw) | Deadboys In Trash City | Masterregistratie |
| BoysVoice | [Dirty Talks](https://open.spotify.com/track/7Lnrw12Mgk5D2pvsOutGf2) | Dirty Talks | Masterregistratie |
| Romeo's Daughter | [Attracted to the Animal](https://open.spotify.com/track/38NGH3zk3juJ4fz8nfiqmQ) | Delectable | Masterregistratie |

## DNA JAARBOEK 1993 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alleycat Scratch | [Take A Bite (Outta Me)](https://open.spotify.com/track/3QsRvvlv90tBrA9NhEF7Mw) | Deadboys In Trash City | DNA-playlist-exportregistratie |
| Romeo's Daughter | [Attracted to the Animal](https://open.spotify.com/track/38NGH3zk3juJ4fz8nfiqmQ) | Delectable | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1994

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Mennen | [House for Sale](https://open.spotify.com/track/0WuUoxjCbKo7et82ctsynr) | Mennen | Masterregistratie |
| The Almighty | [Jonestown Mind](https://open.spotify.com/track/2UkdyzTbXJfquUZbzE93zY) | Crank | Masterregistratie |

## DNA JAARBOEK 1994 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Mennen | [House for Sale](https://open.spotify.com/track/0WuUoxjCbKo7et82ctsynr) | Mennen | DNA-playlist-exportregistratie |
| The Almighty | [Jonestown Mind](https://open.spotify.com/track/2UkdyzTbXJfquUZbzE93zY) | Crank | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1995

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| The Storm | [I Want to Be the One](https://open.spotify.com/track/1Mv73gnCeXRKWn9ikIjCXA) | Eye of the Storm | Masterregistratie |

## DNA JAARBOEK 1995 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| The Storm | [I Want to Be the One](https://open.spotify.com/track/1Mv73gnCeXRKWn9ikIjCXA) | Eye of the Storm | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1999

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Racer X | [Technical Difficulties](https://open.spotify.com/track/6z6hCyOaWbqYKAlgeA6U3d) | Technical Difficulties | Masterregistratie |

## DNA JAARBOEK 1999  [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Racer X | [Technical Difficulties](https://open.spotify.com/track/6z6hCyOaWbqYKAlgeA6U3d) | Technical Difficulties | DNA-playlist-exportregistratie |

## DNA JAARBOEK 1999 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Racer X | [Technical Difficulties](https://open.spotify.com/track/6z6hCyOaWbqYKAlgeA6U3d) | Technical Difficulties | DNA-playlist-exportregistratie |

## DNA JAARBOEK 2005

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Hardcore Superstar | [We Don't Celebrate Sundays](https://open.spotify.com/track/2j4XBnBAtzDVzJPUMoOyDF) | Hardcore Superstar [Reloaded] | Masterregistratie |

## DNA JAARBOEK 2010

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bad City | [Take Me for a Ride](https://open.spotify.com/track/6iRoX4WbIeY9PQh5MNRPOm) | Welcome to the Wasteland | Masterregistratie |
| Crashdïet | [Generation Wild](https://open.spotify.com/track/0CDzxP82YOmMvstrEJjREo) | Generation Wild | Masterregistratie |
| Crazy Lixx | [Blame It On Love](https://open.spotify.com/track/0MF8I8OUo8kytiOo8aSHYq) | New Religion | Masterregistratie |
| Treat | [The War Is Over](https://open.spotify.com/track/7ny9jmlxRRXRuoPjwvhFQ3) | Coup De Grace | Masterregistratie |
| Unruly Child | [Very First Time](https://open.spotify.com/track/7r74TsYouXHVU8hYuONwbD) | Worlds Collide | Masterregistratie |

## DNA JAARBOEK 2011

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Beggars & Thieves | [We Come Undone](https://open.spotify.com/track/5rO1Jlfdw4r9NxG0ZGtgwc) | We Are the Brokenhearted | Masterregistratie |
| Reckless Love | [Hot](https://open.spotify.com/track/5H6eTrcDfPAHXAHWrR7Q5M) | Animal Attraction | Masterregistratie |

## DNA JAARBOEK 2012

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| DIEMONDS | [Take On The Night](https://open.spotify.com/track/3GaFXK924iUUjFoBXnElOn) | The Bad Pack | Masterregistratie |
| Tyketto | [Faithless](https://open.spotify.com/track/75QZe1Yfpi1hmWIavPNgXV) | Dig in Deep | Masterregistratie |

## DNA JAARBOEK 2016

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Sister | [Carved in Stone](https://open.spotify.com/track/3JRuHFUVAK4cgCx98pv8a8) | Stand up, Forward, March! | Masterregistratie |
| Sixx:A.M. | [We Will Not Go Quietly](https://open.spotify.com/track/2mEIz07NTmDyTMmcGea25i) | Prayers for the Blessed | Masterregistratie |
| ToxicRose | [World of Confusion](https://open.spotify.com/track/1sPj9IM8jxDoMdVzefLKHj) | Total Tranquility | Masterregistratie |

## DNA JAARBOEK 2020

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Harem Scarem | [Aftershock](https://open.spotify.com/track/1eC1DM5oypvu5XIcpkNcaM) | Change the World | Masterregistratie |
| Reb Beach | [Black Magic (2020)](https://open.spotify.com/track/6RRLGF6bkMzZLROp1w94qM) | A View from the Inside | Masterregistratie |
| Vandenberg | [Shadows Of The Night](https://open.spotify.com/track/6VDYMhOnFtPwsSYrVDWEkB) | Shadows Of The Night | Masterregistratie |

## DNA JAARBOEK 2021

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Temple Balls | [What is Dead Never Dies](https://open.spotify.com/track/2kR3dxZDaIHrbI7ZrodAbg) | Pyromide | Masterregistratie |

## DNA JAARBOEK 2022

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| BlackRain | [Untamed](https://open.spotify.com/track/3LxsyDBqaXIYlGIFzKsWLK) | Untamed | Masterregistratie |
| Chez Kane | [Powerzone](https://open.spotify.com/track/16SmBswtkGZPQR2wVcHBDe) | Powerzone | Masterregistratie |

## DNA JAARBOEK 2023

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Cobra Spell | [The Devil Inside of Me](https://open.spotify.com/track/5jL5h2D7ZCKLU0c1FtaTQf) | 666 | Masterregistratie |

## DNA JAARBOEK 2024

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Black Diamonds | [Rock n' Roll Is My Religion](https://open.spotify.com/track/5gmdly7vMnxOvryIp2xe2Q) | Destination Paradise | Masterregistratie |
| Maverick | [Sweet Surrender](https://open.spotify.com/track/2SGHjhlW9KkAWRfhH1zpPf) | Silver Tongue | Masterregistratie |

## 80's Hair Metal Deep Cuts DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Autograph | [Turn up the Radio](https://open.spotify.com/track/7u0b4DthVvd2F2EzCiOx0Z) | Sign In Please | DNA-playlist-exportregistratie |
| Banshee | [Shoot Down The Night](https://open.spotify.com/track/2PpqbO2k43P79UHR0WiMs9) | Race Against Time | DNA-playlist-exportregistratie |
| Brighton Rock | [Young Wild and Free](https://open.spotify.com/track/7EBpncUwlHjLhQTetSLb9O) | Young, Wild And Free | DNA-playlist-exportregistratie |
| Cobra | [Blood On Your Money](https://open.spotify.com/track/7gn5F0ysslKKWQT4epLUiw) | First Strike | DNA-playlist-exportregistratie |
| Coney Hatch | [Some Like It Hot](https://open.spotify.com/track/68oRkANDPCQ6EegIVdzwgx) | Outa Hand | DNA-playlist-exportregistratie |
| Craaft | [Hold Me - Remastered](https://open.spotify.com/track/6XwLmzU8uVVAEoGoXbo6Kc) | Craaft (Remastered) | DNA-playlist-exportregistratie |
| Faster Pussycat | [Babylon](https://open.spotify.com/track/2Mt7VAy2lQLDxRTMtK5Oue) | Faster Pussycat | DNA-playlist-exportregistratie |
| Girlschool | [Race with the Devil](https://open.spotify.com/track/3D8KAebbZgAFdVjTrsNgOI) | Demolition | DNA-playlist-exportregistratie |
| Giuffria | [Do Me Right](https://open.spotify.com/track/1IsKwftNuXKGG9bjNXh7lU) | Giuffria | DNA-playlist-exportregistratie |
| Gorky Park | [Within Your Eyes](https://open.spotify.com/track/35OQaDlJMzWRVpXObP7k9x) | Gorky Park | DNA-playlist-exportregistratie |
| Hawk | [Tell the Truth](https://open.spotify.com/track/70NkJNwVV9syFBKvWL7kU4) | Hawk | DNA-playlist-exportregistratie |
| Headpins | [Don't It Make Ya Feel](https://open.spotify.com/track/1t9huquVeeqLG9j5boQKsw) | Turn It Loud | DNA-playlist-exportregistratie |
| Heavy Pettin | [Sole Survivor](https://open.spotify.com/track/0nT9SvW91vFE6Hht5HDOuk) | Rock Ain’t Dead | DNA-playlist-exportregistratie |
| Kick Axe | [Heavy Metal Shuffle](https://open.spotify.com/track/0EeG0oErkx95uJCt1X0TKu) | Vices | DNA-playlist-exportregistratie |
| Leatherwolf | [The Calling](https://open.spotify.com/track/3jjDOFt8a30PQBrdKy298m) | Leatherwolf | DNA-playlist-exportregistratie |
| Lion | [Never Surrender](https://open.spotify.com/track/2dm3UxRHnKk2aN0oZSwULc) | Dangerous Attraction | DNA-playlist-exportregistratie |
| MASI | [God Promised a Paradise](https://open.spotify.com/track/26od84hy1tlUNh23V7ps8s) | Downtown Dreamers | DNA-playlist-exportregistratie |
| Nitro | [Freight Train](https://open.spotify.com/track/0TmRltDokO878u40MAs20d) | O.F.R. | DNA-playlist-exportregistratie |
| No Exqze | [We Won't Wait 'Till Saturday](https://open.spotify.com/track/1Oq2KuCowdgVMtHkaPqNUJ) | Too Hard To Handle | DNA-playlist-exportregistratie |
| Odin | [Judgement Day](https://open.spotify.com/track/3i6lUB2s5xKblIodo98o3m) | Caution! | DNA-playlist-exportregistratie |
| Q5 | [Pull the Trigger](https://open.spotify.com/track/3sxvhBZLZF8siHd0LyKFyK) | Steel the Light | DNA-playlist-exportregistratie |
| Smashed Gladys | [Lick It into Shape](https://open.spotify.com/track/6HG1C9zt3trYkHAFtRU0lL) | Social Intercourse | DNA-playlist-exportregistratie |
| Stone Fury | [Break Down The Wall](https://open.spotify.com/track/7zevYZAJYMgEUu8rHDaxLR) | Burns Like A Star | DNA-playlist-exportregistratie |
| Streets | [If Love Should Go](https://open.spotify.com/track/3kAiPXqapVgYwOiISlcexP) | 1st | DNA-playlist-exportregistratie |
| Surgin' | [Shot Through the Heart](https://open.spotify.com/track/13q1ko3CqNl6zoyp1SFHex) | When Midnight Comes | DNA-playlist-exportregistratie |
| TKO | [Below the Belt](https://open.spotify.com/track/3oW7unhX6IuWnxBEzw3x1a) | Below the Belt | DNA-playlist-exportregistratie |
| Triumph | [Follow Your Heart](https://open.spotify.com/track/5ElLpqkkBDi1jlXjhg47Od) | Thunder Seven | DNA-playlist-exportregistratie |
| Tuff Luck | [Tonight Tonight](https://open.spotify.com/track/0OiWDnRSHs1nG8YdpMbmfs) | Tuff Luck | DNA-playlist-exportregistratie |
| White Sister | [Can't Say No](https://open.spotify.com/track/5KxtvhL32pEPyDLp5jPOtv) | White Sister | DNA-playlist-exportregistratie |
| Zebra | [As I Said Before](https://open.spotify.com/track/3DQUOnH5OKGjXXnfKGj0UT) | Zebra | DNA-playlist-exportregistratie |

## After Hair Metal DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| 1st Avenue | [Never Too Late To Live](https://open.spotify.com/track/2zPI1s9o6Ech05vU5sdKcN) | Tears & Triumph | DNA-playlist-exportregistratie |
| Alleycat Scratch | [Take A Bite (Outta Me)](https://open.spotify.com/track/3QsRvvlv90tBrA9NhEF7Mw) | Deadboys In Trash City | DNA-playlist-exportregistratie |
| Bad English | [So This Is Eden](https://open.spotify.com/track/0TZniszdqYe7jxDC0r8oc9) | Backlash | DNA-playlist-exportregistratie |
| Badlands | [Healer](https://open.spotify.com/track/0DmtV4MheUFEjEz6XPZsox) | Dusk | DNA-playlist-exportregistratie |
| BoysVoice | [Dirty Talks](https://open.spotify.com/track/7Lnrw12Mgk5D2pvsOutGf2) | Dirty Talks | DNA-playlist-exportregistratie |
| C.J. Snare | [Rock You Tonight](https://open.spotify.com/track/6Db5cayYggggqGq2MIfp65) | Hold Your Fire | DNA-playlist-exportregistratie |
| Cycle Sluts From Hell | [I Wish You Were a Beer](https://open.spotify.com/track/6DeJNBjDKhD3HKlp7CVuGv) | Cycle Sluts From Hell | DNA-playlist-exportregistratie |
| Jester | [Digitalia](https://open.spotify.com/track/1eWxmMqLWfc4wtWk0skw4w) | Digitalia | DNA-playlist-exportregistratie |
| John Norum;Joey Tempest | [We Will Be Strong](https://open.spotify.com/track/1xId1hoQ0mfYl610t5VtPW) | Face The Truth | DNA-playlist-exportregistratie |
| Mitch Malloy | [Anything at All](https://open.spotify.com/track/3AmZlfEuOqyoOfgqrbFPkh) | Mitch Malloy (Remastered) | DNA-playlist-exportregistratie |
| Racer X | [Technical Difficulties](https://open.spotify.com/track/6z6hCyOaWbqYKAlgeA6U3d) | Technical Difficulties | DNA-playlist-exportregistratie |
| Romeo's Daughter | [Attracted to the Animal](https://open.spotify.com/track/38NGH3zk3juJ4fz8nfiqmQ) | Delectable | DNA-playlist-exportregistratie |
| Roxxi | [Playin' Rough](https://open.spotify.com/track/06MvukPPTGNvPl7D9L2wCb) | Drive It to Ya Hard | DNA-playlist-exportregistratie |
| Saigon Kick | [All I Want](https://open.spotify.com/track/0zYgM5AQLhBWf17mDvqdEj) | The Lizard | DNA-playlist-exportregistratie |
| Shadow King | [Danger in the Dance of Love](https://open.spotify.com/track/50OtUuuYnP0WZVxL8tkl8l) | Shadow King | DNA-playlist-exportregistratie |
| Sven Gali | [Tie Dyed Skies](https://open.spotify.com/track/0AXNPM5EN8lkVsYMA7vpMS) | Sven Gali | DNA-playlist-exportregistratie |
| T-ride | [Luxury Cruiser](https://open.spotify.com/track/0WtuL3WGbH1e0IMjwxUNjW) | T-ride | DNA-playlist-exportregistratie |
| The Storm | [I Want to Be the One](https://open.spotify.com/track/1Mv73gnCeXRKWn9ikIjCXA) | Eye of the Storm | DNA-playlist-exportregistratie |
| Union | [Love (I Don't Need It Anymore)](https://open.spotify.com/track/5RpmKN1BxLMJGRanfhwmnj) | Union | DNA-playlist-exportregistratie |
| Whitecross | [Enough Is Enough](https://open.spotify.com/track/4ZdRpscrIpqA24a8BrnWoI) | Whitecross | DNA-playlist-exportregistratie |

## Alternative Metal DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Hëssler | [Waste Away](https://open.spotify.com/track/0NkL2P7XkS3q2hSuYY6dyY) | Comes With the Territory | Masterregistratie |

## Alternative Metal DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Hëssler | [Waste Away](https://open.spotify.com/track/0NkL2P7XkS3q2hSuYY6dyY) | Comes With the Territory | DNA-playlist-exportregistratie |

## Arena Rock DNA  [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alice Cooper | [Elected](https://open.spotify.com/track/32wcgD2iId0smNDyjUNvd8) | Billion Dollar Babies | DNA-playlist-exportregistratie |
| KISS | [Tears Are Falling](https://open.spotify.com/track/1hxt3chzYLAzS4NmSSi5A3) | Asylum | DNA-playlist-exportregistratie |
| Night Ranger | [Running out of Time](https://open.spotify.com/track/4ZqPN606YREag4P3xvUaXS) | Don't Let Up | DNA-playlist-exportregistratie |
| Van Halen | [And the Cradle Will Rock... - 2015 Remaster](https://open.spotify.com/track/4MM0jT9z9m7VFiusFrGJ8C) | Women and Children First (Remastered) | DNA-playlist-exportregistratie |
| Whitesnake | [Still of the Night - 2018 Remaster](https://open.spotify.com/track/7AtwQRLPdttsxcLM5tPL0t) | Whitesnake (2018 Remaster) | DNA-playlist-exportregistratie |

## Blues Rock DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Shabby Trick | [Rnr Raiser](https://open.spotify.com/track/0iOoHU4vuzTCcy4uXlXUzU) | R'n'r Raiser | Masterregistratie |

## Blues Rock DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Shabby Trick | [Rnr Raiser](https://open.spotify.com/track/0iOoHU4vuzTCcy4uXlXUzU) | R'n'r Raiser | DNA-playlist-exportregistratie |

## Deep Purple DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Asphalt Ballet | [Soul Survive](https://open.spotify.com/track/29K89Zrp5kQPvekUm82LxV) | Asphalt Ballet | Masterregistratie |
| Black 'N Blue | [Hold On To 18](https://open.spotify.com/track/154rHCEahCbCIeCPc2VnI6) | Black N Blue | Masterregistratie |
| BlackRain | [Untamed](https://open.spotify.com/track/3LxsyDBqaXIYlGIFzKsWLK) | Untamed | Masterregistratie |
| Blue Murder | [Valley Of The Kings](https://open.spotify.com/track/70BR04tUEx7e3td2ra72X8) | Blue Murder | Masterregistratie |
| Crashdïet | [Generation Wild](https://open.spotify.com/track/0CDzxP82YOmMvstrEJjREo) | Generation Wild | Masterregistratie |
| Dirty Looks | [Cool from the Wire](https://open.spotify.com/track/6QAVmVPIW9GaGZcCqtYxSv) | Cool From The Wire | Masterregistratie |
| Enuff Z'Nuff | [New Thing](https://open.spotify.com/track/00iVYbSh1B77akx1ITNWUL) | Enuff Z'Nuff | Masterregistratie |
| Fastway | [Say What You Will](https://open.spotify.com/track/08nVwMJvWeJwwc9pSd74wO) | FASTWAY | Masterregistratie |
| Guns N' Roses | [Welcome To The Jungle](https://open.spotify.com/track/0bVtevEgtDIeRjCJbK3Lmv) | Appetite For Destruction | Masterregistratie |
| Hericane Alice | [Tear the House Down](https://open.spotify.com/track/0NSjjwyd40Wb5NOXHzNpGJ) | Tear The House Down | Masterregistratie |
| Jettblack | [Dangerzone](https://open.spotify.com/track/32VYaroYozIBUzzphSr0Xh) | Two Hot Girls | Masterregistratie |
| John Sykes | [Cautionary Warning](https://open.spotify.com/track/0DQre1WvAlGHKpLFTEf3Hp) | 20th Century | Masterregistratie |
| Keel | [Speed Demon](https://open.spotify.com/track/4dYQ2i4yH70kKhUXMypICn) | The Right To Rock | Masterregistratie |
| Little Caesar | [Vegas](https://open.spotify.com/track/6fhCWLu21nVWg4ObkOyxcn) | Eight | Masterregistratie |
| Lynch Mob | [Wicked Sensation](https://open.spotify.com/track/2Kf3Sy6Tj0T2jl36ghCHpF) | Wicked Sensation | Masterregistratie |
| Mädhouse | [Boom Boob Shaker](https://open.spotify.com/track/1CYYgH2R1hFXN9R7hpGYHH) | Money Talks Bullshit Walks | Masterregistratie |
| Takara | [When Darkness Falls](https://open.spotify.com/track/2NlJYagrPCWEDZTos1xQCV) | Taste Of Heaven | Masterregistratie |
| Talisman | [I'll Be Waiting](https://open.spotify.com/track/7AdMzesYknao6loNAJAq9f) | Talisman | Masterregistratie |
| The Defiants | [19 Summertime](https://open.spotify.com/track/0wdepryHrbTGXF7UmRwmBm) | Drive | Masterregistratie |
| Unruly Child | [Very First Time](https://open.spotify.com/track/7r74TsYouXHVU8hYuONwbD) | Worlds Collide | Masterregistratie |
| Vandenberg | [Shadows Of The Night](https://open.spotify.com/track/6VDYMhOnFtPwsSYrVDWEkB) | Shadows Of The Night | Masterregistratie |
| Victory | [Rising Force](https://open.spotify.com/track/1V5mmHT7oZGuNlQXP5lz9W) | Gods of Tomorrow | Masterregistratie |
| W.E.T. | [One Final Kiss](https://open.spotify.com/track/3wdqtNP07d6o281NT7fRpu) | Retransmission | Masterregistratie |
| War Babies | [Care (Man I Just Don't)](https://open.spotify.com/track/2HoYIvgDyRXDyvdirUfCXB) | War Babies | Masterregistratie |
| Wild Horses | [Cool Me Down](https://open.spotify.com/track/6ae5BKe2d3WeqQjq9a2tmL) | Bareback | Masterregistratie |
| Wildness | [Crucified](https://open.spotify.com/track/16hzN78VdK2CxVt7KCWTrw) | Crucified | Masterregistratie |

## Deep Purple DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Asphalt Ballet | [Soul Survive](https://open.spotify.com/track/29K89Zrp5kQPvekUm82LxV) | Asphalt Ballet | DNA-playlist-exportregistratie |
| Black 'N Blue | [Hold On To 18](https://open.spotify.com/track/154rHCEahCbCIeCPc2VnI6) | Black N Blue | DNA-playlist-exportregistratie |
| BlackRain | [Untamed](https://open.spotify.com/track/3LxsyDBqaXIYlGIFzKsWLK) | Untamed | DNA-playlist-exportregistratie |
| Blue Murder | [Valley Of The Kings](https://open.spotify.com/track/70BR04tUEx7e3td2ra72X8) | Blue Murder | DNA-playlist-exportregistratie |
| Crashdïet | [Generation Wild](https://open.spotify.com/track/0CDzxP82YOmMvstrEJjREo) | Generation Wild | DNA-playlist-exportregistratie |
| Dirty Looks | [Cool from the Wire](https://open.spotify.com/track/6QAVmVPIW9GaGZcCqtYxSv) | Cool From The Wire | DNA-playlist-exportregistratie |
| Enuff Z'Nuff | [New Thing](https://open.spotify.com/track/00iVYbSh1B77akx1ITNWUL) | Enuff Z'Nuff | DNA-playlist-exportregistratie |
| Fastway | [Say What You Will](https://open.spotify.com/track/08nVwMJvWeJwwc9pSd74wO) | FASTWAY | DNA-playlist-exportregistratie |
| Guns N' Roses | [Welcome To The Jungle](https://open.spotify.com/track/0bVtevEgtDIeRjCJbK3Lmv) | Appetite For Destruction | DNA-playlist-exportregistratie |
| Hericane Alice | [Tear the House Down](https://open.spotify.com/track/0NSjjwyd40Wb5NOXHzNpGJ) | Tear The House Down | DNA-playlist-exportregistratie |
| Jettblack | [Dangerzone](https://open.spotify.com/track/32VYaroYozIBUzzphSr0Xh) | Two Hot Girls | DNA-playlist-exportregistratie |
| John Sykes | [Cautionary Warning](https://open.spotify.com/track/0DQre1WvAlGHKpLFTEf3Hp) | 20th Century | DNA-playlist-exportregistratie |
| Keel | [Speed Demon](https://open.spotify.com/track/4dYQ2i4yH70kKhUXMypICn) | The Right To Rock | DNA-playlist-exportregistratie |
| Little Caesar | [Vegas](https://open.spotify.com/track/6fhCWLu21nVWg4ObkOyxcn) | Eight | DNA-playlist-exportregistratie |
| Lynch Mob | [Wicked Sensation](https://open.spotify.com/track/2Kf3Sy6Tj0T2jl36ghCHpF) | Wicked Sensation | DNA-playlist-exportregistratie |
| Mädhouse | [Boom Boob Shaker](https://open.spotify.com/track/1CYYgH2R1hFXN9R7hpGYHH) | Money Talks Bullshit Walks | DNA-playlist-exportregistratie |
| Takara | [When Darkness Falls](https://open.spotify.com/track/2NlJYagrPCWEDZTos1xQCV) | Taste Of Heaven | DNA-playlist-exportregistratie |
| Talisman | [I'll Be Waiting](https://open.spotify.com/track/7AdMzesYknao6loNAJAq9f) | Talisman | DNA-playlist-exportregistratie |
| The Defiants | [19 Summertime](https://open.spotify.com/track/0wdepryHrbTGXF7UmRwmBm) | Drive | DNA-playlist-exportregistratie |
| Unruly Child | [Very First Time](https://open.spotify.com/track/7r74TsYouXHVU8hYuONwbD) | Worlds Collide | DNA-playlist-exportregistratie |
| Vandenberg | [Shadows Of The Night](https://open.spotify.com/track/6VDYMhOnFtPwsSYrVDWEkB) | Shadows Of The Night | DNA-playlist-exportregistratie |
| Victory | [Rising Force](https://open.spotify.com/track/1V5mmHT7oZGuNlQXP5lz9W) | Gods of Tomorrow | DNA-playlist-exportregistratie |
| W.E.T. | [One Final Kiss](https://open.spotify.com/track/3wdqtNP07d6o281NT7fRpu) | Retransmission | DNA-playlist-exportregistratie |
| War Babies | [Care (Man I Just Don't)](https://open.spotify.com/track/2HoYIvgDyRXDyvdirUfCXB) | War Babies | DNA-playlist-exportregistratie |
| Wild Horses | [Cool Me Down](https://open.spotify.com/track/6ae5BKe2d3WeqQjq9a2tmL) | Bareback | DNA-playlist-exportregistratie |
| Wildness | [Crucified](https://open.spotify.com/track/16hzN78VdK2CxVt7KCWTrw) | Crucified | DNA-playlist-exportregistratie |

## Ghost DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| 220 Volt | [The Harder They Come](https://open.spotify.com/track/3Q0fmbHtdUVu3uZI2TonUn) | Eye to Eye | Masterregistratie |
| Alcatrazz | [God Blessed Video](https://open.spotify.com/track/2nsrALjWaiP5WqyzIkJlHe) | Disturbing The Peace | Masterregistratie |
| Axe | [Young Hearts](https://open.spotify.com/track/6Dvy24CR0KZjjsQIqilyxL) | Nemesis | Masterregistratie |
| BAD HABIT Sweden | [Another Night](https://open.spotify.com/track/1yFU4PX34ya2lt9urs4XYu) | Revolution (Re-Mastered) | Masterregistratie |
| Bai Bang | [Raise Your Hands](https://open.spotify.com/track/0jJBQ5bqJT7mzirXnAoSNk) | All Around the World | Masterregistratie |
| Bangalore Choir | [Angel in Black](https://open.spotify.com/track/280ibzeGZs86VRH7iejBtw) | On Target | Masterregistratie |
| Baton Rouge | [Walks Like a Woman](https://open.spotify.com/track/1mSkQolHBx2wqFNwKnFCnA) | Shake Your Soul | Masterregistratie |
| Pretty Maids | [Future World](https://open.spotify.com/track/2v9855tCBy97Qp4BmMZscS) | Future World | Masterregistratie |
| Queensrÿche | [The Needle Lies - Remastered 2003](https://open.spotify.com/track/6D56362n3CmvFqPPqrujqc) | Operation: Mindcrime (Deluxe Edition) | Masterregistratie |
| Temple Balls | [What is Dead Never Dies](https://open.spotify.com/track/2kR3dxZDaIHrbI7ZrodAbg) | Pyromide | Masterregistratie |

## Ghost DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| 220 Volt | [The Harder They Come](https://open.spotify.com/track/3Q0fmbHtdUVu3uZI2TonUn) | Eye to Eye | DNA-playlist-exportregistratie |
| Alcatrazz | [God Blessed Video](https://open.spotify.com/track/2nsrALjWaiP5WqyzIkJlHe) | Disturbing The Peace | DNA-playlist-exportregistratie |
| Axe | [Young Hearts](https://open.spotify.com/track/6Dvy24CR0KZjjsQIqilyxL) | Nemesis | DNA-playlist-exportregistratie |
| BAD HABIT Sweden | [Another Night](https://open.spotify.com/track/1yFU4PX34ya2lt9urs4XYu) | Revolution (Re-Mastered) | DNA-playlist-exportregistratie |
| Bai Bang | [Raise Your Hands](https://open.spotify.com/track/0jJBQ5bqJT7mzirXnAoSNk) | All Around the World | DNA-playlist-exportregistratie |
| Baton Rouge | [Walks Like a Woman](https://open.spotify.com/track/1mSkQolHBx2wqFNwKnFCnA) | Shake Your Soul | DNA-playlist-exportregistratie |
| Pretty Maids | [Future World](https://open.spotify.com/track/2v9855tCBy97Qp4BmMZscS) | Future World | DNA-playlist-exportregistratie |
| Queensrÿche | [The Needle Lies - Remastered 2003](https://open.spotify.com/track/6D56362n3CmvFqPPqrujqc) | Operation: Mindcrime (Deluxe Edition) | DNA-playlist-exportregistratie |
| Temple Balls | [What is Dead Never Dies](https://open.spotify.com/track/2kR3dxZDaIHrbI7ZrodAbg) | Pyromide | DNA-playlist-exportregistratie |

## Glam Rock DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Hanoi Rocks | [Up Around the Bend](https://open.spotify.com/track/58jMdhU11g7JdvrBSlaIk2) | Two Steps From The Move | DNA-playlist-exportregistratie |
| Roxx Gang | [Scratch My Back](https://open.spotify.com/track/6hP3lbXemPQLx6QiKJ1z5v) | Bodacious Ta Tas: The Best of Roxx Gang | DNA-playlist-exportregistratie |
| Steel Panther | [Death To All But Metal](https://open.spotify.com/track/0S6LJ0NSDynIsCptVBZdfy) | Feel The Steel | DNA-playlist-exportregistratie |
| The Dogs D'Amour | [I Don't Want You to Go](https://open.spotify.com/track/4ABjFaFQHJN6gW2vx4D3lf) | In The Dynamite Jet Saloon | DNA-playlist-exportregistratie |
| Twisted Sister | [I Wanna Rock](https://open.spotify.com/track/70Z9t1qhytWtG4cCmmi7mU) | Stay Hungry | DNA-playlist-exportregistratie |

## Hair Metal DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Aldo Nova | [Fantasy](https://open.spotify.com/track/1zrba5qe6xkC84AlbXNa6u) | Aldo Nova | DNA-playlist-exportregistratie |
| Bon Jovi | [Runaway](https://open.spotify.com/track/0X1sqQ652p1sceKM2nJlIJ) | Bon Jovi | DNA-playlist-exportregistratie |
| Cats In Boots | [Shotgun Sally](https://open.spotify.com/track/18n5kMWdrmrEOuh9Qnh2Wf) | Kicked And Klawed | DNA-playlist-exportregistratie |
| D'Molls | [My Life](https://open.spotify.com/track/2Dd0cU8vbBl38j2RBLhLAm) | Warped | DNA-playlist-exportregistratie |
| Def Leppard | [Animal](https://open.spotify.com/track/4qjscZh4jfhkpcQG4ZQfi2) | Hysteria | DNA-playlist-exportregistratie |
| Every Mothers Nightmare | [Walls Come Down](https://open.spotify.com/track/779PvwBHrHjORk3lC3AMPt) | Every Mother's Nightmare | DNA-playlist-exportregistratie |
| Gasoline Queen | [Broke, Cursed and Damned](https://open.spotify.com/track/09qJb7SQ5grUFEn58NawLo) | Gas for the Underclass | DNA-playlist-exportregistratie |
| Hardcore Superstar | [We Don't Celebrate Sundays](https://open.spotify.com/track/2j4XBnBAtzDVzJPUMoOyDF) | Hardcore Superstar [Reloaded] | DNA-playlist-exportregistratie |
| Helix | [Rock You](https://open.spotify.com/track/2sd8DUzBIaNBzkgEPGsHV6) | Walkin' The Razor's Edge | DNA-playlist-exportregistratie |
| King Kobra | [Iron Eagle (Never Say Die)](https://open.spotify.com/track/3tD4AR8vbvM0b9X09YBYE0) | Thrill Of A Lifetime | DNA-playlist-exportregistratie |
| Lipz | [Get It On](https://open.spotify.com/track/0ti0aAg5xZd7JW8KGU9ROX) | Scaryman | DNA-playlist-exportregistratie |
| Love/Hate | [Blackout In the Red Room](https://open.spotify.com/track/7otFmfukIbDdXFrdLwRHH9) | Blackout In The Red Room | DNA-playlist-exportregistratie |
| Michael Monroe | [Dead, Jail Or Rock 'N' Roll](https://open.spotify.com/track/3hMxAPl8lko0bnq7C0qPbW) | Not Fakin' It | DNA-playlist-exportregistratie |
| Nelson | [After The Rain - Remastered 2017](https://open.spotify.com/track/3VWGHiQO7fArciqoKB2DSx) | After The Rain (Remastered) | DNA-playlist-exportregistratie |
| Poison | [Talk Dirty To Me](https://open.spotify.com/track/01R0Xdwje645C6xFCnMRvm) | Look What The Cat Dragged In | DNA-playlist-exportregistratie |
| Ratt | [You're in Love](https://open.spotify.com/track/3D3lmTEhuWaunO1yxpYPD8) | Invasion of Your Privacy | DNA-playlist-exportregistratie |
| Reckless Love | [Hot](https://open.spotify.com/track/5H6eTrcDfPAHXAHWrR7Q5M) | Animal Attraction | DNA-playlist-exportregistratie |
| Salty Dog | [Come Along](https://open.spotify.com/track/37RCRKa0LpuR6joRsPl0sO) | Every Dog Has Its Day | DNA-playlist-exportregistratie |
| Scorpions | [Rock You Like a Hurricane - 2015 - Remaster](https://open.spotify.com/track/2fICdpdRotwfmGYzvs8Ngf) | Love At First Sting (Deluxe Edition) | DNA-playlist-exportregistratie |
| Shotgun Messiah | [Heartbreak Blvd.](https://open.spotify.com/track/3e3pkp0mPrSH3RC6qwiRFi) | Second Coming | DNA-playlist-exportregistratie |
| Sixx:A.M. | [We Will Not Go Quietly](https://open.spotify.com/track/2mEIz07NTmDyTMmcGea25i) | Prayers for the Blessed | DNA-playlist-exportregistratie |
| STEELHEART | [Everybody Loves Eileen](https://open.spotify.com/track/6J3BPR0jqAAf836i1j9g1v) | Steelheart | DNA-playlist-exportregistratie |
| Stryper | [Calling on You](https://open.spotify.com/track/6zhvmGUoS80bmWBg45b8Wl) | ONE Christian Music's #1 Charting Rock Hits V1 | DNA-playlist-exportregistratie |
| Suicide Bombers | [So Bad](https://open.spotify.com/track/5drLgudNh1wkMD3kvtUyiq) | Murder Couture | DNA-playlist-exportregistratie |
| The Darkness | [One Way Ticket](https://open.spotify.com/track/44x9GdJsYmbaYRBm8ROyfL) | One Way Ticket to Hell... and Back | DNA-playlist-exportregistratie |
| The Last Vegas | [Raw Dog](https://open.spotify.com/track/7pHiMsZHv3nGLOIQvZHfhO) | Seal the Deal | DNA-playlist-exportregistratie |
| Tigertailz | [Love Bomb Baby](https://open.spotify.com/track/1PqfpW21YPno7nUzlVHyFv) | Bezerk | DNA-playlist-exportregistratie |
| ToxicRose | [World of Confusion](https://open.spotify.com/track/1sPj9IM8jxDoMdVzefLKHj) | Total Tranquility | DNA-playlist-exportregistratie |
| Trixter | [One in a Million](https://open.spotify.com/track/0MiEhQOPw9IlArjnSLe84w) | Alive in Japan | DNA-playlist-exportregistratie |
| Tuff | [The All New Generation](https://open.spotify.com/track/3BeSJIYsMVlnlALz1OLBzS) | What Comes Around Goes Around | DNA-playlist-exportregistratie |
| Vains Of Jenna | [Enemy In Me](https://open.spotify.com/track/3JP7RGrx1ORUsx2Idyr0Ba) | The Art of Telling Lies | DNA-playlist-exportregistratie |
| Wrathchild | [Stakk Attakk](https://open.spotify.com/track/0hk8UzMwmbxkDyLHLlPGQm) | Stakk Attakk | DNA-playlist-exportregistratie |

## Hair Metal Gekkies DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Aviator | [Front Line](https://open.spotify.com/track/5MmFMKe0VGaqlQ33KNy0KY) | Aviator | DNA-playlist-exportregistratie |
| Bad Boy Eddy | [Rad Ruby](https://open.spotify.com/track/3KwjghB9DAht28mPX9Onw2) | Over the Top (Deluxe Edition) | DNA-playlist-exportregistratie |
| Big Bang Babies | [Everybody Needs A Hero](https://open.spotify.com/track/3HUCwifeBQMMBKUPxCaVt2) | 3 Chords And The Truth | DNA-playlist-exportregistratie |
| Child's Play | [Good Ol' Rock And Roll](https://open.spotify.com/track/3Csv0MN00Iv3XH9d418JaQ) | Rat Race | DNA-playlist-exportregistratie |
| CHINA | [In The Middle Of The Night](https://open.spotify.com/track/3fgSnDCK05NDXlDJX0jArO) | Sign In The Sky | DNA-playlist-exportregistratie |
| Cold Sweat | [Let's Make Love Tonight](https://open.spotify.com/track/0Md3WqXa9vCXWOVcvU94lA) | Break Out | DNA-playlist-exportregistratie |
| Electric Angels | [Rattlesnake Kisses](https://open.spotify.com/track/6wUkj9fhKcMkUlSwcC3xd0) | Electric Angels | DNA-playlist-exportregistratie |
| Heavy Bones | [The Hand That Feeds](https://open.spotify.com/track/0bwEjc3wdAY8mDdsbnRxcv) | Heavy Bones | DNA-playlist-exportregistratie |
| Kik Tracee | [Don't Need Rules](https://open.spotify.com/track/5AOPC7iW1kj8uGtT4CmcQj) | No Rules | DNA-playlist-exportregistratie |
| London | [Russian Winter](https://open.spotify.com/track/1GJo4SLR73bNNOIhAg4DJn) | Playa Del Rock | DNA-playlist-exportregistratie |
| Lord Tracy | [Jinx](https://open.spotify.com/track/4rcLZKHHudIqWEof4wC4q9) | Porn Again | DNA-playlist-exportregistratie |
| McQueen Street | [Money](https://open.spotify.com/track/5cOjszw4fhg4weBmGGzI7Z) | McQueen Street | DNA-playlist-exportregistratie |
| Rock City Angels | [Tear It Up](https://open.spotify.com/track/0tZKNC75qI6S0IuQayXS3P) | Midnight Confessions | DNA-playlist-exportregistratie |
| Roko | [One Night Stand](https://open.spotify.com/track/17ZHoNeu3j9wPdaCA5OmEi) | Roko | DNA-playlist-exportregistratie |
| Rox Diamond | [Heart of Mine](https://open.spotify.com/track/60VvnoCXoJ0P6RJki3QO21) | Rox Diamond | DNA-playlist-exportregistratie |
| Roxy Blue | [Too Hot To Handle](https://open.spotify.com/track/1vmTDGLj4FteG2Jn4NTazK) | Want Some? | DNA-playlist-exportregistratie |
| Saints & Sinners | [Shake](https://open.spotify.com/track/4gjFeCBHRvUQluaJgUsDCh) | Saints & Sinners | DNA-playlist-exportregistratie |
| Salems Lott | [When Heaven Comes Down](https://open.spotify.com/track/5y4qyckPkYBsbM1Oapkpsm) | Mask of Morality | DNA-playlist-exportregistratie |
| Sea Hags | [Half The Way Valley](https://open.spotify.com/track/55Qc3ftOxf63hZn8XJElLF) | Sea Hags | DNA-playlist-exportregistratie |
| Signal | [Arms Of A Stranger](https://open.spotify.com/track/3gdnbF4xI6Lkql4vbFlZrM) | Loud & Clear | DNA-playlist-exportregistratie |
| Slik Toxik | [Twenty Something](https://open.spotify.com/track/7colHMaVuGXqzdA7gikLK7) | Irrelevant | DNA-playlist-exportregistratie |
| Spiders & Snakes | [California Slide](https://open.spotify.com/track/1mdIPntJsgZbuq3Vrg5CsC) | Arachnomania | DNA-playlist-exportregistratie |
| Sweet F.A. | [Hard Drivin' Man](https://open.spotify.com/track/3oMvf57iwFSz4iTs7FxrXl) | The Lost Tapes | DNA-playlist-exportregistratie |
| Tattoo Rodeo | [Shotgun Johnny](https://open.spotify.com/track/3pNjmuIGxxQYNESienwpfy) | Rode Hard - Put Away Wet | DNA-playlist-exportregistratie |
| The Throbs | [Come Down Sister](https://open.spotify.com/track/31Eino4YwuoQlORmBExbdK) | The Language Of Thieves And Vagabonds | DNA-playlist-exportregistratie |
| Tora Tora | [Amnesia](https://open.spotify.com/track/6woSuDAzfcyogEKqzISMk9) | Wild America | DNA-playlist-exportregistratie |
| Trouble Tribe | [(Angel With A) Devil's Kiss](https://open.spotify.com/track/6Y3CVmC4P0P0sDcrRSzr4L) | Trouble Tribe | DNA-playlist-exportregistratie |
| Wild Boyz | [I Don't Wanna Cry No More](https://open.spotify.com/track/2lPD9LITr762cHFJQundXM) | I Don't Wanna Cry No More | DNA-playlist-exportregistratie |
| Wild Machine | [Straight to Hell](https://open.spotify.com/track/2wfif2vUzvmTsWzFTf4N5B) | II | DNA-playlist-exportregistratie |
| Zinatra | [Two Sides of Love](https://open.spotify.com/track/3JqYYx1tjKYlpnbSIm8Hc1) | Rockumentary Part 2 | DNA-playlist-exportregistratie |

## Iron Maiden DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Iconic | [Fast as You Can](https://open.spotify.com/track/17UNYdDQKW0caFvTMaUdGi) | Second Skin | Masterregistratie |
| Jaded Heart | [Dreams You'll Never See](https://open.spotify.com/track/7hGpn5Dulu4fN1jjrAGToL) | Helluva Time | Masterregistratie |
| Legs Diamond | [Stage Fright](https://open.spotify.com/track/5gyUWuwyWTJuxWVen6CFx9) | Legs Diamond | Masterregistratie |
| Maverick | [Sweet Surrender](https://open.spotify.com/track/2SGHjhlW9KkAWRfhH1zpPf) | Silver Tongue | Masterregistratie |
| McAuley Schenker Group | [What Happens To Me](https://open.spotify.com/track/0n6Tc3UXJXneAgDWWQMO5u) | MSG | Masterregistratie |
| Mennen | [House for Sale](https://open.spotify.com/track/0WuUoxjCbKo7et82ctsynr) | Mennen | Masterregistratie |
| Night Ranger | [Running out of Time](https://open.spotify.com/track/4ZqPN606YREag4P3xvUaXS) | Don't Let Up | Masterregistratie |
| Osukaru | [Shut It Out](https://open.spotify.com/track/1jXE1kW6nIXXteOiyxR6CF) | Starbound | Masterregistratie |
| Paul Laine | [We Are the Young](https://open.spotify.com/track/0cT1ifeOtwbuUasO1kFXSn) | Stick It In Your Ear | Masterregistratie |
| Sandness | [London](https://open.spotify.com/track/5F82o6qYX3SgFNTWIwOcid) | Untamed | Masterregistratie |
| Skagarack | [I'm Alone](https://open.spotify.com/track/5DriplwmjPuGdESyrlFlAQ) | Skagarack | Masterregistratie |
| Strangeways | [Every Time You Cry](https://open.spotify.com/track/4iz0WrlKRMh8tW6DcauSaA) | Walk In The Fire (Expanded Edition) | Masterregistratie |

## Iron Maiden DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Iconic | [Fast as You Can](https://open.spotify.com/track/17UNYdDQKW0caFvTMaUdGi) | Second Skin | DNA-playlist-exportregistratie |
| Jaded Heart | [Dreams You'll Never See](https://open.spotify.com/track/7hGpn5Dulu4fN1jjrAGToL) | Helluva Time | DNA-playlist-exportregistratie |
| Legs Diamond | [Stage Fright](https://open.spotify.com/track/5gyUWuwyWTJuxWVen6CFx9) | Legs Diamond | DNA-playlist-exportregistratie |
| Maverick | [Sweet Surrender](https://open.spotify.com/track/2SGHjhlW9KkAWRfhH1zpPf) | Silver Tongue | DNA-playlist-exportregistratie |
| McAuley Schenker Group | [What Happens To Me](https://open.spotify.com/track/0n6Tc3UXJXneAgDWWQMO5u) | MSG | DNA-playlist-exportregistratie |
| Mennen | [House for Sale](https://open.spotify.com/track/0WuUoxjCbKo7et82ctsynr) | Mennen | DNA-playlist-exportregistratie |
| Night Ranger | [Running out of Time](https://open.spotify.com/track/4ZqPN606YREag4P3xvUaXS) | Don't Let Up | DNA-playlist-exportregistratie |
| Osukaru | [Shut It Out](https://open.spotify.com/track/1jXE1kW6nIXXteOiyxR6CF) | Starbound | DNA-playlist-exportregistratie |
| Paul Laine | [We Are the Young](https://open.spotify.com/track/0cT1ifeOtwbuUasO1kFXSn) | Stick It In Your Ear | DNA-playlist-exportregistratie |
| Sandness | [London](https://open.spotify.com/track/5F82o6qYX3SgFNTWIwOcid) | Untamed | DNA-playlist-exportregistratie |
| Skagarack | [I'm Alone](https://open.spotify.com/track/5DriplwmjPuGdESyrlFlAQ) | Skagarack | DNA-playlist-exportregistratie |
| Strangeways | [Every Time You Cry](https://open.spotify.com/track/4iz0WrlKRMh8tW6DcauSaA) | Walk In The Fire (Expanded Edition) | DNA-playlist-exportregistratie |

## KISS DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alice Cooper | [Elected](https://open.spotify.com/track/32wcgD2iId0smNDyjUNvd8) | Billion Dollar Babies | Masterregistratie |
| Babylon A.D. | [Bang Go the Bells](https://open.spotify.com/track/3KcU6uoStAqQ0kIbCqb17g) | Bang Go the Bells | Masterregistratie |
| BAD MOON RISING | [Full Moon Fever](https://open.spotify.com/track/2sFjEYfvb8ljjPzYymr6q6) | Bad Moon Rising | Masterregistratie |
| Hurricane | [I'm On To You](https://open.spotify.com/track/1SSl0W9w6qnWDn3RuS8iWs) | Over The Edge | Masterregistratie |
| ICON | [Danger Calling](https://open.spotify.com/track/0oLhwxvNHtxeeJfkcdVufF) | Night Of The Crime | Masterregistratie |
| John Norum | [Still The Night](https://open.spotify.com/track/6fpZe462ozfaI0mWxwSXuQ) | Face The Truth | Masterregistratie |
| Kane Roberts | [Dance Little Sister](https://open.spotify.com/track/1iSBHNMOe5URk7nfspifky) | Saints and Sinners | Masterregistratie |
| Kingdom Come | [Who Do You Love](https://open.spotify.com/track/7yT8LTMsVjIrEQUvIOuSPH) | In Your Face | Masterregistratie |
| KISS | [Tears Are Falling](https://open.spotify.com/track/1hxt3chzYLAzS4NmSSi5A3) | Asylum | Masterregistratie |
| Lee Aaron | [Metal Queen](https://open.spotify.com/track/4b3UYHaYfUb1V546Chw4to) | Metal Queen | Masterregistratie |
| Lillian Axe | [Show A Little Love](https://open.spotify.com/track/4FsAlfZHssqD8BXHANHLqP) | Love + War | Masterregistratie |
| LIONSHEART | [Can't Believe](https://open.spotify.com/track/5h7ymBzWhlHhMTwoqA4ShA) | Lionsheart | Masterregistratie |
| Masquerade | [Gimme All Your Love](https://open.spotify.com/track/2tQQbnFVWTkgtrFHiK4vR2) | Masquerade (Deluxe Edition) | Masterregistratie |
| Melidian | [Ready to Rock](https://open.spotify.com/track/7qIwJEBAIDoMjXeSRMAKKM) | Lost in the Wild | Masterregistratie |
| Pink Cream 69 | [Walls Come Down](https://open.spotify.com/track/3Utjd0xWwiHU4Ff4z438aG) | Headstrong | Masterregistratie |
| Pretty Wild | [Shot Me Down](https://open.spotify.com/track/2OOWiNegPJCRX4vNXEQxgl) | Interstate 13 | Masterregistratie |
| Rough Cutt | [Piece of My Heart](https://open.spotify.com/track/01TluZKgLPWzBObU5plV1T) | Rough Cutt | Masterregistratie |
| Saraya | [Love Has Taken Its Toll](https://open.spotify.com/track/0xoTEpWW6JDmVpnoQo5Oxl) | Saraya | Masterregistratie |
| Shark Island | [Bad For Each Other](https://open.spotify.com/track/55ftoigsg90cpRFZUqqljP) | Law of the Order | Masterregistratie |
| SHY | [It's Only Rock n Roll](https://open.spotify.com/track/1fjdOMHtWHyTJ5q9XfBmrt) | Welcome to the Madhouse | Masterregistratie |
| Silent Rage | [Rebel With a Cause](https://open.spotify.com/track/1Zae2Y6ihqEck4maOchh8R) | Dont Touch Me There | Masterregistratie |
| Tangier | [Ripcord](https://open.spotify.com/track/2tlQiYJWelcYShESxSo3tX) | Four Winds | Masterregistratie |
| TNT | [10,000 Lovers (In One)](https://open.spotify.com/track/7q1HuENSdN4GMm8IxvdeKg) | Tell No Tales | Masterregistratie |
| Treat | [The War Is Over](https://open.spotify.com/track/7ny9jmlxRRXRuoPjwvhFQ3) | Coup De Grace | Masterregistratie |
| Tyketto | [Faithless](https://open.spotify.com/track/75QZe1Yfpi1hmWIavPNgXV) | Dig in Deep | Masterregistratie |
| Von Groove | [Better Than Ever](https://open.spotify.com/track/5MotDhB6ddSFux2RirEFqm) | Von Groove | Masterregistratie |
| Waysted | [Walls Fall Down](https://open.spotify.com/track/3kZD4ZUmX2zs5qDdmgzKuP) | Save Your Prayers | Masterregistratie |
| Winger | [Seventeen](https://open.spotify.com/track/2ZS0wDcdfrJPC86u5aJGo9) | Winger | Masterregistratie |
| XYZ | [Inside Out](https://open.spotify.com/track/6qQ6gLUtaAJMubfyE7Dd5S) | Hollywood Rocks! | Masterregistratie |
| Y&T | [Open Fire](https://open.spotify.com/track/3bjvLwp6T0S1c4RtP4rBz8) | Black Tiger (Expanded Edition) | Masterregistratie |

## KISS DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alice Cooper | [Elected](https://open.spotify.com/track/32wcgD2iId0smNDyjUNvd8) | Billion Dollar Babies | DNA-playlist-exportregistratie |
| Babylon A.D. | [Bang Go the Bells](https://open.spotify.com/track/3KcU6uoStAqQ0kIbCqb17g) | Bang Go the Bells | DNA-playlist-exportregistratie |
| BAD MOON RISING | [Full Moon Fever](https://open.spotify.com/track/2sFjEYfvb8ljjPzYymr6q6) | Bad Moon Rising | DNA-playlist-exportregistratie |
| Hurricane | [I'm On To You](https://open.spotify.com/track/1SSl0W9w6qnWDn3RuS8iWs) | Over The Edge | DNA-playlist-exportregistratie |
| ICON | [Danger Calling](https://open.spotify.com/track/0oLhwxvNHtxeeJfkcdVufF) | Night Of The Crime | DNA-playlist-exportregistratie |
| John Norum | [Still The Night](https://open.spotify.com/track/6fpZe462ozfaI0mWxwSXuQ) | Face The Truth | DNA-playlist-exportregistratie |
| Kane Roberts | [Dance Little Sister](https://open.spotify.com/track/1iSBHNMOe5URk7nfspifky) | Saints and Sinners | DNA-playlist-exportregistratie |
| Kingdom Come | [Who Do You Love](https://open.spotify.com/track/7yT8LTMsVjIrEQUvIOuSPH) | In Your Face | DNA-playlist-exportregistratie |
| KISS | [Tears Are Falling](https://open.spotify.com/track/1hxt3chzYLAzS4NmSSi5A3) | Asylum | DNA-playlist-exportregistratie |
| Lee Aaron | [Metal Queen](https://open.spotify.com/track/4b3UYHaYfUb1V546Chw4to) | Metal Queen | DNA-playlist-exportregistratie |
| Lillian Axe | [Show A Little Love](https://open.spotify.com/track/4FsAlfZHssqD8BXHANHLqP) | Love + War | DNA-playlist-exportregistratie |
| LIONSHEART | [Can't Believe](https://open.spotify.com/track/5h7ymBzWhlHhMTwoqA4ShA) | Lionsheart | DNA-playlist-exportregistratie |
| Masquerade | [Gimme All Your Love](https://open.spotify.com/track/2tQQbnFVWTkgtrFHiK4vR2) | Masquerade (Deluxe Edition) | DNA-playlist-exportregistratie |
| Melidian | [Ready to Rock](https://open.spotify.com/track/7qIwJEBAIDoMjXeSRMAKKM) | Lost in the Wild | DNA-playlist-exportregistratie |
| Pink Cream 69 | [Walls Come Down](https://open.spotify.com/track/3Utjd0xWwiHU4Ff4z438aG) | Headstrong | DNA-playlist-exportregistratie |
| Pretty Wild | [Shot Me Down](https://open.spotify.com/track/2OOWiNegPJCRX4vNXEQxgl) | Interstate 13 | DNA-playlist-exportregistratie |
| Rough Cutt | [Piece of My Heart](https://open.spotify.com/track/01TluZKgLPWzBObU5plV1T) | Rough Cutt | DNA-playlist-exportregistratie |
| Saraya | [Love Has Taken Its Toll](https://open.spotify.com/track/0xoTEpWW6JDmVpnoQo5Oxl) | Saraya | DNA-playlist-exportregistratie |
| Shark Island | [Bad For Each Other](https://open.spotify.com/track/55ftoigsg90cpRFZUqqljP) | Law of the Order | DNA-playlist-exportregistratie |
| SHY | [It's Only Rock n Roll](https://open.spotify.com/track/1fjdOMHtWHyTJ5q9XfBmrt) | Welcome to the Madhouse | DNA-playlist-exportregistratie |
| Silent Rage | [Rebel With a Cause](https://open.spotify.com/track/1Zae2Y6ihqEck4maOchh8R) | Dont Touch Me There | DNA-playlist-exportregistratie |
| Tangier | [Ripcord](https://open.spotify.com/track/2tlQiYJWelcYShESxSo3tX) | Four Winds | DNA-playlist-exportregistratie |
| TNT | [10,000 Lovers (In One)](https://open.spotify.com/track/7q1HuENSdN4GMm8IxvdeKg) | Tell No Tales | DNA-playlist-exportregistratie |
| Treat | [The War Is Over](https://open.spotify.com/track/7ny9jmlxRRXRuoPjwvhFQ3) | Coup De Grace | DNA-playlist-exportregistratie |
| Tyketto | [Faithless](https://open.spotify.com/track/75QZe1Yfpi1hmWIavPNgXV) | Dig in Deep | DNA-playlist-exportregistratie |
| Von Groove | [Better Than Ever](https://open.spotify.com/track/5MotDhB6ddSFux2RirEFqm) | Von Groove | DNA-playlist-exportregistratie |
| Waysted | [Walls Fall Down](https://open.spotify.com/track/3kZD4ZUmX2zs5qDdmgzKuP) | Save Your Prayers | DNA-playlist-exportregistratie |
| Winger | [Seventeen](https://open.spotify.com/track/2ZS0wDcdfrJPC86u5aJGo9) | Winger | DNA-playlist-exportregistratie |
| XYZ | [Inside Out](https://open.spotify.com/track/6qQ6gLUtaAJMubfyE7Dd5S) | Hollywood Rocks! | DNA-playlist-exportregistratie |
| Y&T | [Open Fire](https://open.spotify.com/track/3bjvLwp6T0S1c4RtP4rBz8) | Black Tiger (Expanded Edition) | DNA-playlist-exportregistratie |

## Metallica DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Accept | [Balls To The Wall](https://open.spotify.com/track/0xX1PxiAPN1mD9hCRiqd0Z) | Staying A Life | Masterregistratie |
| Judas Priest | [Painkiller](https://open.spotify.com/track/0L7zm6afBEtrNKo6C6Gj08) | Painkiller | Masterregistratie |
| LOUDNESS | [Crazy Night（Remaster Version）](https://open.spotify.com/track/5EcFBNGhTAcCh0z9Za5YeQ) | ROCK SHOCKS（Remaster Version） | Masterregistratie |
| Tygers Of Pan Tang | [Only the Brave](https://open.spotify.com/track/5F4PRUrsZQ8zTppxd6OA9a) | Tygers of Pan Tang | Masterregistratie |

## Metallica DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Accept | [Balls To The Wall](https://open.spotify.com/track/0xX1PxiAPN1mD9hCRiqd0Z) | Staying A Life | DNA-playlist-exportregistratie |
| Judas Priest | [Painkiller](https://open.spotify.com/track/0L7zm6afBEtrNKo6C6Gj08) | Painkiller | DNA-playlist-exportregistratie |
| LOUDNESS | [Crazy Night（Remaster Version）](https://open.spotify.com/track/5EcFBNGhTAcCh0z9Za5YeQ) | ROCK SHOCKS（Remaster Version） | DNA-playlist-exportregistratie |
| Tygers Of Pan Tang | [Only the Brave](https://open.spotify.com/track/5F4PRUrsZQ8zTppxd6OA9a) | Tygers of Pan Tang | DNA-playlist-exportregistratie |

## Modern Hair Metal Revival DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| 17  Crash | [Through Hell and Back](https://open.spotify.com/track/5DUwA2mRmOTUrlfrDXTuTe) | Through Hell and Back | DNA-playlist-exportregistratie |
| Atomic Riot | [Dance with the Devil](https://open.spotify.com/track/1FiVRpr3BdZmekfdKsjTKt) | Atomic Riot | DNA-playlist-exportregistratie |
| Bad City | [Take Me for a Ride](https://open.spotify.com/track/6iRoX4WbIeY9PQh5MNRPOm) | Welcome to the Wasteland | DNA-playlist-exportregistratie |
| Beautiful Creatures | [1 A.M.](https://open.spotify.com/track/7ChtXTYUFz95bNtrTaXUST) | Beautiful Creatures | DNA-playlist-exportregistratie |
| Big Cock | [Bump and Grind](https://open.spotify.com/track/3g9zgsWo5cQIkbJeU5tMh6) | Motherload | DNA-playlist-exportregistratie |
| Brides Of Destruction | [Shut the Fuck Up](https://open.spotify.com/track/0GObuYPUbAqttlTHfXzvja) | Here Come the Brides | DNA-playlist-exportregistratie |
| Catalano | [Set This City on Fire](https://open.spotify.com/track/3KICJpgBMMNXD35i6fXqvb) | Nightfighter | DNA-playlist-exportregistratie |
| Christian Shields | [Can't Get Enough](https://open.spotify.com/track/5YTPq05aU6HbePwPY5MWxA) | This Is Rock 'N' Roll | DNA-playlist-exportregistratie |
| Cobra Spell | [The Devil Inside of Me](https://open.spotify.com/track/5jL5h2D7ZCKLU0c1FtaTQf) | 666 | DNA-playlist-exportregistratie |
| Crash Kelly | [She Gets Away](https://open.spotify.com/track/1kTPKqk6vMojgGGgsfumiq) | Penny Pills | DNA-playlist-exportregistratie |
| Crystal Pistol | [Rockstar](https://open.spotify.com/track/4NTuOzgM0DgNtbCSCUj9QN) | Crystal Pistol | DNA-playlist-exportregistratie |
| Dextress | [Wild Is the Night](https://open.spotify.com/track/6NNsd9I026SdZOKDYxxPFY) | Dextress | DNA-playlist-exportregistratie |
| DIEMONDS | [Take On The Night](https://open.spotify.com/track/3GaFXK924iUUjFoBXnElOn) | The Bad Pack | DNA-playlist-exportregistratie |
| Dirty Penny | [Midnight Ride](https://open.spotify.com/track/5odcsQIIb5KnBBEJfiurfg) | Take it Sleezy | DNA-playlist-exportregistratie |
| Erotic Psycho | [Sex Me Up](https://open.spotify.com/track/7wgW21EE9DOX1wllyCKWCG) | Sex You Up! | DNA-playlist-exportregistratie |
| John Diva & the Rockets of Love | [American Amadeus](https://open.spotify.com/track/5glmLXna7qATdV9Mx4ObQM) | American Amadeus | DNA-playlist-exportregistratie |
| Kissin' Dynamite | [You're Not Alone](https://open.spotify.com/track/7iiTqsPA1JyrifFT5uC8Mv) | Ecstasy | DNA-playlist-exportregistratie |
| Knock Out Kaine | [House of Sins](https://open.spotify.com/track/5CO83sRl9V71zp5AuXIkr0) | House of Sins | DNA-playlist-exportregistratie |
| L.A. Cobra | [Sell Your Soul (Little Girl)](https://open.spotify.com/track/2GzbTHVtT8qRA0Q5URGQPV) | Shotgun Slinger | DNA-playlist-exportregistratie |
| Löve Razër | [First Class Bitch](https://open.spotify.com/track/0FZz3lUJzcFa0kpVpi2uXu) | Rock 'N' Roll Addiction | DNA-playlist-exportregistratie |
| Mad Margritt | [Loaded Gun](https://open.spotify.com/track/2lzS8KMVOJ7yahEyQDZ4vD) | Animal | DNA-playlist-exportregistratie |
| Midnight Sin | [Midnight Revolution](https://open.spotify.com/track/3N1jTgIrRB9ygnJBFjCeUT) | Sex First | DNA-playlist-exportregistratie |
| Rakel Traxx | [S.E.X](https://open.spotify.com/track/0QEeZSbtq8LGo49WmiIQLX) | Bitches Palace | DNA-playlist-exportregistratie |
| Sisters Doll | [All Dolled Up](https://open.spotify.com/track/3rSEGkb2k3NxMq1Z0p7QNH) | All Dolled Up | DNA-playlist-exportregistratie |
| Skull Daze | [Dirty Girl](https://open.spotify.com/track/60CxR4AAuXPdyd77KKUW07) | Skull Daze | DNA-playlist-exportregistratie |
| Snakebite | [Two Desperate Hearts](https://open.spotify.com/track/6k0ZSzyUBMglF65AwnMvTm) | Rise of the Snake | DNA-playlist-exportregistratie |
| Speed Stroke | [Demon Alcohol](https://open.spotify.com/track/2zpOyHWYyaLPEjuSe0m6vB) | Fury | DNA-playlist-exportregistratie |
| Stolen Prayer | [Move on You](https://open.spotify.com/track/3KxPCmDDwWEdM2fBLRQIos) | Stolen Prayer II | DNA-playlist-exportregistratie |
| The Unripes | [Reload](https://open.spotify.com/track/67DOuWJIFmZQAEKnGXIqHY) | This Is Not America | DNA-playlist-exportregistratie |
| Wildstreet | [Easy Does It](https://open.spotify.com/track/1ZCBORA4hOTX9dUcpSnW7M) | Easy Does It | DNA-playlist-exportregistratie |

## Music DNA · Proefcadeau [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Giuffria | [Do Me Right](https://open.spotify.com/track/1IsKwftNuXKGG9bjNXh7lU) | Giuffria | DNA-playlist-exportregistratie |

## NWOBHM DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Ozzy Osbourne | [Crazy Train](https://open.spotify.com/track/2b9lp5A6CqSzwOrBfAFhof) | Blizzard of Ozz (Expanded Edition) | Masterregistratie |
| The Almighty | [Jonestown Mind](https://open.spotify.com/track/2UkdyzTbXJfquUZbzE93zY) | Crank | Masterregistratie |
| The Cult | [She Sells Sanctuary (2009 Re-master)](https://open.spotify.com/track/3EAFamlgsYPA3HijLUPszI) | Love (Expanded Edition) | Masterregistratie |
| Thunder | [Gimme Shelter](https://open.spotify.com/track/3rgMrxAo4IuG2tpiJmTPaA) | Their Finest Hour (And A Bit) | Masterregistratie |
| Whitesnake | [Still of the Night - 2018 Remaster](https://open.spotify.com/track/7AtwQRLPdttsxcLM5tPL0t) | Whitesnake (2018 Remaster) | Masterregistratie |

## NWOBHM DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Girlschool | [Race with the Devil](https://open.spotify.com/track/3D8KAebbZgAFdVjTrsNgOI) | Demolition | DNA-playlist-exportregistratie |
| Ozzy Osbourne | [Crazy Train](https://open.spotify.com/track/2b9lp5A6CqSzwOrBfAFhof) | Blizzard of Ozz (Expanded Edition) | DNA-playlist-exportregistratie |
| The Almighty | [Jonestown Mind](https://open.spotify.com/track/2UkdyzTbXJfquUZbzE93zY) | Crank | DNA-playlist-exportregistratie |
| The Cult | [She Sells Sanctuary (2009 Re-master)](https://open.spotify.com/track/3EAFamlgsYPA3HijLUPszI) | Love (Expanded Edition) | DNA-playlist-exportregistratie |
| Thunder | [Gimme Shelter](https://open.spotify.com/track/3rgMrxAo4IuG2tpiJmTPaA) | Their Finest Hour (And A Bit) | DNA-playlist-exportregistratie |
| Whitesnake | [Still of the Night - 2018 Remaster](https://open.spotify.com/track/7AtwQRLPdttsxcLM5tPL0t) | Whitesnake (2018 Remaster) | DNA-playlist-exportregistratie |

## Ontdek DNA #2026-39 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Badlands | [Healer](https://open.spotify.com/track/0DmtV4MheUFEjEz6XPZsox) | Dusk | DNA-playlist-exportregistratie |
| Coney Hatch | [Some Like It Hot](https://open.spotify.com/track/68oRkANDPCQ6EegIVdzwgx) | Outa Hand | DNA-playlist-exportregistratie |
| Helix | [Rock You](https://open.spotify.com/track/2sd8DUzBIaNBzkgEPGsHV6) | Walkin' The Razor's Edge | DNA-playlist-exportregistratie |
| John Diva & the Rockets of Love | [American Amadeus](https://open.spotify.com/track/5glmLXna7qATdV9Mx4ObQM) | American Amadeus | DNA-playlist-exportregistratie |
| Lipz | [Get It On](https://open.spotify.com/track/0ti0aAg5xZd7JW8KGU9ROX) | Scaryman | DNA-playlist-exportregistratie |
| Q5 | [Pull the Trigger](https://open.spotify.com/track/3sxvhBZLZF8siHd0LyKFyK) | Steel the Light | DNA-playlist-exportregistratie |
| Reckless Love | [Hot](https://open.spotify.com/track/5H6eTrcDfPAHXAHWrR7Q5M) | Animal Attraction | DNA-playlist-exportregistratie |
| Roxy Blue | [Too Hot To Handle](https://open.spotify.com/track/1vmTDGLj4FteG2Jn4NTazK) | Want Some? | DNA-playlist-exportregistratie |
| Shiraz Lane | [To The Moon & Back](https://open.spotify.com/track/0jCiQXabUrZmAfGXEbo3WF) | To The Moon & Back | DNA-playlist-exportregistratie |
| Signal | [Arms Of A Stranger](https://open.spotify.com/track/3gdnbF4xI6Lkql4vbFlZrM) | Loud & Clear | DNA-playlist-exportregistratie |
| Stone Fury | [Break Down The Wall](https://open.spotify.com/track/7zevYZAJYMgEUu8rHDaxLR) | Burns Like A Star | DNA-playlist-exportregistratie |
| The Poodles | [Night of Passion](https://open.spotify.com/track/1ianoyRbOK3RXrQIiT2aTk) | Metal Will Stand Tall | DNA-playlist-exportregistratie |
| ToxicRose | [World of Confusion](https://open.spotify.com/track/1sPj9IM8jxDoMdVzefLKHj) | Total Tranquility | DNA-playlist-exportregistratie |

## Ontdek DNA #2026-40 [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alien | [Give It Up](https://open.spotify.com/track/1nDOVQ2ioOrnE7SfJT0rvO) | Shiftin' Gear | DNA-playlist-exportregistratie |
| Andy Timmons | [Groove or Die](https://open.spotify.com/track/2vLm4hsLeMMfcqaVlj4PKN) | That Was Then, This Is Now | DNA-playlist-exportregistratie |
| Aviator | [Front Line](https://open.spotify.com/track/5MmFMKe0VGaqlQ33KNy0KY) | Aviator | DNA-playlist-exportregistratie |
| Baby Jane | [My Behavior](https://open.spotify.com/track/1IJtqhXB7xi9IXqOmG7DLd) | In the Spotlight | DNA-playlist-exportregistratie |
| Babylon Bombs | [Hometown Hero](https://open.spotify.com/track/5TqQnYIyisbHJiHXzkSK9u) | Doin' You Nasty | DNA-playlist-exportregistratie |
| Big Bang Babies | [Everybody Needs A Hero](https://open.spotify.com/track/3HUCwifeBQMMBKUPxCaVt2) | 3 Chords And The Truth | DNA-playlist-exportregistratie |
| Bombshell Boys | [Shake Your Body](https://open.spotify.com/track/07VDLT8jatNUZTGgVVm7gy) | Medicine for Love | DNA-playlist-exportregistratie |
| Brighton Rock | [Young Wild and Free](https://open.spotify.com/track/7EBpncUwlHjLhQTetSLb9O) | Young, Wild And Free | DNA-playlist-exportregistratie |
| C.J. Snare | [Rock You Tonight](https://open.spotify.com/track/6Db5cayYggggqGq2MIfp65) | Hold Your Fire | DNA-playlist-exportregistratie |
| Crash Kelly | [She Gets Away](https://open.spotify.com/track/1kTPKqk6vMojgGGgsfumiq) | Penny Pills | DNA-playlist-exportregistratie |
| Crystal Pistol | [Rockstar](https://open.spotify.com/track/4NTuOzgM0DgNtbCSCUj9QN) | Crystal Pistol | DNA-playlist-exportregistratie |
| Heavy Bones | [The Hand That Feeds](https://open.spotify.com/track/0bwEjc3wdAY8mDdsbnRxcv) | Heavy Bones | DNA-playlist-exportregistratie |
| John Norum;Joey Tempest | [We Will Be Strong](https://open.spotify.com/track/1xId1hoQ0mfYl610t5VtPW) | Face The Truth | DNA-playlist-exportregistratie |
| King Kobra | [Iron Eagle (Never Say Die)](https://open.spotify.com/track/3tD4AR8vbvM0b9X09YBYE0) | Thrill Of A Lifetime | DNA-playlist-exportregistratie |
| Peppermint Creeps | [Turning Japanese](https://open.spotify.com/track/6Wb0KcC6LEMjOtLYcMKcss) | We R The Weirdoz!!! | DNA-playlist-exportregistratie |
| Radioactive;Jeff Paris | [Shame On You, Shame On Me](https://open.spotify.com/track/6XcxLPk27iNbo2rBWnnr5V) | Shame On You, Shame On Me | DNA-playlist-exportregistratie |
| Restless Spirits;Chez Kane | [Dreams of the Wild](https://open.spotify.com/track/6cVcombXzsFOdRDnvpMLoL) | Dreams of the Wild | DNA-playlist-exportregistratie |
| Return | [Steal Your Heart](https://open.spotify.com/track/4sbbbxq9R9KJoUZuJHF6Wb) | Attitudes | DNA-playlist-exportregistratie |
| Saints & Sinners | [Shake](https://open.spotify.com/track/4gjFeCBHRvUQluaJgUsDCh) | Saints & Sinners | DNA-playlist-exportregistratie |
| Sic Vikki | [Kiss Me in French](https://open.spotify.com/track/4lxeOuQ37BfUxqkeOwwIjb) | Kiss Me in French (30th Anniversary) | DNA-playlist-exportregistratie |
| Zebra | [As I Said Before](https://open.spotify.com/track/3DQUOnH5OKGjXXnfKGj0UT) | Zebra | DNA-playlist-exportregistratie |

## RATT DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| 220 Volt | [The Harder They Come](https://open.spotify.com/track/3Q0fmbHtdUVu3uZI2TonUn) | Eye to Eye | Masterregistratie |
| Alcatrazz | [God Blessed Video](https://open.spotify.com/track/2nsrALjWaiP5WqyzIkJlHe) | Disturbing The Peace | Masterregistratie |
| Axe | [Young Hearts](https://open.spotify.com/track/6Dvy24CR0KZjjsQIqilyxL) | Nemesis | Masterregistratie |
| BAD HABIT Sweden | [Another Night](https://open.spotify.com/track/1yFU4PX34ya2lt9urs4XYu) | Revolution (Re-Mastered) | Masterregistratie |
| Bai Bang | [Raise Your Hands](https://open.spotify.com/track/0jJBQ5bqJT7mzirXnAoSNk) | All Around the World | Masterregistratie |
| Bangalore Choir | [Angel in Black](https://open.spotify.com/track/280ibzeGZs86VRH7iejBtw) | On Target | Masterregistratie |
| Baton Rouge | [Walks Like a Woman](https://open.spotify.com/track/1mSkQolHBx2wqFNwKnFCnA) | Shake Your Soul | Masterregistratie |
| Black Diamonds | [Rock n' Roll Is My Religion](https://open.spotify.com/track/5gmdly7vMnxOvryIp2xe2Q) | Destination Paradise | Masterregistratie |
| Bloody Heels | [Ignite the Sky](https://open.spotify.com/track/3APm5ErddIfnRSz70fdbaf) | Ignite the Sky | Masterregistratie |
| Bonfire | [Burning Heart](https://open.spotify.com/track/5g4kyBBhgXC4gtuyQgxCsV) | Legends | Masterregistratie |
| Burning Rain | [Face the Music](https://open.spotify.com/track/0sWUIQNEt6VxqZcjSGfz4O) | Face the Music | Masterregistratie |
| Casanova | [Burning Love](https://open.spotify.com/track/0h5Ll4rrsTfUHOqXYE4Rny) | Casanova | Masterregistratie |
| Chez Kane | [Powerzone](https://open.spotify.com/track/16SmBswtkGZPQR2wVcHBDe) | Powerzone | Masterregistratie |
| Confess | [Malleus](https://open.spotify.com/track/7yRLruRxym6eOyGwY0BQzm) | Burn 'em All | Masterregistratie |
| Crazy Lixx | [Blame It On Love](https://open.spotify.com/track/0MF8I8OUo8kytiOo8aSHYq) | New Religion | Masterregistratie |
| Danger Danger | [Naughty Naughty](https://open.spotify.com/track/53G4MWFNYRx2R22CHwkTrs) | Danger Danger | Masterregistratie |
| Don Dokken | [Mirror Mirror](https://open.spotify.com/track/0hCmGNCBtlrlj7HduIflJF) | Up From The Ashes | Masterregistratie |
| Fair Warning | [When Love Fails](https://open.spotify.com/track/2Sr3ftfmJmVjUJQNLRhikj) | Fair Warning | Masterregistratie |
| FM | [Frozen Heart](https://open.spotify.com/track/35XuGgoiSuSd7fynzObdDf) | Indiscreet | Masterregistratie |
| GIANT | [Thunder and Lightning](https://open.spotify.com/track/3A8tmh1KAnThMGLyXpym3e) | Time To Burn | Masterregistratie |
| Girish And The Chronicles | [Ride to Hell](https://open.spotify.com/track/2Gz1Ya7XxpDXsRn6toj3aF) | Back on Earth | Masterregistratie |
| Grand Design | [Rawk 'n' Roll Heart Attack](https://open.spotify.com/track/0dd7qzym8BByJhYGPhHn5g) | Thrill of the Night | Masterregistratie |
| Gunner | [Arcade Nights](https://open.spotify.com/track/29hKOqR29tEzeuZS22GHln) | Sinners | Masterregistratie |
| H.E.A.T | [1000 Miles](https://open.spotify.com/track/7KUIkBKcgU89hDKCnq9JM3) | H.e.a.t. | Masterregistratie |
| Hardline | [Takin' Me Down](https://open.spotify.com/track/0ykRm2cMP8ku2qRj5UpEsg) | Double Eclipse | Masterregistratie |
| Harem Scarem | [Aftershock](https://open.spotify.com/track/1eC1DM5oypvu5XIcpkNcaM) | Change the World | Masterregistratie |
| Heavens Edge | [Skin to Skin](https://open.spotify.com/track/2uWj7xlLTeoPylxwA6IukB) | Heavens Edge | Masterregistratie |
| Hell In the Club | [Devil on My Shoulder](https://open.spotify.com/track/4q5fKBdqCNWWKT9CTw4LGe) | Devil on My Shoulder | Masterregistratie |
| House Of Lords | [The Bigger They Come](https://open.spotify.com/track/1fjMxKt6DhJ3JQV2HG2OWv) | Cartesian Dreams | Masterregistratie |
| Ratt | [You're in Love](https://open.spotify.com/track/3D3lmTEhuWaunO1yxpYPD8) | Invasion of Your Privacy | Masterregistratie |

## RATT DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| 220 Volt | [The Harder They Come](https://open.spotify.com/track/3Q0fmbHtdUVu3uZI2TonUn) | Eye to Eye | DNA-playlist-exportregistratie |
| Alcatrazz | [God Blessed Video](https://open.spotify.com/track/2nsrALjWaiP5WqyzIkJlHe) | Disturbing The Peace | DNA-playlist-exportregistratie |
| Axe | [Young Hearts](https://open.spotify.com/track/6Dvy24CR0KZjjsQIqilyxL) | Nemesis | DNA-playlist-exportregistratie |
| BAD HABIT Sweden | [Another Night](https://open.spotify.com/track/1yFU4PX34ya2lt9urs4XYu) | Revolution (Re-Mastered) | DNA-playlist-exportregistratie |
| Bai Bang | [Raise Your Hands](https://open.spotify.com/track/0jJBQ5bqJT7mzirXnAoSNk) | All Around the World | DNA-playlist-exportregistratie |
| Bangalore Choir | [Angel in Black](https://open.spotify.com/track/280ibzeGZs86VRH7iejBtw) | On Target | DNA-playlist-exportregistratie |
| Baton Rouge | [Walks Like a Woman](https://open.spotify.com/track/1mSkQolHBx2wqFNwKnFCnA) | Shake Your Soul | DNA-playlist-exportregistratie |
| Black Diamonds | [Rock n' Roll Is My Religion](https://open.spotify.com/track/5gmdly7vMnxOvryIp2xe2Q) | Destination Paradise | DNA-playlist-exportregistratie |
| Bloody Heels | [Ignite the Sky](https://open.spotify.com/track/3APm5ErddIfnRSz70fdbaf) | Ignite the Sky | DNA-playlist-exportregistratie |
| Bonfire | [Burning Heart](https://open.spotify.com/track/5g4kyBBhgXC4gtuyQgxCsV) | Legends | DNA-playlist-exportregistratie |
| Burning Rain | [Face the Music](https://open.spotify.com/track/0sWUIQNEt6VxqZcjSGfz4O) | Face the Music | DNA-playlist-exportregistratie |
| Casanova | [Burning Love](https://open.spotify.com/track/0h5Ll4rrsTfUHOqXYE4Rny) | Casanova | DNA-playlist-exportregistratie |
| Chez Kane | [Powerzone](https://open.spotify.com/track/16SmBswtkGZPQR2wVcHBDe) | Powerzone | DNA-playlist-exportregistratie |
| Confess | [Malleus](https://open.spotify.com/track/7yRLruRxym6eOyGwY0BQzm) | Burn 'em All | DNA-playlist-exportregistratie |
| Crazy Lixx | [Blame It On Love](https://open.spotify.com/track/0MF8I8OUo8kytiOo8aSHYq) | New Religion | DNA-playlist-exportregistratie |
| Danger Danger | [Naughty Naughty](https://open.spotify.com/track/53G4MWFNYRx2R22CHwkTrs) | Danger Danger | DNA-playlist-exportregistratie |
| Don Dokken | [Mirror Mirror](https://open.spotify.com/track/0hCmGNCBtlrlj7HduIflJF) | Up From The Ashes | DNA-playlist-exportregistratie |
| Fair Warning | [When Love Fails](https://open.spotify.com/track/2Sr3ftfmJmVjUJQNLRhikj) | Fair Warning | DNA-playlist-exportregistratie |
| FM | [Frozen Heart](https://open.spotify.com/track/35XuGgoiSuSd7fynzObdDf) | Indiscreet | DNA-playlist-exportregistratie |
| GIANT | [Thunder and Lightning](https://open.spotify.com/track/3A8tmh1KAnThMGLyXpym3e) | Time To Burn | DNA-playlist-exportregistratie |
| Girish And The Chronicles | [Ride to Hell](https://open.spotify.com/track/2Gz1Ya7XxpDXsRn6toj3aF) | Back on Earth | DNA-playlist-exportregistratie |
| Grand Design | [Rawk 'n' Roll Heart Attack](https://open.spotify.com/track/0dd7qzym8BByJhYGPhHn5g) | Thrill of the Night | DNA-playlist-exportregistratie |
| Gunner | [Arcade Nights](https://open.spotify.com/track/29hKOqR29tEzeuZS22GHln) | Sinners | DNA-playlist-exportregistratie |
| H.E.A.T | [1000 Miles](https://open.spotify.com/track/7KUIkBKcgU89hDKCnq9JM3) | H.e.a.t. | DNA-playlist-exportregistratie |
| Hardline | [Takin' Me Down](https://open.spotify.com/track/0ykRm2cMP8ku2qRj5UpEsg) | Double Eclipse | DNA-playlist-exportregistratie |
| Harem Scarem | [Aftershock](https://open.spotify.com/track/1eC1DM5oypvu5XIcpkNcaM) | Change the World | DNA-playlist-exportregistratie |
| Heavens Edge | [Skin to Skin](https://open.spotify.com/track/2uWj7xlLTeoPylxwA6IukB) | Heavens Edge | DNA-playlist-exportregistratie |
| Hell In the Club | [Devil on My Shoulder](https://open.spotify.com/track/4q5fKBdqCNWWKT9CTw4LGe) | Devil on My Shoulder | DNA-playlist-exportregistratie |
| House Of Lords | [The Bigger They Come](https://open.spotify.com/track/1fjMxKt6DhJ3JQV2HG2OWv) | Cartesian Dreams | DNA-playlist-exportregistratie |
| Ratt | [You're in Love](https://open.spotify.com/track/3D3lmTEhuWaunO1yxpYPD8) | Invasion of Your Privacy | DNA-playlist-exportregistratie |

## Rush DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Queensrÿche | [The Needle Lies - Remastered 2003](https://open.spotify.com/track/6D56362n3CmvFqPPqrujqc) | Operation: Mindcrime (Deluxe Edition) | Masterregistratie |

## Rush DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Queensrÿche | [The Needle Lies - Remastered 2003](https://open.spotify.com/track/6D56362n3CmvFqPPqrujqc) | Operation: Mindcrime (Deluxe Edition) | DNA-playlist-exportregistratie |

## Scandinavian Hair Metal DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alien | [Give It Up](https://open.spotify.com/track/1nDOVQ2ioOrnE7SfJT0rvO) | Shiftin' Gear | DNA-playlist-exportregistratie |
| Baby Jane | [My Behavior](https://open.spotify.com/track/1IJtqhXB7xi9IXqOmG7DLd) | In the Spotlight | DNA-playlist-exportregistratie |
| Babylon Bombs | [Hometown Hero](https://open.spotify.com/track/5TqQnYIyisbHJiHXzkSK9u) | Doin' You Nasty | DNA-playlist-exportregistratie |
| Bulletrain | [Memory Lane](https://open.spotify.com/track/3B1GcV5ViFxTMpX6bGcPnD) | What You Fear the Most | DNA-playlist-exportregistratie |
| D-A-D | [Sleeping My Day Away - 2009 - Remaster](https://open.spotify.com/track/5ZuXgk0enEvv2HlnUe2rj3) | No Fuel Left for the Pilgrims (2009 - Remastered) | DNA-playlist-exportregistratie |
| Dream Police | [Rock Me](https://open.spotify.com/track/0UG2cMyIPWU5cXGNsweAlL) | Dream Police | DNA-playlist-exportregistratie |
| Dust Bowl Jokies | [Boots on Rocks Off](https://open.spotify.com/track/4ZhBsaHn2of6CW1I8cT7sn) | Cockaigne Vaudeville | DNA-playlist-exportregistratie |
| Easy Action | [We Go Rocking - 2008 re-recording](https://open.spotify.com/track/4WmZoM5KgISsleWXDZM9jO) | We Go Rocking | DNA-playlist-exportregistratie |
| Europe | [The Final Countdown](https://open.spotify.com/track/3MrRksHupTVEQ7YbA0FsZK) | The Final Countdown (Expanded Edition) | DNA-playlist-exportregistratie |
| Hell N' Diesel | [Miss Cocaine](https://open.spotify.com/track/3pIYR84epkcf0zCfIMGipV) | Passion for Power | DNA-playlist-exportregistratie |
| Highride | [A Good Day (To Die)](https://open.spotify.com/track/087dDyo7DRneZWsagz011x) | Excellence & Decadence | DNA-playlist-exportregistratie |
| Laney's Legion | [Taste of Your Tongue](https://open.spotify.com/track/5XK4P3zE7DYnnwZUsBILMU) | Laney's Legion | DNA-playlist-exportregistratie |
| Loud 'N' Nasty | [Stand Strong](https://open.spotify.com/track/4KOCQK92cOw8Pvx9haAa6p) | Stand Strong | DNA-playlist-exportregistratie |
| NiteRain | [Lost and Wasted](https://open.spotify.com/track/7HgInZAuyMC2h5oIEkvEa8) | Vendetta | DNA-playlist-exportregistratie |
| Quickstrike | [Rebel Radio](https://open.spotify.com/track/5WstrW5hHw0SQaUWL0RPNR) | None Of A Kind | DNA-playlist-exportregistratie |
| Return | [Steal Your Heart](https://open.spotify.com/track/4sbbbxq9R9KJoUZuJHF6Wb) | Attitudes | DNA-playlist-exportregistratie |
| Scandal Circus | [In the Name of Rock N´ Roll](https://open.spotify.com/track/68GaB1nA1tGa9a08Y5AnVL) | In the Name of Rock N´ Roll | DNA-playlist-exportregistratie |
| Shiraz Lane | [To The Moon & Back](https://open.spotify.com/track/0jCiQXabUrZmAfGXEbo3WF) | To The Moon & Back | DNA-playlist-exportregistratie |
| Sister | [Carved in Stone](https://open.spotify.com/track/3JRuHFUVAK4cgCx98pv8a8) | Stand up, Forward, March! | DNA-playlist-exportregistratie |
| Sons Of Angels | [Spend the Night](https://open.spotify.com/track/4sbhYTms1UZc3tLJOmiWP6) | Sons Of Angels | DNA-playlist-exportregistratie |
| Stage Dolls | [Soldiers Gun](https://open.spotify.com/track/74vPDjq1Me3iRffUP4kC4W) | Soldiers Gun | DNA-playlist-exportregistratie |
| Strÿkenine | [Inside](https://open.spotify.com/track/4bQr7iA7izf3u7aOJ2Y5tP) | Inside | DNA-playlist-exportregistratie |
| Swedish Erotica | [Rock'n'Roll City](https://open.spotify.com/track/7HKkpIjafs6ufCZlXJgvAj) | Swedish Erotica | DNA-playlist-exportregistratie |
| The Cruel Intentions | [Jawbreaker](https://open.spotify.com/track/42BMNYuOQFa7gefX7sCeRK) | No Sign of Relief | DNA-playlist-exportregistratie |
| The Poodles | [Night of Passion](https://open.spotify.com/track/1ianoyRbOK3RXrQIiT2aTk) | Metal Will Stand Tall | DNA-playlist-exportregistratie |
| Tindrum | [Drums of War](https://open.spotify.com/track/0qCQ4qe6fO4cRQsG0eqY4C) | Drums of War | DNA-playlist-exportregistratie |
| Wig Wam | [Gonna Get You Someday](https://open.spotify.com/track/5zULoNWVx5FkBROAo9ce9w) | Wig Wamania | DNA-playlist-exportregistratie |
| Wildnite | [I'll Be There](https://open.spotify.com/track/7sUYjUNdts2w5bGSrtm2Sd) | Wildnite | DNA-playlist-exportregistratie |
| Zan Clan | [Go Go Go](https://open.spotify.com/track/6vPsyfpxShe0Sa2ltKhzFm) | We Are Zan Clan... | DNA-playlist-exportregistratie |

## Southern Rock DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| The Four Horsemen | [Can't Stop Rockin](https://open.spotify.com/track/0LJpAeb5D1uK5C7thKCOSe) | Nobody Said It Was Easy | Masterregistratie |

## Southern Rock DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| The Four Horsemen | [Can't Stop Rockin](https://open.spotify.com/track/0LJpAeb5D1uK5C7thKCOSe) | Nobody Said It Was Easy | DNA-playlist-exportregistratie |

## Speed Thrash Metal DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Armored Saint | [Can U Deliver](https://open.spotify.com/track/25kORdST1xzG4WXOnzJCKV) | March Of The Saint | Masterregistratie |

## Speed Thrash Metal DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Armored Saint | [Can U Deliver](https://open.spotify.com/track/25kORdST1xzG4WXOnzJCKV) | March Of The Saint | DNA-playlist-exportregistratie |

## Sunset Strip Sleaze Metal DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| All or Nothing | [The Big Deal](https://open.spotify.com/track/7bvQNZgCzGSN7bctpl3NJb) | AON | DNA-playlist-exportregistratie |
| Beau Nasty | [Goodbye Rosie](https://open.spotify.com/track/5OseDsw9dkEvY3uhh9Wpn4) | Dirty, But Well Dressed | DNA-playlist-exportregistratie |
| Billion Dollar Babies | [In the Back of My Limousine](https://open.spotify.com/track/3GdTrTfB4iHhVCSP5QKKTM) | House of Dreams Pt.1 | DNA-playlist-exportregistratie |
| Bombshell Boys | [Shake Your Body](https://open.spotify.com/track/07VDLT8jatNUZTGgVVm7gy) | Medicine for Love | DNA-playlist-exportregistratie |
| Diamond Lane | [The Enemy](https://open.spotify.com/track/3Qf7gOUUDQh8ABRXicG2R4) | Terrorizer | DNA-playlist-exportregistratie |
| Diamond Rexx | [Land Of The Damned](https://open.spotify.com/track/45L8TWrPiA9FCGUKOgujlb) | Land of the Damned | DNA-playlist-exportregistratie |
| Femme Fatale | [My Baby's Gun](https://open.spotify.com/track/2liRH2CmYCeHxAFyzoaqLe) | Virgines Metallium: A Tribute to the New Maidens of Metal | DNA-playlist-exportregistratie |
| Foxy Venus | [Thirsty for Love](https://open.spotify.com/track/28HDdjjVBm9vCOXrLtvnF1) | Thirsty for Love | DNA-playlist-exportregistratie |
| Hollywood Rose | [Killing Time](https://open.spotify.com/track/5ssGfL5SbidOv7yJLtsXFd) | 100 Hair Metal Anthems | DNA-playlist-exportregistratie |
| Julliet | [Love Hungry Man](https://open.spotify.com/track/5eaveS1Oieqxf9HRNUQymh) | Passion | DNA-playlist-exportregistratie |
| Kidd Skruff | [Honky Tonk Woman](https://open.spotify.com/track/0XZBr0WakortnKU7lfT0NL) | Angels With Dirty Faces | DNA-playlist-exportregistratie |
| Laci Violett | [Snakebite](https://open.spotify.com/track/6ycPmWFMoGinlD3yC7P9oL) | Laci Violett | DNA-playlist-exportregistratie |
| Lioncourt | [Kiss to Kill](https://open.spotify.com/track/4LzTT2BphTwQUidiuOunSO) | Kiss to Kill | DNA-playlist-exportregistratie |
| Lostboys | [Lost And Found](https://open.spotify.com/track/57FdV3Vwi2Qwj15ziHxAKd) | Lost And Found | DNA-playlist-exportregistratie |
| Nasty Ratz | [All Night Long](https://open.spotify.com/track/6cdtQmOoaweSXXzoXkiXWP) | Third Cut | DNA-playlist-exportregistratie |
| NITE | [Nite F'king Riders](https://open.spotify.com/track/5DcgJfdYh1F2OHDkczPpfy) | 2nd Extended | DNA-playlist-exportregistratie |
| Peppermint Creeps | [Turning Japanese](https://open.spotify.com/track/6Wb0KcC6LEMjOtLYcMKcss) | We R The Weirdoz!!! | DNA-playlist-exportregistratie |
| Pussy Sisster | [Here Are the Pussys](https://open.spotify.com/track/0YF8iD65m1fWLq5ps0dd8Q) | Here Are the Pussys | DNA-playlist-exportregistratie |
| Rebelstar | [The Heat Is On](https://open.spotify.com/track/6QFo7dfNgB696C50aKox6o) | Take a Hit | DNA-playlist-exportregistratie |
| Rock Soldiers | [Never Givin’ Up](https://open.spotify.com/track/4HMxExh5WWoCYRmFkCXqMv) | Never Givin’ Up | DNA-playlist-exportregistratie |
| Shake City | [Hot Love](https://open.spotify.com/track/6WJZ771rZr5dl81HHE9uIs) | Shake City | DNA-playlist-exportregistratie |
| Sic Vikki | [Kiss Me in French](https://open.spotify.com/track/4lxeOuQ37BfUxqkeOwwIjb) | Kiss Me in French (30th Anniversary) | DNA-playlist-exportregistratie |
| Steevi Jaimz | [Cat On A Hot Tin Roof](https://open.spotify.com/track/2ZdBLRfolvi1VdLc0LY0ZQ) | Glam Damnation | DNA-playlist-exportregistratie |
| Tales From The Porn | [Back to the 80's](https://open.spotify.com/track/6hUpP05PFI4AavmWtRoW1q) | H. M. M. V | DNA-playlist-exportregistratie |
| The Bang Gang | [Pedal to the Metal](https://open.spotify.com/track/6ic9FzKyg8vVy50PLpRMI0) | Love Sells | DNA-playlist-exportregistratie |
| The Cherry Bombz | [Hot Girls](https://open.spotify.com/track/6BBBk288ysctFBf14F4kTq) | The Cherry Bombz - Deluxe Version | DNA-playlist-exportregistratie |
| The Nästy | [Expect No Mercy](https://open.spotify.com/track/3qDu4tmjRQ1Z6YCBQkFvkg) | Expect No Mercy | DNA-playlist-exportregistratie |
| Tryx | [She's so Fine](https://open.spotify.com/track/0DzhQxAj8XOyTCYFzGrf16) | Don't You Need It | DNA-playlist-exportregistratie |
| Vain Vipers | [Bitch Please (Shut Up)](https://open.spotify.com/track/3YJRoWGQPySnv7oTHbYWCv) | Vain Vipers | DNA-playlist-exportregistratie |
| Vamp | [Heartbreak, Heartache](https://open.spotify.com/track/0Dcrpt05CBuXjEyzTAM8LX) | The Rich Don't Rock | DNA-playlist-exportregistratie |

## Sweet DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bang Tango | [Someone Like You](https://open.spotify.com/track/0ebrUqGYac6Hh1nCF6ex3Y) | The Ultimate Bang Tango - Rockers & Thieves | Masterregistratie |
| Britny Fox | [Girlschool](https://open.spotify.com/track/3SLutZby4IG3BISQVzCesq) | The Best Of Britny Fox | Masterregistratie |
| Bulletboys | [Smooth up in Ya](https://open.spotify.com/track/5QoTdzVSygZB3SRxgFUANZ) | Bulletboys | Masterregistratie |
| Cinderella | [Somebody Save Me](https://open.spotify.com/track/3fjiaIx6KFssAz3C8TaUec) | Night Songs | Masterregistratie |
| Dangerous Toys | [Scared](https://open.spotify.com/track/4Rtx0zFndC7iDhZpIcJbT3) | Dangerous Toys | Masterregistratie |
| Dokken | [Into the Fire](https://open.spotify.com/track/2QarjsUyOIxGeUA3sR1xSZ) | Tooth and Nail | Masterregistratie |
| Great White | [Once Bitten Twice Shy](https://open.spotify.com/track/7pkWZL0kA26s754CwyK0SH) | Twice Shy | Masterregistratie |
| Jetboy | [Feel The Shake](https://open.spotify.com/track/0THwi7rnD74mtPYgSjGj8B) | 80s Metal Essentials | Masterregistratie |
| Killer Dwarfs | [Dirty Weapons](https://open.spotify.com/track/54VcCazvrKLfR8xdMFChW4) | Dirty Weapons | Masterregistratie |
| Kix | [Blow My Fuse](https://open.spotify.com/track/7jCc2Dz8PfHN3YoxDezkUl) | Blow My Fuse | Masterregistratie |
| Krokus | [Born To Be Wild](https://open.spotify.com/track/0H8iyBZDnWYgwVNAOcLiah) | Hoodoo | Masterregistratie |
| L.A. Guns | [Never Enough](https://open.spotify.com/track/4AWJ4Zwe5kHiQfUtrnFsA6) | Cocked And Loaded | Masterregistratie |
| Lita Ford | [Shot of Poison](https://open.spotify.com/track/7fG4AeCFHXxeXnAXfkmiFk) | Dangerous Curves | Masterregistratie |
| Mötley Crüe | [Wild Side](https://open.spotify.com/track/41wWrTueWew7qUU0Ru87Mp) | Girls, Girls, Girls | Masterregistratie |
| Pretty Boy Floyd | [Set The Night On Fire](https://open.spotify.com/track/7G0vIVAdfOSv5kXz09GzNH) | Porn Stars | Masterregistratie |
| Quiet Riot | [Metal Health (Bang Your Head)](https://open.spotify.com/track/28clONjZmul6FjfO6tZQDE) | Metal Health | Masterregistratie |
| Ratt | [Lay It Down](https://open.spotify.com/track/3D5ORNm9spaTcdRx50ksHx) | Invasion of Your Privacy | Masterregistratie |
| Santa Cruz | [Drag Me Down](https://open.spotify.com/track/6UBbdux7eI0m77auUWh4UD) | Drag Me Down | Masterregistratie |
| Skid Row | [18 and Life](https://open.spotify.com/track/0qgrrDnUUhyxpxbBznUnzg) | Skid Row | Masterregistratie |
| Slaughter | [Up All Night](https://open.spotify.com/track/1AsRjeavWPH8sCQbjMP8Xh) | Mass Slaughter | Masterregistratie |
| Sleeze Beez | [Screwed, Blued & Tattooed](https://open.spotify.com/track/2gS0MZUZu8xKxJbD7QXZBz) | Live In Tokyo | Masterregistratie |
| Spread Eagle | [Switchblade Serenade](https://open.spotify.com/track/3ubPquUIL4gzFghyGG0nsK) | Spread Eagle | Masterregistratie |
| Tesla | [Modern Day Cowboy](https://open.spotify.com/track/5ZIU2kT1wNjQNclQeVCz5O) | Mechanical Resonance | Masterregistratie |
| Vain | [Beat the Bullet](https://open.spotify.com/track/4xgqf2xJ8eaSKXRwYafEYf) | No Respect | Masterregistratie |
| Vinnie Vincent Invasion | [Dirty Rhythm - Remastered 2003](https://open.spotify.com/track/6hkkco5FXywlf1Kjqwc3o3) | All Systems Go (Remastered 2003) | Masterregistratie |
| Vixen | [Edge Of A Broken Heart](https://open.spotify.com/track/2mEk0VdrbDJ11DBC6Y92mh) | Vixen | Masterregistratie |
| Wildside | [Hang on Lucy](https://open.spotify.com/track/7jCoAuyOqLo80pWgveaW1I) | U.T.I. - 20th Anniversary Special Edition | Masterregistratie |

## Sweet DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bang Tango | [Someone Like You](https://open.spotify.com/track/0ebrUqGYac6Hh1nCF6ex3Y) | The Ultimate Bang Tango - Rockers & Thieves | DNA-playlist-exportregistratie |
| Britny Fox | [Girlschool](https://open.spotify.com/track/3SLutZby4IG3BISQVzCesq) | The Best Of Britny Fox | DNA-playlist-exportregistratie |
| Bulletboys | [Smooth up in Ya](https://open.spotify.com/track/5QoTdzVSygZB3SRxgFUANZ) | Bulletboys | DNA-playlist-exportregistratie |
| Cinderella | [Somebody Save Me](https://open.spotify.com/track/3fjiaIx6KFssAz3C8TaUec) | Night Songs | DNA-playlist-exportregistratie |
| Dangerous Toys | [Scared](https://open.spotify.com/track/4Rtx0zFndC7iDhZpIcJbT3) | Dangerous Toys | DNA-playlist-exportregistratie |
| Dokken | [Into the Fire](https://open.spotify.com/track/2QarjsUyOIxGeUA3sR1xSZ) | Tooth and Nail | DNA-playlist-exportregistratie |
| Great White | [Once Bitten Twice Shy](https://open.spotify.com/track/7pkWZL0kA26s754CwyK0SH) | Twice Shy | DNA-playlist-exportregistratie |
| Jetboy | [Feel The Shake](https://open.spotify.com/track/0THwi7rnD74mtPYgSjGj8B) | 80s Metal Essentials | DNA-playlist-exportregistratie |
| Killer Dwarfs | [Dirty Weapons](https://open.spotify.com/track/54VcCazvrKLfR8xdMFChW4) | Dirty Weapons | DNA-playlist-exportregistratie |
| Kix | [Blow My Fuse](https://open.spotify.com/track/7jCc2Dz8PfHN3YoxDezkUl) | Blow My Fuse | DNA-playlist-exportregistratie |
| Krokus | [Born To Be Wild](https://open.spotify.com/track/0H8iyBZDnWYgwVNAOcLiah) | Hoodoo | DNA-playlist-exportregistratie |
| L.A. Guns | [Never Enough](https://open.spotify.com/track/4AWJ4Zwe5kHiQfUtrnFsA6) | Cocked And Loaded | DNA-playlist-exportregistratie |
| Lita Ford | [Shot of Poison](https://open.spotify.com/track/7fG4AeCFHXxeXnAXfkmiFk) | Dangerous Curves | DNA-playlist-exportregistratie |
| Mötley Crüe | [Wild Side](https://open.spotify.com/track/41wWrTueWew7qUU0Ru87Mp) | Girls, Girls, Girls | DNA-playlist-exportregistratie |
| Pretty Boy Floyd | [Set The Night On Fire](https://open.spotify.com/track/7G0vIVAdfOSv5kXz09GzNH) | Porn Stars | DNA-playlist-exportregistratie |
| Quiet Riot | [Metal Health (Bang Your Head)](https://open.spotify.com/track/28clONjZmul6FjfO6tZQDE) | Metal Health | DNA-playlist-exportregistratie |
| Ratt | [Lay It Down](https://open.spotify.com/track/3D5ORNm9spaTcdRx50ksHx) | Invasion of Your Privacy | DNA-playlist-exportregistratie |
| Santa Cruz | [Drag Me Down](https://open.spotify.com/track/6UBbdux7eI0m77auUWh4UD) | Drag Me Down | DNA-playlist-exportregistratie |
| Skid Row | [18 and Life](https://open.spotify.com/track/0qgrrDnUUhyxpxbBznUnzg) | Skid Row | DNA-playlist-exportregistratie |
| Slaughter | [Up All Night](https://open.spotify.com/track/1AsRjeavWPH8sCQbjMP8Xh) | Mass Slaughter | DNA-playlist-exportregistratie |
| Sleeze Beez | [Screwed, Blued & Tattooed](https://open.spotify.com/track/2gS0MZUZu8xKxJbD7QXZBz) | Live In Tokyo | DNA-playlist-exportregistratie |
| Spread Eagle | [Switchblade Serenade](https://open.spotify.com/track/3ubPquUIL4gzFghyGG0nsK) | Spread Eagle | DNA-playlist-exportregistratie |
| Tesla | [Modern Day Cowboy](https://open.spotify.com/track/5ZIU2kT1wNjQNclQeVCz5O) | Mechanical Resonance | DNA-playlist-exportregistratie |
| Vain | [Beat the Bullet](https://open.spotify.com/track/4xgqf2xJ8eaSKXRwYafEYf) | No Respect | DNA-playlist-exportregistratie |
| Vinnie Vincent Invasion | [Dirty Rhythm - Remastered 2003](https://open.spotify.com/track/6hkkco5FXywlf1Kjqwc3o3) | All Systems Go (Remastered 2003) | DNA-playlist-exportregistratie |
| Vixen | [Edge Of A Broken Heart](https://open.spotify.com/track/2mEk0VdrbDJ11DBC6Y92mh) | Vixen | DNA-playlist-exportregistratie |
| Wildside | [Hang on Lucy](https://open.spotify.com/track/7jCoAuyOqLo80pWgveaW1I) | U.T.I. - 20th Anniversary Special Edition | DNA-playlist-exportregistratie |

## The  Last Hardrock Goldmine DNA

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Badlands | [Healer](https://open.spotify.com/track/03JcK7UUadSCIn6hAjI4p2) | Dusk | Masterregistratie |
| Circus Of Power | [Machine](https://open.spotify.com/track/2mMJzyMsDvIvOCUDvmEQzF) | Circus Of Power | Masterregistratie |
| David Lee Roth | [Just Like Paradise](https://open.spotify.com/track/5ZY7Gug850kv4heJcWZGHM) | Skyscraper | Masterregistratie |
| Dio | [Rock 'n' Roll Children - 2016 Remaster](https://open.spotify.com/track/4QsUCXM0HsaPS55CIupTo2) | Sacred Heart (2016 Remaster) | Masterregistratie |
| Fatal Smile | [S.o.b.](https://open.spotify.com/track/0viieRils7yJcwKRKnkMP2) | World Domination | Masterregistratie |
| Kickin Valentina | [Somebody New](https://open.spotify.com/track/2runRlofsbXcoWyOFUPmPA) | The Revenge Of Rock | Masterregistratie |
| Rhino Bucket | [Beat to Death Like a Dog](https://open.spotify.com/track/75P9eJ4OtShvS70Zw1KXNF) | Get Used To It | Masterregistratie |
| Scorpions | [Rock You Like a Hurricane - 2015 - Remaster](https://open.spotify.com/track/58dBJivB6lbAY5irCuAxJX) | Love At First Sting | Masterregistratie |
| Sebastian Bach | [American Metalhead](https://open.spotify.com/track/1YtsPIJHkdloi2nu6SvhH4) | Angel Down | Masterregistratie |
| Van Halen | [And the Cradle Will Rock... - 2015 Remaster](https://open.spotify.com/track/4MM0jT9z9m7VFiusFrGJ8C) | Women and Children First (Remastered) | Masterregistratie |
| Vengeance | [Dreamworld](https://open.spotify.com/track/3NA16mkVUx0OMfzEdWA1bf) | Collections | Masterregistratie |
| Vince Neil | [You're Invited (But Your Friend Can't Come)](https://open.spotify.com/track/5Veev1IuoCARMvYpmXD5kj) | Exposed | Masterregistratie |
| W.A.S.P. | [I Wanna Be Somebody](https://open.spotify.com/track/6w8dBm5KlXxWejYrbGS1EJ) | W.A.S.P. | Masterregistratie |

## The Last Hardrock Goldmine DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Badlands | [Healer](https://open.spotify.com/track/03JcK7UUadSCIn6hAjI4p2) | Dusk | DNA-playlist-exportregistratie |
| Circus Of Power | [Machine](https://open.spotify.com/track/2mMJzyMsDvIvOCUDvmEQzF) | Circus Of Power | DNA-playlist-exportregistratie |
| David Lee Roth | [Just Like Paradise](https://open.spotify.com/track/5ZY7Gug850kv4heJcWZGHM) | Skyscraper | DNA-playlist-exportregistratie |
| Dio | [Rock 'n' Roll Children - 2016 Remaster](https://open.spotify.com/track/4QsUCXM0HsaPS55CIupTo2) | Sacred Heart (2016 Remaster) | DNA-playlist-exportregistratie |
| Fatal Smile | [S.o.b.](https://open.spotify.com/track/0viieRils7yJcwKRKnkMP2) | World Domination | DNA-playlist-exportregistratie |
| Kickin Valentina | [Somebody New](https://open.spotify.com/track/2runRlofsbXcoWyOFUPmPA) | The Revenge Of Rock | DNA-playlist-exportregistratie |
| Rhino Bucket | [Beat to Death Like a Dog](https://open.spotify.com/track/75P9eJ4OtShvS70Zw1KXNF) | Get Used To It | DNA-playlist-exportregistratie |
| Scorpions | [Rock You Like a Hurricane - 2015 - Remaster](https://open.spotify.com/track/58dBJivB6lbAY5irCuAxJX) | Love At First Sting | DNA-playlist-exportregistratie |
| Sebastian Bach | [American Metalhead](https://open.spotify.com/track/1YtsPIJHkdloi2nu6SvhH4) | Angel Down | DNA-playlist-exportregistratie |
| Van Halen | [And the Cradle Will Rock... - 2015 Remaster](https://open.spotify.com/track/4MM0jT9z9m7VFiusFrGJ8C) | Women and Children First (Remastered) | DNA-playlist-exportregistratie |
| Vengeance | [Dreamworld](https://open.spotify.com/track/3NA16mkVUx0OMfzEdWA1bf) | Collections | DNA-playlist-exportregistratie |
| Vince Neil | [You're Invited (But Your Friend Can't Come)](https://open.spotify.com/track/5Veev1IuoCARMvYpmXD5kj) | Exposed | DNA-playlist-exportregistratie |
| W.A.S.P. | [I Wanna Be Somebody](https://open.spotify.com/track/6w8dBm5KlXxWejYrbGS1EJ) | W.A.S.P. | DNA-playlist-exportregistratie |

## Too Late For The Hair Metal Party DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Airkraft | [Heaven](https://open.spotify.com/track/2MGGeF00phi0YVvajKrthc) | In The Red | DNA-playlist-exportregistratie |
| Alias | [One More Chance](https://open.spotify.com/track/4AxB2cpS07IqbolZ4VA5B2) | Alias | DNA-playlist-exportregistratie |
| Angelica | [Time And Time Again](https://open.spotify.com/track/0a6kglbV52TaC4RY01dCq9) | Walkin' In Faith (Remastered) | DNA-playlist-exportregistratie |
| Bang Tango | [Someone Like You](https://open.spotify.com/track/0ebrUqGYac6Hh1nCF6ex3Y) | The Ultimate Bang Tango - Rockers & Thieves | DNA-playlist-exportregistratie |
| Britny Fox | [Girlschool](https://open.spotify.com/track/3SLutZby4IG3BISQVzCesq) | The Best Of Britny Fox | DNA-playlist-exportregistratie |
| Bulletboys | [Smooth up in Ya](https://open.spotify.com/track/5QoTdzVSygZB3SRxgFUANZ) | Bulletboys | DNA-playlist-exportregistratie |
| Crystavox | [Power Games](https://open.spotify.com/track/3ao5UhNlUUIdrRGFZZJFb7) | Crystavox | DNA-playlist-exportregistratie |
| Dangerous Toys | [Scared](https://open.spotify.com/track/4Rtx0zFndC7iDhZpIcJbT3) | Dangerous Toys | DNA-playlist-exportregistratie |
| Dirty White Boy | [Let's Spend Momma's Money](https://open.spotify.com/track/6o0hQH5YEno9mmEll9biox) | Bad Reputation | DNA-playlist-exportregistratie |
| Dream Police | [Rock Me](https://open.spotify.com/track/0UG2cMyIPWU5cXGNsweAlL) | Dream Police | DNA-playlist-exportregistratie |
| Eyes | [Young And Innocent](https://open.spotify.com/track/47sftmA1pVBWn6C6Sf4suV) | Eyes | DNA-playlist-exportregistratie |
| Firehouse | [Shake & Tumble (2024 Remaster)](https://open.spotify.com/track/4MLmEX0LoKw9TB26bWYLEe) | Firehouse (2024 Remaster) | DNA-playlist-exportregistratie |
| Holy Soldier | [Stranger](https://open.spotify.com/track/7e9Xot4Q5hhRdbJ6JVLF1m) | Holy Soldier | DNA-playlist-exportregistratie |
| Jackyl | [The Lumberjack](https://open.spotify.com/track/6Lm7q87UKarM7YtgLxUOq4) | Jackyl 25 | DNA-playlist-exportregistratie |
| Jetboy | [Feel The Shake](https://open.spotify.com/track/0THwi7rnD74mtPYgSjGj8B) | 80s Metal Essentials | DNA-playlist-exportregistratie |
| Killer Dwarfs | [Dirty Weapons](https://open.spotify.com/track/54VcCazvrKLfR8xdMFChW4) | Dirty Weapons | DNA-playlist-exportregistratie |
| Lostboys | [Lost And Found](https://open.spotify.com/track/57FdV3Vwi2Qwj15ziHxAKd) | Lost And Found | DNA-playlist-exportregistratie |
| Sleeze Beez | [Screwed, Blued & Tattooed](https://open.spotify.com/track/2gS0MZUZu8xKxJbD7QXZBz) | Live In Tokyo | DNA-playlist-exportregistratie |
| Spread Eagle | [Switchblade Serenade](https://open.spotify.com/track/3ubPquUIL4gzFghyGG0nsK) | Spread Eagle | DNA-playlist-exportregistratie |
| Stranger | [Let Me Rock-N-Roll](https://open.spotify.com/track/0IjyqeMq97Ydmbp4MyodnP) | No More Dirty Deals | DNA-playlist-exportregistratie |
| The Quireboys | [Sex Party](https://open.spotify.com/track/6SaqcLqM70Gzl6DbUbGpQC) | A Bit Of What You Fancy | DNA-playlist-exportregistratie |
| Vain | [Beat the Bullet](https://open.spotify.com/track/4xgqf2xJ8eaSKXRwYafEYf) | No Respect | DNA-playlist-exportregistratie |
| Vinnie Vincent Invasion | [Dirty Rhythm - Remastered 2003](https://open.spotify.com/track/6hkkco5FXywlf1Kjqwc3o3) | All Systems Go (Remastered 2003) | DNA-playlist-exportregistratie |
| Wildside | [Hang on Lucy](https://open.spotify.com/track/7jCoAuyOqLo80pWgveaW1I) | U.T.I. - 20th Anniversary Special Edition | DNA-playlist-exportregistratie |

## WASP Band DNA  [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Armored Saint | [Can U Deliver](https://open.spotify.com/track/25kORdST1xzG4WXOnzJCKV) | March Of The Saint | DNA-playlist-exportregistratie |
| Lizzy Borden | [Me Against the World](https://open.spotify.com/track/0r1OaClQOS9UGAqb49CqB1) | Visual Lies (Remastered) | DNA-playlist-exportregistratie |
| Malice | [License to Kill](https://open.spotify.com/track/0oDC3JcCtcJi6sgMMPIgxM) | License To Kill | DNA-playlist-exportregistratie |
| Ratt | [Lay It Down](https://open.spotify.com/track/3D5ORNm9spaTcdRx50ksHx) | Invasion of Your Privacy | DNA-playlist-exportregistratie |

## DNA SPECIAL 05

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bon Jovi | [Runaway](https://open.spotify.com/track/0X1sqQ652p1sceKM2nJlIJ) | Bon Jovi | Masterregistratie |
| Damn Yankees | [Coming of Age](https://open.spotify.com/track/1VMqkvlOqaH0HP0nsj1bx5) | Damn Yankees | Masterregistratie |
| Def Leppard | [Animal](https://open.spotify.com/track/4qjscZh4jfhkpcQG4ZQfi2) | Hysteria | Masterregistratie |
| Faster Pussycat | [Babylon](https://open.spotify.com/track/2Mt7VAy2lQLDxRTMtK5Oue) | Faster Pussycat | Masterregistratie |
| Hardcore Superstar | [We Don't Celebrate Sundays](https://open.spotify.com/track/2j4XBnBAtzDVzJPUMoOyDF) | Hardcore Superstar [Reloaded] | Masterregistratie |
| King Kobra | [Iron Eagle (Never Say Die)](https://open.spotify.com/track/3tD4AR8vbvM0b9X09YBYE0) | Thrill Of A Lifetime | Masterregistratie |
| Lipz | [Get It On](https://open.spotify.com/track/0ti0aAg5xZd7JW8KGU9ROX) | Scaryman | Masterregistratie |
| Michael Monroe | [Dead, Jail Or Rock 'N' Roll](https://open.spotify.com/track/3hMxAPl8lko0bnq7C0qPbW) | Not Fakin' It | Masterregistratie |
| Nelson | [After The Rain - Remastered 2017](https://open.spotify.com/track/3VWGHiQO7fArciqoKB2DSx) | After The Rain (Remastered) | Masterregistratie |
| Poison | [Talk Dirty To Me](https://open.spotify.com/track/01R0Xdwje645C6xFCnMRvm) | Look What The Cat Dragged In | Masterregistratie |
| Roxx Gang | [Scratch My Back](https://open.spotify.com/track/6hP3lbXemPQLx6QiKJ1z5v) | Bodacious Ta Tas: The Best of Roxx Gang | Masterregistratie |
| Steel Panther | [Death To All But Metal](https://open.spotify.com/track/0S6LJ0NSDynIsCptVBZdfy) | Feel The Steel | Masterregistratie |
| The Darkness | [One Way Ticket](https://open.spotify.com/track/44x9GdJsYmbaYRBm8ROyfL) | One Way Ticket to Hell... and Back | Masterregistratie |
| ToxicRose | [World of Confusion](https://open.spotify.com/track/1sPj9IM8jxDoMdVzefLKHj) | Total Tranquility | Masterregistratie |
| Warrant | [Cherry Pie](https://open.spotify.com/track/18ESXa5mEm1V4Pkt5GSXWx) | Cherry Pie (Expanded Edition) | Masterregistratie |

## DNA SPECIAL 05 Haar Omhoog Dak Eraf [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bon Jovi | [Runaway](https://open.spotify.com/track/0X1sqQ652p1sceKM2nJlIJ) | Bon Jovi | DNA-playlist-exportregistratie |
| Damn Yankees | [Coming of Age](https://open.spotify.com/track/1VMqkvlOqaH0HP0nsj1bx5) | Damn Yankees | DNA-playlist-exportregistratie |
| Def Leppard | [Animal](https://open.spotify.com/track/4qjscZh4jfhkpcQG4ZQfi2) | Hysteria | DNA-playlist-exportregistratie |
| Faster Pussycat | [Babylon](https://open.spotify.com/track/2Mt7VAy2lQLDxRTMtK5Oue) | Faster Pussycat | DNA-playlist-exportregistratie |
| Hardcore Superstar | [We Don't Celebrate Sundays](https://open.spotify.com/track/2j4XBnBAtzDVzJPUMoOyDF) | Hardcore Superstar [Reloaded] | DNA-playlist-exportregistratie |
| King Kobra | [Iron Eagle (Never Say Die)](https://open.spotify.com/track/3tD4AR8vbvM0b9X09YBYE0) | Thrill Of A Lifetime | DNA-playlist-exportregistratie |
| Lipz | [Get It On](https://open.spotify.com/track/0ti0aAg5xZd7JW8KGU9ROX) | Scaryman | DNA-playlist-exportregistratie |
| Michael Monroe | [Dead, Jail Or Rock 'N' Roll](https://open.spotify.com/track/3hMxAPl8lko0bnq7C0qPbW) | Not Fakin' It | DNA-playlist-exportregistratie |
| Nelson | [After The Rain - Remastered 2017](https://open.spotify.com/track/3VWGHiQO7fArciqoKB2DSx) | After The Rain (Remastered) | DNA-playlist-exportregistratie |
| Poison | [Talk Dirty To Me](https://open.spotify.com/track/01R0Xdwje645C6xFCnMRvm) | Look What The Cat Dragged In | DNA-playlist-exportregistratie |
| Roxx Gang | [Scratch My Back](https://open.spotify.com/track/6hP3lbXemPQLx6QiKJ1z5v) | Bodacious Ta Tas: The Best of Roxx Gang | DNA-playlist-exportregistratie |
| Steel Panther | [Death To All But Metal](https://open.spotify.com/track/0S6LJ0NSDynIsCptVBZdfy) | Feel The Steel | DNA-playlist-exportregistratie |
| The Darkness | [One Way Ticket](https://open.spotify.com/track/44x9GdJsYmbaYRBm8ROyfL) | One Way Ticket to Hell... and Back | DNA-playlist-exportregistratie |
| ToxicRose | [World of Confusion](https://open.spotify.com/track/1sPj9IM8jxDoMdVzefLKHj) | Total Tranquility | DNA-playlist-exportregistratie |
| Warrant | [Cherry Pie](https://open.spotify.com/track/18ESXa5mEm1V4Pkt5GSXWx) | Cherry Pie (Expanded Edition) | DNA-playlist-exportregistratie |

## DNA SPECIAL 06

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Coney Hatch | [Some Like It Hot](https://open.spotify.com/track/68oRkANDPCQ6EegIVdzwgx) | Outa Hand | Masterregistratie |
| Crash Kelly | [She Gets Away](https://open.spotify.com/track/1kTPKqk6vMojgGGgsfumiq) | Penny Pills | Masterregistratie |
| Firehouse | [Shake & Tumble (2024 Remaster)](https://open.spotify.com/track/4MLmEX0LoKw9TB26bWYLEe) | Firehouse (2024 Remaster) | Masterregistratie |
| Mitch Malloy | [Anything at All](https://open.spotify.com/track/3AmZlfEuOqyoOfgqrbFPkh) | Mitch Malloy (Remastered) | Masterregistratie |
| Mr. Big | [Wind Me Up - 2009 Remastered Version](https://open.spotify.com/track/4w6cB76PxVcBMwyKval9Tz) | Mr. Big [Expanded] | Masterregistratie |
| Q5 | [Pull the Trigger](https://open.spotify.com/track/3sxvhBZLZF8siHd0LyKFyK) | Steel the Light | Masterregistratie |
| Romeo's Daughter | [Attracted to the Animal](https://open.spotify.com/track/38NGH3zk3juJ4fz8nfiqmQ) | Delectable | Masterregistratie |
| Salty Dog | [Come Along](https://open.spotify.com/track/37RCRKa0LpuR6joRsPl0sO) | Every Dog Has Its Day | Masterregistratie |
| Shotgun Messiah | [Heartbreak Blvd.](https://open.spotify.com/track/3e3pkp0mPrSH3RC6qwiRFi) | Second Coming | Masterregistratie |
| Snakebite | [Two Desperate Hearts](https://open.spotify.com/track/6k0ZSzyUBMglF65AwnMvTm) | Rise of the Snake | Masterregistratie |
| Stolen Prayer | [Move on You](https://open.spotify.com/track/3KxPCmDDwWEdM2fBLRQIos) | Stolen Prayer II | Masterregistratie |
| Tora Tora | [Amnesia](https://open.spotify.com/track/6woSuDAzfcyogEKqzISMk9) | Wild America | Masterregistratie |

## DNA SPECIAL 06 Gas Erop [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Coney Hatch | [Some Like It Hot](https://open.spotify.com/track/68oRkANDPCQ6EegIVdzwgx) | Outa Hand | DNA-playlist-exportregistratie |
| Crash Kelly | [She Gets Away](https://open.spotify.com/track/1kTPKqk6vMojgGGgsfumiq) | Penny Pills | DNA-playlist-exportregistratie |
| Firehouse | [Shake & Tumble (2024 Remaster)](https://open.spotify.com/track/4MLmEX0LoKw9TB26bWYLEe) | Firehouse (2024 Remaster) | DNA-playlist-exportregistratie |
| Mitch Malloy | [Anything at All](https://open.spotify.com/track/3AmZlfEuOqyoOfgqrbFPkh) | Mitch Malloy (Remastered) | DNA-playlist-exportregistratie |
| Mr. Big | [Wind Me Up - 2009 Remastered Version](https://open.spotify.com/track/4w6cB76PxVcBMwyKval9Tz) | Mr. Big [Expanded] | DNA-playlist-exportregistratie |
| Q5 | [Pull the Trigger](https://open.spotify.com/track/3sxvhBZLZF8siHd0LyKFyK) | Steel the Light | DNA-playlist-exportregistratie |
| Romeo's Daughter | [Attracted to the Animal](https://open.spotify.com/track/38NGH3zk3juJ4fz8nfiqmQ) | Delectable | DNA-playlist-exportregistratie |
| Salty Dog | [Come Along](https://open.spotify.com/track/37RCRKa0LpuR6joRsPl0sO) | Every Dog Has Its Day | DNA-playlist-exportregistratie |
| Shotgun Messiah | [Heartbreak Blvd.](https://open.spotify.com/track/3e3pkp0mPrSH3RC6qwiRFi) | Second Coming | DNA-playlist-exportregistratie |
| Snakebite | [Two Desperate Hearts](https://open.spotify.com/track/6k0ZSzyUBMglF65AwnMvTm) | Rise of the Snake | DNA-playlist-exportregistratie |
| Stolen Prayer | [Move on You](https://open.spotify.com/track/3KxPCmDDwWEdM2fBLRQIos) | Stolen Prayer II | DNA-playlist-exportregistratie |
| Tora Tora | [Amnesia](https://open.spotify.com/track/6woSuDAzfcyogEKqzISMk9) | Wild America | DNA-playlist-exportregistratie |

## DNA SPECIAL 100

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Skid Row | [18 and Life](https://open.spotify.com/track/0qgrrDnUUhyxpxbBznUnzg) | Skid Row | Masterregistratie |

## DNA SPECIAL 100 Honderd Specials · Dit is mijn DNA [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Skid Row | [18 and Life](https://open.spotify.com/track/0qgrrDnUUhyxpxbBznUnzg) | Skid Row | DNA-playlist-exportregistratie |

## DNA SPECIAL 103 Japan Achter de glitter

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| EZO | [HOUSE OF 1,000 PLEASURES](https://open.spotify.com/track/1hPFDHt7hCBKikYc56gJhR) | E・Z・O | Masterregistratie |

## DNA SPECIAL 104 — De glitter bleef

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Baby Jane | [My Behavior](https://open.spotify.com/track/1IJtqhXB7xi9IXqOmG7DLd) | In the Spotlight | Spotify-publicatie |
| Babylon Bombs | [Hometown Hero](https://open.spotify.com/track/5TqQnYIyisbHJiHXzkSK9u) | Doin' You Nasty | Spotify-publicatie |
| Billion Dollar Babies | [In the Back of My Limousine](https://open.spotify.com/track/3GdTrTfB4iHhVCSP5QKKTM) | House of Dreams Pt.1 | Spotify-publicatie |
| Bulletrain | [Memory Lane](https://open.spotify.com/track/3B1GcV5ViFxTMpX6bGcPnD) | What You Fear the Most | Spotify-publicatie |
| Gasoline Queen | [Broke, Cursed and Damned](https://open.spotify.com/track/09qJb7SQ5grUFEn58NawLo) | Gas for the Underclass | Spotify-publicatie |
| Hell N' Diesel | [Miss Cocaine](https://open.spotify.com/track/3pIYR84epkcf0zCfIMGipV) | Passion for Power | Spotify-publicatie |
| Laney's Legion | [Taste of Your Tongue](https://open.spotify.com/track/5XK4P3zE7DYnnwZUsBILMU) | Laney's Legion | Spotify-publicatie |
| Loud 'N' Nasty | [Stand Strong](https://open.spotify.com/track/4KOCQK92cOw8Pvx9haAa6p) | Stand Strong | Spotify-publicatie |
| NiteRain | [Lost and Wasted](https://open.spotify.com/track/7HgInZAuyMC2h5oIEkvEa8) | Vendetta | Spotify-publicatie |
| Sons Of Angels | [Spend the Night](https://open.spotify.com/track/4sbhYTms1UZc3tLJOmiWP6) | Sons Of Angels | Spotify-publicatie |
| Suicide Bombers | [So Bad](https://open.spotify.com/track/5drLgudNh1wkMD3kvtUyiq) | Murder Couture | Spotify-publicatie |
| Swedish Erotica | [Rock'n'Roll City](https://open.spotify.com/track/7HKkpIjafs6ufCZlXJgvAj) | Swedish Erotica | Spotify-publicatie |
| Sweet Creature | [This Town Is Dead](https://open.spotify.com/track/0fSeONddkwt7Vb3zvuj4Fw) | This Town Is Dead | Spotify-publicatie |
| Wildnite | [I'll Be There](https://open.spotify.com/track/7sUYjUNdts2w5bGSrtm2Sd) | Wildnite | Spotify-publicatie |
| Zan Clan | [Go Go Go](https://open.spotify.com/track/6vPsyfpxShe0Sa2ltKhzFm) | We Are Zan Clan... | Spotify-publicatie |

## DNA SPECIAL 13

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Gemini Five | [You Spin Me Round (Like A Record)](https://open.spotify.com/track/2BLD6EM0kaOQhPfuwANW4Q) | Babylon Rockets | Masterregistratie |
| Jake E. Lee;Lemmy | [It’s A Long Way To The Top](https://open.spotify.com/track/06WVG8EF6JxiPTpkBQrIGI) | Guitar Warrior | Masterregistratie |

## DNA SPECIAL 13 Ken ik ... maar niet zo! [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Gemini Five | [You Spin Me Round (Like A Record)](https://open.spotify.com/track/2BLD6EM0kaOQhPfuwANW4Q) | Babylon Rockets | DNA-playlist-exportregistratie |
| Jake E. Lee;Lemmy | [It’s A Long Way To The Top](https://open.spotify.com/track/06WVG8EF6JxiPTpkBQrIGI) | Guitar Warrior | DNA-playlist-exportregistratie |

## DNA SPECIAL 15

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Andy Timmons | [Groove or Die](https://open.spotify.com/track/2vLm4hsLeMMfcqaVlj4PKN) | That Was Then, This Is Now | Masterregistratie |
| Racer X | [Technical Difficulties](https://open.spotify.com/track/6z6hCyOaWbqYKAlgeA6U3d) | Technical Difficulties | Masterregistratie |

## DNA SPECIAL 15 Geen zanger nodig [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Andy Timmons | [Groove or Die](https://open.spotify.com/track/2vLm4hsLeMMfcqaVlj4PKN) | That Was Then, This Is Now | DNA-playlist-exportregistratie |
| Racer X | [Technical Difficulties](https://open.spotify.com/track/6z6hCyOaWbqYKAlgeA6U3d) | Technical Difficulties | DNA-playlist-exportregistratie |

## DNA SPECIAL 18

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Girlschool | [Race with the Devil](https://open.spotify.com/track/3D8KAebbZgAFdVjTrsNgOI) | Demolition | Masterregistratie |

## DNA SPECIAL 18 Vrouwen vooraan [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Girlschool | [Race with the Devil](https://open.spotify.com/track/3D8KAebbZgAFdVjTrsNgOI) | Demolition | DNA-playlist-exportregistratie |

## DNA SPECIAL 21

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alien | [Give It Up](https://open.spotify.com/track/1nDOVQ2ioOrnE7SfJT0rvO) | Shiftin' Gear | Masterregistratie |
| Electric Boys | [Suffer](https://open.spotify.com/track/597sFLu5mDcNFyRkaiNSgW) | Suffer | Masterregistratie |
| Europe | [The Final Countdown](https://open.spotify.com/track/3MrRksHupTVEQ7YbA0FsZK) | The Final Countdown (Expanded Edition) | Masterregistratie |
| Yngwie Malmsteen | [You Don't Remember, I'll Never Forget](https://open.spotify.com/track/2O6g3yvCX7vdcj6yKfdYl1) | Trilogy | Masterregistratie |

## DNA SPECIAL 21 Zweden; Melodie uit het noorden [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alien | [Give It Up](https://open.spotify.com/track/1nDOVQ2ioOrnE7SfJT0rvO) | Shiftin' Gear | DNA-playlist-exportregistratie |
| Electric Boys | [Suffer](https://open.spotify.com/track/597sFLu5mDcNFyRkaiNSgW) | Suffer | DNA-playlist-exportregistratie |
| Europe | [The Final Countdown](https://open.spotify.com/track/3MrRksHupTVEQ7YbA0FsZK) | The Final Countdown (Expanded Edition) | DNA-playlist-exportregistratie |
| Yngwie Malmsteen | [You Don't Remember, I'll Never Forget](https://open.spotify.com/track/2O6g3yvCX7vdcj6yKfdYl1) | Trilogy | DNA-playlist-exportregistratie |

## DNA SPECIAL 22

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Hanoi Rocks | [Up Around the Bend](https://open.spotify.com/track/58jMdhU11g7JdvrBSlaIk2) | Two Steps From The Move | Masterregistratie |
| Reckless Love | [Hot](https://open.spotify.com/track/5H6eTrcDfPAHXAHWrR7Q5M) | Animal Attraction | Masterregistratie |
| Shiraz Lane | [To The Moon & Back](https://open.spotify.com/track/0jCiQXabUrZmAfGXEbo3WF) | To The Moon & Back | Masterregistratie |

## DNA SPECIAL 22 Finland; Donker licht [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Hanoi Rocks | [Up Around the Bend](https://open.spotify.com/track/58jMdhU11g7JdvrBSlaIk2) | Two Steps From The Move | DNA-playlist-exportregistratie |
| Reckless Love | [Hot](https://open.spotify.com/track/5H6eTrcDfPAHXAHWrR7Q5M) | Animal Attraction | DNA-playlist-exportregistratie |
| Shiraz Lane | [To The Moon & Back](https://open.spotify.com/track/0jCiQXabUrZmAfGXEbo3WF) | To The Moon & Back | DNA-playlist-exportregistratie |

## DNA SPECIAL 23

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Scorpions | [Rock You Like a Hurricane - 2015 - Remaster](https://open.spotify.com/track/2fICdpdRotwfmGYzvs8Ngf) | Love At First Sting (Deluxe Edition) | Masterregistratie |
| Warlock | [All We Are](https://open.spotify.com/track/2dU4FegjbgW5qkdrUdzogT) | Triumph And Agony | Masterregistratie |

## DNA SPECIAL 23 Duitsland; Staal en stroom [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Scorpions | [Rock You Like a Hurricane - 2015 - Remaster](https://open.spotify.com/track/2fICdpdRotwfmGYzvs8Ngf) | Love At First Sting (Deluxe Edition) | DNA-playlist-exportregistratie |
| Warlock | [All We Are](https://open.spotify.com/track/2dU4FegjbgW5qkdrUdzogT) | Triumph And Agony | DNA-playlist-exportregistratie |

## DNA SPECIAL 24

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Cobra Spell | [The Devil Inside of Me](https://open.spotify.com/track/5jL5h2D7ZCKLU0c1FtaTQf) | 666 | Masterregistratie |
| Zinatra | [Two Sides of Love](https://open.spotify.com/track/3JqYYx1tjKYlpnbSIm8Hc1) | Rockumentary Part 2 | Masterregistratie |

## DNA SPECIAL 24 Nederland; Van polder tot prog [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Cobra Spell | [The Devil Inside of Me](https://open.spotify.com/track/5jL5h2D7ZCKLU0c1FtaTQf) | 666 | DNA-playlist-exportregistratie |
| Zinatra | [Two Sides of Love](https://open.spotify.com/track/3JqYYx1tjKYlpnbSIm8Hc1) | Rockumentary Part 2 | DNA-playlist-exportregistratie |

## DNA SPECIAL 25

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Aldo Nova | [Fantasy](https://open.spotify.com/track/1zrba5qe6xkC84AlbXNa6u) | Aldo Nova | Masterregistratie |

## DNA SPECIAL 25 Canada; Hard maar melodieus [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Aldo Nova | [Fantasy](https://open.spotify.com/track/1zrba5qe6xkC84AlbXNa6u) | Aldo Nova | DNA-playlist-exportregistratie |

## DNA SPECIAL 27

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Hitten | [Eyes Never Lie](https://open.spotify.com/track/0U0t9b69VJjXXvPpgWPEWY) | Triumph & Tragedy | Masterregistratie |
| The Unripes | [Reload](https://open.spotify.com/track/67DOuWJIFmZQAEKnGXIqHY) | This Is Not America | Masterregistratie |

## DNA SPECIAL 27 Zuid-Europa; Van Italië tot Iberië [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Hitten | [Eyes Never Lie](https://open.spotify.com/track/0U0t9b69VJjXXvPpgWPEWY) | Triumph & Tragedy | DNA-playlist-exportregistratie |
| The Unripes | [Reload](https://open.spotify.com/track/67DOuWJIFmZQAEKnGXIqHY) | This Is Not America | DNA-playlist-exportregistratie |

## DNA SPECIAL 28

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Gorky Park | [Within Your Eyes](https://open.spotify.com/track/35OQaDlJMzWRVpXObP7k9x) | Gorky Park | Masterregistratie |
| Nasty Ratz | [All Night Long](https://open.spotify.com/track/6cdtQmOoaweSXXzoXkiXWP) | Third Cut | Masterregistratie |

## DNA SPECIAL 28 Oost-Europa; Achter het voormalige gordijn [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Gorky Park | [Within Your Eyes](https://open.spotify.com/track/35OQaDlJMzWRVpXObP7k9x) | Gorky Park | DNA-playlist-exportregistratie |
| Nasty Ratz | [All Night Long](https://open.spotify.com/track/6cdtQmOoaweSXXzoXkiXWP) | Third Cut | DNA-playlist-exportregistratie |

## DNA SPECIAL 29

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| D-A-D | [Sleeping My Day Away - 2009 - Remaster](https://open.spotify.com/track/5ZuXgk0enEvv2HlnUe2rj3) | No Fuel Left for the Pilgrims (2009 - Remastered) | Masterregistratie |
| Wig Wam | [Gonna Get You Someday](https://open.spotify.com/track/5zULoNWVx5FkBROAo9ce9w) | Wig Wamania | Masterregistratie |

## DNA SPECIAL 29 Noord-Europa; Van de fjorden tot de Oostzee [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| D-A-D | [Sleeping My Day Away - 2009 - Remaster](https://open.spotify.com/track/5ZuXgk0enEvv2HlnUe2rj3) | No Fuel Left for the Pilgrims (2009 - Remastered) | DNA-playlist-exportregistratie |
| Wig Wam | [Gonna Get You Someday](https://open.spotify.com/track/5zULoNWVx5FkBROAo9ce9w) | Wig Wamania | DNA-playlist-exportregistratie |

## DNA SPECIAL 30

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Exxocet | [Spyders Nest](https://open.spotify.com/track/5sHMCmSE4kAuCZ2dYoiuYY) | Dagger Constellations | Masterregistratie |

## DNA SPECIAL 30 Brazilië & Latijns-Amerika; Zuidwaarts [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Exxocet | [Spyders Nest](https://open.spotify.com/track/5sHMCmSE4kAuCZ2dYoiuYY) | Dagger Constellations | DNA-playlist-exportregistratie |

## DNA SPECIAL 34

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Autograph | [Turn up the Radio](https://open.spotify.com/track/7u0b4DthVvd2F2EzCiOx0Z) | Sign In Please | Masterregistratie |
| Honeymoon Suite | [Burning in Love](https://open.spotify.com/track/4vCR2DqRydeYDvZQkfzBmE) | Honeymoon Suite | Masterregistratie |
| Sammy Hagar | [I Can't Drive 55](https://open.spotify.com/track/1MqGKtY9L5qjPi8s7gX645) | Voa | Masterregistratie |
| Stage Dolls | [Soldiers Gun](https://open.spotify.com/track/74vPDjq1Me3iRffUP4kC4W) | Soldiers Gun | Masterregistratie |
| Stone Fury | [Break Down The Wall](https://open.spotify.com/track/7zevYZAJYMgEUu8rHDaxLR) | Burns Like A Star | Masterregistratie |
| Zebra | [As I Said Before](https://open.spotify.com/track/3DQUOnH5OKGjXXnfKGj0UT) | Zebra | Masterregistratie |

## DNA SPECIAL 34 1983–1986; Alles wordt groter [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Autograph | [Turn up the Radio](https://open.spotify.com/track/7u0b4DthVvd2F2EzCiOx0Z) | Sign In Please | DNA-playlist-exportregistratie |
| Bon Jovi | [Runaway](https://open.spotify.com/track/0X1sqQ652p1sceKM2nJlIJ) | Bon Jovi | DNA-playlist-exportregistratie |
| Honeymoon Suite | [Burning in Love](https://open.spotify.com/track/4vCR2DqRydeYDvZQkfzBmE) | Honeymoon Suite | DNA-playlist-exportregistratie |
| Poison | [Talk Dirty To Me](https://open.spotify.com/track/01R0Xdwje645C6xFCnMRvm) | Look What The Cat Dragged In | DNA-playlist-exportregistratie |
| Q5 | [Pull the Trigger](https://open.spotify.com/track/3sxvhBZLZF8siHd0LyKFyK) | Steel the Light | DNA-playlist-exportregistratie |
| Sammy Hagar | [I Can't Drive 55](https://open.spotify.com/track/1MqGKtY9L5qjPi8s7gX645) | Voa | DNA-playlist-exportregistratie |
| Stage Dolls | [Soldiers Gun](https://open.spotify.com/track/74vPDjq1Me3iRffUP4kC4W) | Soldiers Gun | DNA-playlist-exportregistratie |
| Stone Fury | [Break Down The Wall](https://open.spotify.com/track/7zevYZAJYMgEUu8rHDaxLR) | Burns Like A Star | DNA-playlist-exportregistratie |
| Zebra | [As I Said Before](https://open.spotify.com/track/3DQUOnH5OKGjXXnfKGj0UT) | Zebra | DNA-playlist-exportregistratie |

## DNA SPECIAL 35

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bonham;The Jason Bonham Band | [Wait for You](https://open.spotify.com/track/0LdPlZKpROaZMLkR0CBpz2) | The Disregard of Timekeeping | Masterregistratie |
| Signal | [Arms Of A Stranger](https://open.spotify.com/track/3gdnbF4xI6Lkql4vbFlZrM) | Loud & Clear | Masterregistratie |
| Valentine | [Runnin' on Luck Again](https://open.spotify.com/track/4WCJHjC64YImYYaHt6q1nJ) | Valentine | Masterregistratie |

## DNA SPECIAL 35 1987–1990; Hoogtepunt vóór de breuk [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bonham;The Jason Bonham Band | [Wait for You](https://open.spotify.com/track/0LdPlZKpROaZMLkR0CBpz2) | The Disregard of Timekeeping | DNA-playlist-exportregistratie |
| Damn Yankees | [Coming of Age](https://open.spotify.com/track/1VMqkvlOqaH0HP0nsj1bx5) | Damn Yankees | DNA-playlist-exportregistratie |
| Def Leppard | [Animal](https://open.spotify.com/track/4qjscZh4jfhkpcQG4ZQfi2) | Hysteria | DNA-playlist-exportregistratie |
| Nelson | [After The Rain - Remastered 2017](https://open.spotify.com/track/3VWGHiQO7fArciqoKB2DSx) | After The Rain (Remastered) | DNA-playlist-exportregistratie |
| Signal | [Arms Of A Stranger](https://open.spotify.com/track/3gdnbF4xI6Lkql4vbFlZrM) | Loud & Clear | DNA-playlist-exportregistratie |
| Valentine | [Runnin' on Luck Again](https://open.spotify.com/track/4WCJHjC64YImYYaHt6q1nJ) | Valentine | DNA-playlist-exportregistratie |

## DNA SPECIAL 36

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| T-ride | [Luxury Cruiser](https://open.spotify.com/track/0WtuL3WGbH1e0IMjwxUNjW) | T-ride | Masterregistratie |
| White Lion | [Lights and Thunder](https://open.spotify.com/track/4gpzP5C8xwbgSecdup8AX0) | Mane Attraction | Masterregistratie |

## DNA SPECIAL 36 1991–1994; De grote reset [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Shotgun Messiah | [Heartbreak Blvd.](https://open.spotify.com/track/3e3pkp0mPrSH3RC6qwiRFi) | Second Coming | DNA-playlist-exportregistratie |
| T-ride | [Luxury Cruiser](https://open.spotify.com/track/0WtuL3WGbH1e0IMjwxUNjW) | T-ride | DNA-playlist-exportregistratie |
| White Lion | [Lights and Thunder](https://open.spotify.com/track/4gpzP5C8xwbgSecdup8AX0) | Mane Attraction | DNA-playlist-exportregistratie |

## DNA SPECIAL 39 2005–2008; Nieuwe hardheid, oude wortels [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Hardcore Superstar | [We Don't Celebrate Sundays](https://open.spotify.com/track/2j4XBnBAtzDVzJPUMoOyDF) | Hardcore Superstar [Reloaded] | DNA-playlist-exportregistratie |
| The Darkness | [One Way Ticket](https://open.spotify.com/track/44x9GdJsYmbaYRBm8ROyfL) | One Way Ticket to Hell... and Back | DNA-playlist-exportregistratie |

## DNA SPECIAL 40

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bad City | [Take Me for a Ride](https://open.spotify.com/track/6iRoX4WbIeY9PQh5MNRPOm) | Welcome to the Wasteland | Masterregistratie |
| Vains Of Jenna | [Enemy In Me](https://open.spotify.com/track/3JP7RGrx1ORUsx2Idyr0Ba) | The Art of Telling Lies | Masterregistratie |

## DNA SPECIAL 40 2009–2012; Oud DNA, nieuwe motor [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bad City | [Take Me for a Ride](https://open.spotify.com/track/6iRoX4WbIeY9PQh5MNRPOm) | Welcome to the Wasteland | DNA-playlist-exportregistratie |
| Steel Panther | [Death To All But Metal](https://open.spotify.com/track/0S6LJ0NSDynIsCptVBZdfy) | Feel The Steel | DNA-playlist-exportregistratie |
| Vains Of Jenna | [Enemy In Me](https://open.spotify.com/track/3JP7RGrx1ORUsx2Idyr0Ba) | The Art of Telling Lies | DNA-playlist-exportregistratie |

## DNA SPECIAL 41

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| ZAR;John Lawton | [Heart of the Night](https://open.spotify.com/track/1o4dTuvn469vsQEeH1FEMn) | Live Your Life Forever | Masterregistratie |

## DNA SPECIAL 41 2013–2016; Retro wordt weer nieuw [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| ZAR;John Lawton | [Heart of the Night](https://open.spotify.com/track/1o4dTuvn469vsQEeH1FEMn) | Live Your Life Forever | DNA-playlist-exportregistratie |

## DNA SPECIAL 42

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Kissin' Dynamite | [You're Not Alone](https://open.spotify.com/track/7iiTqsPA1JyrifFT5uC8Mv) | Ecstasy | Masterregistratie |

## DNA SPECIAL 42 2017–2019; Grenzen lossen op [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Kissin' Dynamite | [You're Not Alone](https://open.spotify.com/track/7iiTqsPA1JyrifFT5uC8Mv) | Ecstasy | DNA-playlist-exportregistratie |

## DNA SPECIAL 44

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Adam Bomb;Cliff Williams of AC/DC | [I Want My Heavy Metal](https://open.spotify.com/track/1KYIpDjujE56pTLRXbWNmp) | Fatal Attraction | Masterregistratie |
| WANTED | [Under The Law](https://open.spotify.com/track/0Htw7MvGgRiLK2pFfCqfb1) | Under The Law | Masterregistratie |

## DNA SPECIAL 44 2023–2026; Hier staan we nu [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Adam Bomb;Cliff Williams of AC/DC | [I Want My Heavy Metal](https://open.spotify.com/track/1KYIpDjujE56pTLRXbWNmp) | Fatal Attraction | DNA-playlist-exportregistratie |
| WANTED | [Under The Law](https://open.spotify.com/track/0Htw7MvGgRiLK2pFfCqfb1) | Under The Law | DNA-playlist-exportregistratie |

## DNA SPECIAL 45

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alice Cooper | [Elected](https://open.spotify.com/track/32wcgD2iId0smNDyjUNvd8) | Billion Dollar Babies | Masterregistratie |

## DNA SPECIAL 45 1973; Prog op de top [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alice Cooper | [Elected](https://open.spotify.com/track/32wcgD2iId0smNDyjUNvd8) | Billion Dollar Babies | DNA-playlist-exportregistratie |

## DNA SPECIAL 47

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Armored Saint | [Can U Deliver](https://open.spotify.com/track/25kORdST1xzG4WXOnzJCKV) | March Of The Saint | Masterregistratie |
| Dokken | [Into the Fire](https://open.spotify.com/track/2QarjsUyOIxGeUA3sR1xSZ) | Tooth and Nail | Masterregistratie |
| Giuffria | [Do Me Right](https://open.spotify.com/track/1IsKwftNuXKGG9bjNXh7lU) | Giuffria | Masterregistratie |
| Helix | [Rock You](https://open.spotify.com/track/2sd8DUzBIaNBzkgEPGsHV6) | Walkin' The Razor's Edge | Masterregistratie |
| Twisted Sister | [I Wanna Rock](https://open.spotify.com/track/70Z9t1qhytWtG4cCmmi7mU) | Stay Hungry | Masterregistratie |
| W.A.S.P. | [I Wanna Be Somebody](https://open.spotify.com/track/6w8dBm5KlXxWejYrbGS1EJ) | W.A.S.P. | Masterregistratie |

## DNA SPECIAL 47 1984; Glans tegen staal [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Armored Saint | [Can U Deliver](https://open.spotify.com/track/25kORdST1xzG4WXOnzJCKV) | March Of The Saint | DNA-playlist-exportregistratie |
| Dokken | [Into the Fire](https://open.spotify.com/track/2QarjsUyOIxGeUA3sR1xSZ) | Tooth and Nail | DNA-playlist-exportregistratie |
| Giuffria | [Do Me Right](https://open.spotify.com/track/1IsKwftNuXKGG9bjNXh7lU) | Giuffria | DNA-playlist-exportregistratie |
| Helix | [Rock You](https://open.spotify.com/track/2sd8DUzBIaNBzkgEPGsHV6) | Walkin' The Razor's Edge | DNA-playlist-exportregistratie |
| Twisted Sister | [I Wanna Rock](https://open.spotify.com/track/70Z9t1qhytWtG4cCmmi7mU) | Stay Hungry | DNA-playlist-exportregistratie |
| W.A.S.P. | [I Wanna Be Somebody](https://open.spotify.com/track/6w8dBm5KlXxWejYrbGS1EJ) | W.A.S.P. | DNA-playlist-exportregistratie |

## DNA SPECIAL 48

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Fair Warning | [When Love Fails](https://open.spotify.com/track/2Sr3ftfmJmVjUJQNLRhikj) | Fair Warning | Masterregistratie |
| GIANT | [Thunder and Lightning](https://open.spotify.com/track/3A8tmh1KAnThMGLyXpym3e) | Time To Burn | Masterregistratie |
| Hardline | [Takin' Me Down](https://open.spotify.com/track/0ykRm2cMP8ku2qRj5UpEsg) | Double Eclipse | Masterregistratie |

## DNA SPECIAL 48 1992; Na de aardverschuiving [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Fair Warning | [When Love Fails](https://open.spotify.com/track/2Sr3ftfmJmVjUJQNLRhikj) | Fair Warning | DNA-playlist-exportregistratie |
| GIANT | [Thunder and Lightning](https://open.spotify.com/track/3A8tmh1KAnThMGLyXpym3e) | Time To Burn | DNA-playlist-exportregistratie |
| Hardline | [Takin' Me Down](https://open.spotify.com/track/0ykRm2cMP8ku2qRj5UpEsg) | Double Eclipse | DNA-playlist-exportregistratie |

## DNA SPECIAL 50

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Santa Cruz | [Drag Me Down](https://open.spotify.com/track/6UBbdux7eI0m77auUWh4UD) | Drag Me Down | Masterregistratie |
| Tygers Of Pan Tang | [Only the Brave](https://open.spotify.com/track/5F4PRUrsZQ8zTppxd6OA9a) | Tygers of Pan Tang | Masterregistratie |

## DNA SPECIAL 50 2016; Oud geluid, nieuwe generatie [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Santa Cruz | [Drag Me Down](https://open.spotify.com/track/6UBbdux7eI0m77auUWh4UD) | Drag Me Down | DNA-playlist-exportregistratie |
| Tygers Of Pan Tang | [Only the Brave](https://open.spotify.com/track/5F4PRUrsZQ8zTppxd6OA9a) | Tygers of Pan Tang | DNA-playlist-exportregistratie |

## DNA SPECIAL 51

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Christian Shields | [Can't Get Enough](https://open.spotify.com/track/5YTPq05aU6HbePwPY5MWxA) | This Is Rock 'N' Roll | Masterregistratie |
| Dust Bowl Jokies | [Boots on Rocks Off](https://open.spotify.com/track/4ZhBsaHn2of6CW1I8cT7sn) | Cockaigne Vaudeville | Masterregistratie |
| John Diva & the Rockets of Love | [American Amadeus](https://open.spotify.com/track/5glmLXna7qATdV9Mx4ObQM) | American Amadeus | Masterregistratie |
| Quickstrike | [Rebel Radio](https://open.spotify.com/track/5WstrW5hHw0SQaUWL0RPNR) | None Of A Kind | Masterregistratie |
| Sixx:A.M. | [We Will Not Go Quietly](https://open.spotify.com/track/2mEIz07NTmDyTMmcGea25i) | Prayers for the Blessed | Masterregistratie |
| The Cruel Intentions | [Jawbreaker](https://open.spotify.com/track/42BMNYuOQFa7gefX7sCeRK) | No Sign of Relief | Masterregistratie |

## DNA SPECIAL 51 De riff beslist [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Christian Shields | [Can't Get Enough](https://open.spotify.com/track/5YTPq05aU6HbePwPY5MWxA) | This Is Rock 'N' Roll | DNA-playlist-exportregistratie |
| Dust Bowl Jokies | [Boots on Rocks Off](https://open.spotify.com/track/4ZhBsaHn2of6CW1I8cT7sn) | Cockaigne Vaudeville | DNA-playlist-exportregistratie |
| John Diva & the Rockets of Love | [American Amadeus](https://open.spotify.com/track/5glmLXna7qATdV9Mx4ObQM) | American Amadeus | DNA-playlist-exportregistratie |
| Quickstrike | [Rebel Radio](https://open.spotify.com/track/5WstrW5hHw0SQaUWL0RPNR) | None Of A Kind | DNA-playlist-exportregistratie |
| Sixx:A.M. | [We Will Not Go Quietly](https://open.spotify.com/track/2mEIz07NTmDyTMmcGea25i) | Prayers for the Blessed | DNA-playlist-exportregistratie |
| The Cruel Intentions | [Jawbreaker](https://open.spotify.com/track/42BMNYuOQFa7gefX7sCeRK) | No Sign of Relief | DNA-playlist-exportregistratie |

## DNA SPECIAL 52

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Streets | [If Love Should Go](https://open.spotify.com/track/3kAiPXqapVgYwOiISlcexP) | 1st | Masterregistratie |
| The Dogs D'Amour | [I Don't Want You to Go](https://open.spotify.com/track/4ABjFaFQHJN6gW2vx4D3lf) | In The Dynamite Jet Saloon | Masterregistratie |

## DNA SPECIAL 52 Melodie onder spanning [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Streets | [If Love Should Go](https://open.spotify.com/track/3kAiPXqapVgYwOiISlcexP) | 1st | DNA-playlist-exportregistratie |
| The Dogs D'Amour | [I Don't Want You to Go](https://open.spotify.com/track/4ABjFaFQHJN6gW2vx4D3lf) | In The Dynamite Jet Saloon | DNA-playlist-exportregistratie |

## DNA SPECIAL 55

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Animal Drive | [The Look](https://open.spotify.com/track/4bE5Pye1aVn9ELnPphoPiZ) | Back To The Roots | Masterregistratie |
| Aviator | [Front Line](https://open.spotify.com/track/5MmFMKe0VGaqlQ33KNy0KY) | Aviator | Masterregistratie |
| Dio | [Rock 'N' Roll Children](https://open.spotify.com/track/4hbSkGwKpFYCkHJmLXVW7Y) | Sacred Heart (Deluxe Edition) | Masterregistratie |
| Easy Action | [We Go Rocking - 2008 re-recording](https://open.spotify.com/track/4WmZoM5KgISsleWXDZM9jO) | We Go Rocking | Masterregistratie |
| Lion | [Never Surrender](https://open.spotify.com/track/2dm3UxRHnKk2aN0oZSwULc) | Dangerous Attraction | Masterregistratie |
| Malice | [License to Kill](https://open.spotify.com/track/0oDC3JcCtcJi6sgMMPIgxM) | License To Kill | Masterregistratie |
| Tuff | [The All New Generation](https://open.spotify.com/track/3BeSJIYsMVlnlALz1OLBzS) | What Comes Around Goes Around | Masterregistratie |

## DNA SPECIAL 55 Hard zonder brullen [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Animal Drive | [The Look](https://open.spotify.com/track/4bE5Pye1aVn9ELnPphoPiZ) | Back To The Roots | DNA-playlist-exportregistratie |
| Aviator | [Front Line](https://open.spotify.com/track/5MmFMKe0VGaqlQ33KNy0KY) | Aviator | DNA-playlist-exportregistratie |
| Dio | [Rock 'N' Roll Children](https://open.spotify.com/track/4hbSkGwKpFYCkHJmLXVW7Y) | Sacred Heart (Deluxe Edition) | DNA-playlist-exportregistratie |
| Easy Action | [We Go Rocking - 2008 re-recording](https://open.spotify.com/track/4WmZoM5KgISsleWXDZM9jO) | We Go Rocking | DNA-playlist-exportregistratie |
| Lion | [Never Surrender](https://open.spotify.com/track/2dm3UxRHnKk2aN0oZSwULc) | Dangerous Attraction | DNA-playlist-exportregistratie |
| Malice | [License to Kill](https://open.spotify.com/track/0oDC3JcCtcJi6sgMMPIgxM) | License To Kill | DNA-playlist-exportregistratie |
| Tuff | [The All New Generation](https://open.spotify.com/track/3BeSJIYsMVlnlALz1OLBzS) | What Comes Around Goes Around | DNA-playlist-exportregistratie |

## DNA SPECIAL 59

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bombshell Boys | [Shake Your Body](https://open.spotify.com/track/07VDLT8jatNUZTGgVVm7gy) | Medicine for Love | Masterregistratie |
| Highride | [A Good Day (To Die)](https://open.spotify.com/track/087dDyo7DRneZWsagz011x) | Excellence & Decadence | Masterregistratie |
| Kane Roberts;Alice Cooper;Alissa White-Gluz;Aoyama Hideki | [Beginning of the End](https://open.spotify.com/track/7gbkNPXE4PzQXCCpVjLuzk) | The New Normal | Masterregistratie |
| L.A. Cobra | [Sell Your Soul (Little Girl)](https://open.spotify.com/track/2GzbTHVtT8qRA0Q5URGQPV) | Shotgun Slinger | Masterregistratie |
| Lioncourt | [Kiss to Kill](https://open.spotify.com/track/4LzTT2BphTwQUidiuOunSO) | Kiss to Kill | Masterregistratie |
| Mafia Rock | [Crazy! (All Nightlong)](https://open.spotify.com/track/1UxXpbh1pNmNKGcpKNnggY) | Lock & Load | Masterregistratie |
| Restless Spirits;Chez Kane | [Dreams of the Wild](https://open.spotify.com/track/6cVcombXzsFOdRDnvpMLoL) | Dreams of the Wild | Masterregistratie |
| Salems Lott | [When Heaven Comes Down](https://open.spotify.com/track/5y4qyckPkYBsbM1Oapkpsm) | Mask of Morality | Masterregistratie |
| The Midnight Devils | [Highway 69](https://open.spotify.com/track/62ut3cFe95LhnezJmCeaji) | Never Beg for It | Masterregistratie |

## DNA SPECIAL 59 Oud DNA; onverwachte erfgenamen [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bombshell Boys | [Shake Your Body](https://open.spotify.com/track/07VDLT8jatNUZTGgVVm7gy) | Medicine for Love | DNA-playlist-exportregistratie |
| Highride | [A Good Day (To Die)](https://open.spotify.com/track/087dDyo7DRneZWsagz011x) | Excellence & Decadence | DNA-playlist-exportregistratie |
| Kane Roberts;Alice Cooper;Alissa White-Gluz;Aoyama Hideki | [Beginning of the End](https://open.spotify.com/track/7gbkNPXE4PzQXCCpVjLuzk) | The New Normal | DNA-playlist-exportregistratie |
| L.A. Cobra | [Sell Your Soul (Little Girl)](https://open.spotify.com/track/2GzbTHVtT8qRA0Q5URGQPV) | Shotgun Slinger | DNA-playlist-exportregistratie |
| Lioncourt | [Kiss to Kill](https://open.spotify.com/track/4LzTT2BphTwQUidiuOunSO) | Kiss to Kill | DNA-playlist-exportregistratie |
| Mafia Rock | [Crazy! (All Nightlong)](https://open.spotify.com/track/1UxXpbh1pNmNKGcpKNnggY) | Lock & Load | DNA-playlist-exportregistratie |
| Restless Spirits;Chez Kane | [Dreams of the Wild](https://open.spotify.com/track/6cVcombXzsFOdRDnvpMLoL) | Dreams of the Wild | DNA-playlist-exportregistratie |
| Salems Lott | [When Heaven Comes Down](https://open.spotify.com/track/5y4qyckPkYBsbM1Oapkpsm) | Mask of Morality | DNA-playlist-exportregistratie |
| The Midnight Devils | [Highway 69](https://open.spotify.com/track/62ut3cFe95LhnezJmCeaji) | Never Beg for It | DNA-playlist-exportregistratie |

## DNA SPECIAL 65 Los Angeles 1983-1990; Sunset Strip [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Great White | [Once Bitten Twice Shy](https://open.spotify.com/track/7pkWZL0kA26s754CwyK0SH) | Twice Shy | DNA-playlist-exportregistratie |
| Guns N' Roses | [Welcome To The Jungle](https://open.spotify.com/track/0bVtevEgtDIeRjCJbK3Lmv) | Appetite For Destruction | DNA-playlist-exportregistratie |
| Hurricane | [I'm On To You](https://open.spotify.com/track/1SSl0W9w6qnWDn3RuS8iWs) | Over The Edge | DNA-playlist-exportregistratie |
| Keel | [Speed Demon](https://open.spotify.com/track/4dYQ2i4yH70kKhUXMypICn) | The Right To Rock | DNA-playlist-exportregistratie |
| L.A. Guns | [Never Enough](https://open.spotify.com/track/4AWJ4Zwe5kHiQfUtrnFsA6) | Cocked And Loaded | DNA-playlist-exportregistratie |
| Leatherwolf | [The Calling](https://open.spotify.com/track/3jjDOFt8a30PQBrdKy298m) | Leatherwolf | DNA-playlist-exportregistratie |
| Lizzy Borden | [Me Against the World](https://open.spotify.com/track/0r1OaClQOS9UGAqb49CqB1) | Visual Lies (Remastered) | DNA-playlist-exportregistratie |
| London | [Russian Winter](https://open.spotify.com/track/1GJo4SLR73bNNOIhAg4DJn) | Playa Del Rock | DNA-playlist-exportregistratie |
| Mötley Crüe | [Wild Side](https://open.spotify.com/track/41wWrTueWew7qUU0Ru87Mp) | Girls, Girls, Girls | DNA-playlist-exportregistratie |
| Odin | [Judgement Day](https://open.spotify.com/track/3i6lUB2s5xKblIodo98o3m) | Caution! | DNA-playlist-exportregistratie |
| Quiet Riot | [Metal Health (Bang Your Head)](https://open.spotify.com/track/28clONjZmul6FjfO6tZQDE) | Metal Health | DNA-playlist-exportregistratie |
| Ratt | [You're in Love](https://open.spotify.com/track/3D3lmTEhuWaunO1yxpYPD8) | Invasion of Your Privacy | DNA-playlist-exportregistratie |
| Rough Cutt | [Piece of My Heart](https://open.spotify.com/track/01TluZKgLPWzBObU5plV1T) | Rough Cutt | DNA-playlist-exportregistratie |
| Shark Island | [Bad For Each Other](https://open.spotify.com/track/55ftoigsg90cpRFZUqqljP) | Law of the Order | DNA-playlist-exportregistratie |
| Vain | [Beat the Bullet](https://open.spotify.com/track/4xgqf2xJ8eaSKXRwYafEYf) | No Respect | DNA-playlist-exportregistratie |

## DNA SPECIAL 71

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| David Coverdale;Whitesnake | [Too Many Tears - 2003 Remastered Version](https://open.spotify.com/track/5VixAoU5wQmTwRkjah256u) | Best of Whitesnake | Masterregistratie |
| Dio | [Rock 'n' Roll Children - 2016 Remaster](https://open.spotify.com/track/4QsUCXM0HsaPS55CIupTo2) | Sacred Heart (2016 Remaster) | Masterregistratie |

## DNA SPECIAL 71 Uit elkaar, weer verder; Bands uit bands [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| David Coverdale;Whitesnake | [Too Many Tears - 2003 Remastered Version](https://open.spotify.com/track/5VixAoU5wQmTwRkjah256u) | Best of Whitesnake | DNA-playlist-exportregistratie |
| Dio | [Rock 'n' Roll Children - 2016 Remaster](https://open.spotify.com/track/4QsUCXM0HsaPS55CIupTo2) | Sacred Heart (2016 Remaster) | DNA-playlist-exportregistratie |

## DNA SPECIAL 72

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Vinnie Vincent Invasion | [Dirty Rhythm - Remastered 2003](https://open.spotify.com/track/6hkkco5FXywlf1Kjqwc3o3) | All Systems Go (Remastered 2003) | Masterregistratie |

## DNA SPECIAL 72 Het zijproject werd serieus [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Vinnie Vincent Invasion | [Dirty Rhythm - Remastered 2003](https://open.spotify.com/track/6hkkco5FXywlf1Kjqwc3o3) | All Systems Go (Remastered 2003) | DNA-playlist-exportregistratie |

## DNA SPECIAL 73

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Badlands | [Healer](https://open.spotify.com/track/0DmtV4MheUFEjEz6XPZsox) | Dusk | Masterregistratie |
| Blue Murder | [Valley Of The Kings](https://open.spotify.com/track/70BR04tUEx7e3td2ra72X8) | Blue Murder | Masterregistratie |
| David Lee Roth | [Just Like Paradise](https://open.spotify.com/track/5ZY7Gug850kv4heJcWZGHM) | Skyscraper | Masterregistratie |
| George Lynch;Kelly Hansen | [Rock You Like A Hurricane](https://open.spotify.com/track/4BNZcVUwpiwHaEfjVLJPZG) | Guitar Slinger | Masterregistratie |
| Lynch Mob | [Wicked Sensation](https://open.spotify.com/track/2Kf3Sy6Tj0T2jl36ghCHpF) | Wicked Sensation | Masterregistratie |
| Ozzy Osbourne | [Crazy Train](https://open.spotify.com/track/2b9lp5A6CqSzwOrBfAFhof) | Blizzard of Ozz (Expanded Edition) | Masterregistratie |
| Whitesnake | [Still of the Night - 2018 Remaster](https://open.spotify.com/track/7AtwQRLPdttsxcLM5tPL0t) | Whitesnake (2018 Remaster) | Masterregistratie |

## DNA SPECIAL 73 De gitarist verhuisde [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Badlands | [Healer](https://open.spotify.com/track/0DmtV4MheUFEjEz6XPZsox) | Dusk | DNA-playlist-exportregistratie |
| Blue Murder | [Valley Of The Kings](https://open.spotify.com/track/70BR04tUEx7e3td2ra72X8) | Blue Murder | DNA-playlist-exportregistratie |
| David Lee Roth | [Just Like Paradise](https://open.spotify.com/track/5ZY7Gug850kv4heJcWZGHM) | Skyscraper | DNA-playlist-exportregistratie |
| George Lynch;Kelly Hansen | [Rock You Like A Hurricane](https://open.spotify.com/track/4BNZcVUwpiwHaEfjVLJPZG) | Guitar Slinger | DNA-playlist-exportregistratie |
| Lynch Mob | [Wicked Sensation](https://open.spotify.com/track/2Kf3Sy6Tj0T2jl36ghCHpF) | Wicked Sensation | DNA-playlist-exportregistratie |
| Ozzy Osbourne | [Crazy Train](https://open.spotify.com/track/2b9lp5A6CqSzwOrBfAFhof) | Blizzard of Ozz (Expanded Edition) | DNA-playlist-exportregistratie |
| Whitesnake | [Still of the Night - 2018 Remaster](https://open.spotify.com/track/7AtwQRLPdttsxcLM5tPL0t) | Whitesnake (2018 Remaster) | DNA-playlist-exportregistratie |

## DNA SPECIAL 74

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Accept | [Balls To The Wall](https://open.spotify.com/track/0xX1PxiAPN1mD9hCRiqd0Z) | Staying A Life | Masterregistratie |
| Judas Priest | [Painkiller](https://open.spotify.com/track/0L7zm6afBEtrNKo6C6Gj08) | Painkiller | Masterregistratie |
| Ratt | [Lay It Down](https://open.spotify.com/track/3D5ORNm9spaTcdRx50ksHx) | Invasion of Your Privacy | Masterregistratie |

## DNA SPECIAL 74 De ritmesectie bleef staan [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Accept | [Balls To The Wall](https://open.spotify.com/track/0xX1PxiAPN1mD9hCRiqd0Z) | Staying A Life | DNA-playlist-exportregistratie |
| Judas Priest | [Painkiller](https://open.spotify.com/track/0L7zm6afBEtrNKo6C6Gj08) | Painkiller | DNA-playlist-exportregistratie |
| Ratt | [Lay It Down](https://open.spotify.com/track/3D5ORNm9spaTcdRx50ksHx) | Invasion of Your Privacy | DNA-playlist-exportregistratie |

## DNA SPECIAL 75

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| KISS | [Tears Are Falling](https://open.spotify.com/track/1hxt3chzYLAzS4NmSSi5A3) | Asylum | Masterregistratie |
| The Cult | [She Sells Sanctuary (2009 Re-master)](https://open.spotify.com/track/3EAFamlgsYPA3HijLUPszI) | Love (Expanded Edition) | Masterregistratie |

## DNA SPECIAL 75 De producer als onzichtbaar bandlid [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| KISS | [Tears Are Falling](https://open.spotify.com/track/1hxt3chzYLAzS4NmSSi5A3) | Asylum | DNA-playlist-exportregistratie |
| The Cult | [She Sells Sanctuary (2009 Re-master)](https://open.spotify.com/track/3EAFamlgsYPA3HijLUPszI) | Love (Expanded Edition) | DNA-playlist-exportregistratie |

## DNA SPECIAL 77

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bad English | [So This Is Eden](https://open.spotify.com/track/0TZniszdqYe7jxDC0r8oc9) | Backlash | Masterregistratie |
| Iconic | [Fast as You Can](https://open.spotify.com/track/17UNYdDQKW0caFvTMaUdGi) | Second Skin | Masterregistratie |
| W.E.T. | [One Final Kiss](https://open.spotify.com/track/3wdqtNP07d6o281NT7fRpu) | Retransmission | Masterregistratie |

## DNA SPECIAL 77 Supergroepen; Meer dan de som [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bad English | [So This Is Eden](https://open.spotify.com/track/0TZniszdqYe7jxDC0r8oc9) | Backlash | DNA-playlist-exportregistratie |
| Iconic | [Fast as You Can](https://open.spotify.com/track/17UNYdDQKW0caFvTMaUdGi) | Second Skin | DNA-playlist-exportregistratie |
| W.E.T. | [One Final Kiss](https://open.spotify.com/track/3wdqtNP07d6o281NT7fRpu) | Retransmission | DNA-playlist-exportregistratie |

## DNA SPECIAL 78

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| George Lynch;Stephen Pearcy | [Round & Round](https://open.spotify.com/track/1sVjVlSDlD2mTem8mDernB) | Guitar Slinger | Masterregistratie |
| John Norum;Joey Tempest | [We Will Be Strong](https://open.spotify.com/track/1xId1hoQ0mfYl610t5VtPW) | Face The Truth | Masterregistratie |
| Mark Slaughter;Albert Lee | [Back In The Saddle](https://open.spotify.com/track/3W9HxLOVwr6IMmFUG1Xf22) | Back In The Saddle | Masterregistratie |
| Tom Keifer;Lzzy Hale | [Nobody's Fool - Duet Version](https://open.spotify.com/track/1mJVRXYrbZ0CVRt75d0LBP) | The Way Life Goes - Deluxe Edition | Masterregistratie |

## DNA SPECIAL 78 Gastrollen die ertoe deden [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| George Lynch;Stephen Pearcy | [Round & Round](https://open.spotify.com/track/1sVjVlSDlD2mTem8mDernB) | Guitar Slinger | DNA-playlist-exportregistratie |
| John Norum;Joey Tempest | [We Will Be Strong](https://open.spotify.com/track/1xId1hoQ0mfYl610t5VtPW) | Face The Truth | DNA-playlist-exportregistratie |
| Mark Slaughter;Albert Lee | [Back In The Saddle](https://open.spotify.com/track/3W9HxLOVwr6IMmFUG1Xf22) | Back In The Saddle | DNA-playlist-exportregistratie |
| Tom Keifer;Lzzy Hale | [Nobody's Fool - Duet Version](https://open.spotify.com/track/1mJVRXYrbZ0CVRt75d0LBP) | The Way Life Goes - Deluxe Edition | DNA-playlist-exportregistratie |

## DNA SPECIAL 82

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Crashdïet | [Generation Wild](https://open.spotify.com/track/0CDzxP82YOmMvstrEJjREo) | Generation Wild | Masterregistratie |
| Lillian Axe | [Show A Little Love](https://open.spotify.com/track/4FsAlfZHssqD8BXHANHLqP) | Love + War | Masterregistratie |
| TNT | [10,000 Lovers (In One)](https://open.spotify.com/track/7q1HuENSdN4GMm8IxvdeKg) | Tell No Tales | Masterregistratie |
| Vixen | [Edge Of A Broken Heart](https://open.spotify.com/track/2mEk0VdrbDJ11DBC6Y92mh) | Vixen | Masterregistratie |

## DNA SPECIAL 82 Het refrein blijft hangen [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Crashdïet | [Generation Wild](https://open.spotify.com/track/0CDzxP82YOmMvstrEJjREo) | Generation Wild | DNA-playlist-exportregistratie |
| Lillian Axe | [Show A Little Love](https://open.spotify.com/track/4FsAlfZHssqD8BXHANHLqP) | Love + War | DNA-playlist-exportregistratie |
| TNT | [10,000 Lovers (In One)](https://open.spotify.com/track/7q1HuENSdN4GMm8IxvdeKg) | Tell No Tales | DNA-playlist-exportregistratie |
| Vixen | [Edge Of A Broken Heart](https://open.spotify.com/track/2mEk0VdrbDJ11DBC6Y92mh) | Vixen | DNA-playlist-exportregistratie |

## DNA SPECIAL 83

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Ace Frehley | [Rock Soldiers](https://open.spotify.com/track/7DRkxr8eGnAwcNIbdAWcxM) | Frehley's Comet | Masterregistratie |
| Alcatrazz | [God Blessed Video](https://open.spotify.com/track/2nsrALjWaiP5WqyzIkJlHe) | Disturbing The Peace | Masterregistratie |
| John Sykes | [Cautionary Warning](https://open.spotify.com/track/0DQre1WvAlGHKpLFTEf3Hp) | 20th Century | Masterregistratie |
| Tesla | [Modern Day Cowboy](https://open.spotify.com/track/5ZIU2kT1wNjQNclQeVCz5O) | Mechanical Resonance | Masterregistratie |

## DNA SPECIAL 83 De solo verandert alles [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Ace Frehley | [Rock Soldiers](https://open.spotify.com/track/7DRkxr8eGnAwcNIbdAWcxM) | Frehley's Comet | DNA-playlist-exportregistratie |
| Alcatrazz | [God Blessed Video](https://open.spotify.com/track/2nsrALjWaiP5WqyzIkJlHe) | Disturbing The Peace | DNA-playlist-exportregistratie |
| John Sykes | [Cautionary Warning](https://open.spotify.com/track/0DQre1WvAlGHKpLFTEf3Hp) | 20th Century | DNA-playlist-exportregistratie |
| Tesla | [Modern Day Cowboy](https://open.spotify.com/track/5ZIU2kT1wNjQNclQeVCz5O) | Mechanical Resonance | DNA-playlist-exportregistratie |

## DNA SPECIAL 86

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Nasty Idols | [Alive 'n Kickin' - Live](https://open.spotify.com/track/3yUCF2HJ90otx873LuGipZ) | Sweden Rock Festival (Best Of 2005 / 2006, Vol. 2) | Masterregistratie |
| Sleeze Beez | [Screwed, Blued & Tattooed](https://open.spotify.com/track/2gS0MZUZu8xKxJbD7QXZBz) | Live In Tokyo | Masterregistratie |

## DNA SPECIAL 86 Live wordt het beter [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Nasty Idols | [Alive 'n Kickin' - Live](https://open.spotify.com/track/3yUCF2HJ90otx873LuGipZ) | Sweden Rock Festival (Best Of 2005 / 2006, Vol. 2) | DNA-playlist-exportregistratie |
| Sleeze Beez | [Screwed, Blued & Tattooed](https://open.spotify.com/track/2gS0MZUZu8xKxJbD7QXZBz) | Live In Tokyo | DNA-playlist-exportregistratie |

## DNA SPECIAL 93

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Extreme | [Hole Hearted](https://open.spotify.com/track/454prfBh6yhYBJ05NUGHJ4) | Extreme II - Pornograffitti | Masterregistratie |

## DNA SPECIAL 93 Zachter dan verwacht [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Extreme | [Hole Hearted](https://open.spotify.com/track/454prfBh6yhYBJ05NUGHJ4) | Extreme II - Pornograffitti | DNA-playlist-exportregistratie |

## DNA SPECIAL 95

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Chez Kane | [Powerzone](https://open.spotify.com/track/16SmBswtkGZPQR2wVcHBDe) | Powerzone | Masterregistratie |
| Temple Balls | [What is Dead Never Dies](https://open.spotify.com/track/2kR3dxZDaIHrbI7ZrodAbg) | Pyromide | Masterregistratie |
| The Poodles | [Night of Passion](https://open.spotify.com/track/1ianoyRbOK3RXrQIiT2aTk) | Metal Will Stand Tall | Masterregistratie |

## DNA SPECIAL 95 Nieuwe muziek met oude wortels [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Chez Kane | [Powerzone](https://open.spotify.com/track/16SmBswtkGZPQR2wVcHBDe) | Powerzone | DNA-playlist-exportregistratie |
| Temple Balls | [What is Dead Never Dies](https://open.spotify.com/track/2kR3dxZDaIHrbI7ZrodAbg) | Pyromide | DNA-playlist-exportregistratie |
| The Poodles | [Night of Passion](https://open.spotify.com/track/1ianoyRbOK3RXrQIiT2aTk) | Metal Will Stand Tall | DNA-playlist-exportregistratie |

## DNA SPECIAL 96

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bloody Heels | [Ignite the Sky](https://open.spotify.com/track/3APm5ErddIfnRSz70fdbaf) | Ignite the Sky | Masterregistratie |
| Girish And The Chronicles | [Ride to Hell](https://open.spotify.com/track/2Gz1Ya7XxpDXsRn6toj3aF) | Back on Earth | Masterregistratie |
| Gunner | [Arcade Nights](https://open.spotify.com/track/29hKOqR29tEzeuZS22GHln) | Sinners | Masterregistratie |

## DNA SPECIAL 96 Onverwachte landen [exportbestandsnaam]

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Bloody Heels | [Ignite the Sky](https://open.spotify.com/track/3APm5ErddIfnRSz70fdbaf) | Ignite the Sky | DNA-playlist-exportregistratie |
| Girish And The Chronicles | [Ride to Hell](https://open.spotify.com/track/2Gz1Ya7XxpDXsRn6toj3aF) | Back on Earth | DNA-playlist-exportregistratie |
| Gunner | [Arcade Nights](https://open.spotify.com/track/29hKOqR29tEzeuZS22GHln) | Sinners | DNA-playlist-exportregistratie |

## DNA SPECIAL — Glam: de vergeten zijstraten

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Cats In Boots | [Shotgun Sally](https://open.spotify.com/track/18n5kMWdrmrEOuh9Qnh2Wf) | Kicked And Klawed | Masterregistratie |
| Child's Play | [Good Ol' Rock And Roll](https://open.spotify.com/track/3Csv0MN00Iv3XH9d418JaQ) | Rat Race | Masterregistratie |
| Cold Sweat | [Let's Make Love Tonight](https://open.spotify.com/track/0Md3WqXa9vCXWOVcvU94lA) | Break Out | Masterregistratie |
| D'Molls | [My Life](https://open.spotify.com/track/2Dd0cU8vbBl38j2RBLhLAm) | Warped | Masterregistratie |
| Electric Angels | [Rattlesnake Kisses](https://open.spotify.com/track/6wUkj9fhKcMkUlSwcC3xd0) | Electric Angels | Masterregistratie |
| Every Mothers Nightmare | [Walls Come Down](https://open.spotify.com/track/779PvwBHrHjORk3lC3AMPt) | Every Mother's Nightmare | Masterregistratie |
| Heavy Bones | [The Hand That Feeds](https://open.spotify.com/track/0bwEjc3wdAY8mDdsbnRxcv) | Heavy Bones | Masterregistratie |
| Julliet | [Love Hungry Man](https://open.spotify.com/track/5eaveS1Oieqxf9HRNUQymh) | Passion | Masterregistratie |
| Kik Tracee | [Don't Need Rules](https://open.spotify.com/track/5AOPC7iW1kj8uGtT4CmcQj) | No Rules | Masterregistratie |
| Roxy Blue | [Too Hot To Handle](https://open.spotify.com/track/1vmTDGLj4FteG2Jn4NTazK) | Want Some? | Masterregistratie |
| Saints & Sinners | [Shake](https://open.spotify.com/track/4gjFeCBHRvUQluaJgUsDCh) | Saints & Sinners | Masterregistratie |
| Sea Hags | [Half The Way Valley](https://open.spotify.com/track/55Qc3ftOxf63hZn8XJElLF) | Sea Hags | Masterregistratie |
| Smashed Gladys | [Lick It into Shape](https://open.spotify.com/track/6HG1C9zt3trYkHAFtRU0lL) | Social Intercourse | Masterregistratie |
| The Throbs | [Come Down Sister](https://open.spotify.com/track/31Eino4YwuoQlORmBExbdK) | The Language Of Thieves And Vagabonds | Masterregistratie |
| Trouble Tribe | [(Angel With A) Devil's Kiss](https://open.spotify.com/track/6Y3CVmC4P0P0sDcrRSzr4L) | Trouble Tribe | Masterregistratie |

## Ontdek DNA 2026-W39 — opgeslagen weekhistorie

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Badlands | [Healer](https://open.spotify.com/track/0DmtV4MheUFEjEz6XPZsox) | Dusk | Opgeslagen weekhistorie |
| Coney Hatch | [Some Like It Hot](https://open.spotify.com/track/68oRkANDPCQ6EegIVdzwgx) | Outa Hand | Opgeslagen weekhistorie |
| Helix | [Rock You](https://open.spotify.com/track/2sd8DUzBIaNBzkgEPGsHV6) | Walkin' The Razor's Edge | Opgeslagen weekhistorie |
| John Diva & the Rockets of Love | [American Amadeus](https://open.spotify.com/track/5glmLXna7qATdV9Mx4ObQM) | American Amadeus | Opgeslagen weekhistorie |
| Lipz | [Get It On](https://open.spotify.com/track/0ti0aAg5xZd7JW8KGU9ROX) | Scaryman | Opgeslagen weekhistorie |
| Q5 | [Pull the Trigger](https://open.spotify.com/track/3sxvhBZLZF8siHd0LyKFyK) | Steel the Light | Opgeslagen weekhistorie |
| Reckless Love | [Hot](https://open.spotify.com/track/5H6eTrcDfPAHXAHWrR7Q5M) | Animal Attraction | Opgeslagen weekhistorie |
| Roxy Blue | [Too Hot To Handle](https://open.spotify.com/track/1vmTDGLj4FteG2Jn4NTazK) | Want Some? | Opgeslagen weekhistorie |
| Shiraz Lane | [To The Moon & Back](https://open.spotify.com/track/0jCiQXabUrZmAfGXEbo3WF) | To The Moon & Back | Opgeslagen weekhistorie |
| Signal | [Arms Of A Stranger](https://open.spotify.com/track/3gdnbF4xI6Lkql4vbFlZrM) | Loud & Clear | Opgeslagen weekhistorie |
| Stone Fury | [Break Down The Wall](https://open.spotify.com/track/7zevYZAJYMgEUu8rHDaxLR) | Burns Like A Star | Opgeslagen weekhistorie |
| The Poodles | [Night of Passion](https://open.spotify.com/track/1ianoyRbOK3RXrQIiT2aTk) | Metal Will Stand Tall | Opgeslagen weekhistorie |
| ToxicRose | [World of Confusion](https://open.spotify.com/track/1sPj9IM8jxDoMdVzefLKHj) | Total Tranquility | Opgeslagen weekhistorie |

## Ontdek DNA 2026-W40 — museum

| Artiest | Opname | Album | Bewijs |
|---|---|---|---|
| Alien | [Give It Up](https://open.spotify.com/track/1nDOVQ2ioOrnE7SfJT0rvO) | Shiftin' Gear | Museumpublicatie |
| Andy Timmons | [Groove or Die](https://open.spotify.com/track/2vLm4hsLeMMfcqaVlj4PKN) | That Was Then, This Is Now | Museumpublicatie |
| Aviator | [Front Line](https://open.spotify.com/track/5MmFMKe0VGaqlQ33KNy0KY) | Aviator | Museumpublicatie |
| Baby Jane | [My Behavior](https://open.spotify.com/track/1IJtqhXB7xi9IXqOmG7DLd) | In the Spotlight | Museumpublicatie |
| Babylon Bombs | [Hometown Hero](https://open.spotify.com/track/5TqQnYIyisbHJiHXzkSK9u) | Doin' You Nasty | Museumpublicatie |
| Big Bang Babies | [Everybody Needs A Hero](https://open.spotify.com/track/3HUCwifeBQMMBKUPxCaVt2) | 3 Chords And The Truth | Museumpublicatie |
| Bombshell Boys | [Shake Your Body](https://open.spotify.com/track/07VDLT8jatNUZTGgVVm7gy) | Medicine for Love | Museumpublicatie |
| Brighton Rock | [Young Wild and Free](https://open.spotify.com/track/7EBpncUwlHjLhQTetSLb9O) | Young, Wild And Free | Museumpublicatie |
| C.J. Snare | [Rock You Tonight](https://open.spotify.com/track/6Db5cayYggggqGq2MIfp65) | Hold Your Fire | Museumpublicatie |
| Crash Kelly | [She Gets Away](https://open.spotify.com/track/1kTPKqk6vMojgGGgsfumiq) | Penny Pills | Museumpublicatie |
| Crystal Pistol | [Rockstar](https://open.spotify.com/track/4NTuOzgM0DgNtbCSCUj9QN) | Crystal Pistol | Museumpublicatie |
| Heavy Bones | [The Hand That Feeds](https://open.spotify.com/track/0bwEjc3wdAY8mDdsbnRxcv) | Heavy Bones | Museumpublicatie |
| John Norum;Joey Tempest | [We Will Be Strong](https://open.spotify.com/track/1xId1hoQ0mfYl610t5VtPW) | Face The Truth | Museumpublicatie |
| King Kobra | [Iron Eagle (Never Say Die)](https://open.spotify.com/track/3tD4AR8vbvM0b9X09YBYE0) | Thrill Of A Lifetime | Museumpublicatie |
| Peppermint Creeps | [Turning Japanese](https://open.spotify.com/track/6Wb0KcC6LEMjOtLYcMKcss) | We R The Weirdoz!!! | Museumpublicatie |
| Radioactive;Jeff Paris | [Shame On You, Shame On Me](https://open.spotify.com/track/6XcxLPk27iNbo2rBWnnr5V) | Shame On You, Shame On Me | Museumpublicatie |
| Restless Spirits;Chez Kane | [Dreams of the Wild](https://open.spotify.com/track/6cVcombXzsFOdRDnvpMLoL) | Dreams of the Wild | Museumpublicatie |
| Return | [Steal Your Heart](https://open.spotify.com/track/4sbbbxq9R9KJoUZuJHF6Wb) | Attitudes | Museumpublicatie |
| Saints & Sinners | [Shake](https://open.spotify.com/track/4gjFeCBHRvUQluaJgUsDCh) | Saints & Sinners | Museumpublicatie |
| Sic Vikki | [Kiss Me in French](https://open.spotify.com/track/4lxeOuQ37BfUxqkeOwwIjb) | Kiss Me in French (30th Anniversary) | Museumpublicatie |
| Zebra | [As I Said Before](https://open.spotify.com/track/3DQUOnH5OKGjXXnfKGj0UT) | Zebra | Museumpublicatie |

## Controle

Alle 410 genreopnamen met status Geëxposeerd zijn in deze index teruggevonden. De index verandert geen gebruiksstatus en bewijst geen afwezigheid van gebruik voor de 64 Onverkend-opnamen. Alle onderliggende bronverwijzingen en Masterregels zijn in de gekoppelde JSON opgenomen.

[Indexgegevens met bronbewijs](Music-DNA-Depot-Gebruiksindex.json) · [Volledige inventaris](Music-DNA-Depot-v1-Overzicht.md)
