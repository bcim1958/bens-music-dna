# Music DNA Depot v1 — Glam Metal

Actuele stand: 7 oktober 2026. v1.18 — archiefexpositie en volledige ISRC-brondekking voor 63 kandidaten. Dit overzicht en de collectiedata gaan voor op oudere onderzoeksrapporten.

**474 genre-gelabelde opnamen, 470 artiestcredits en 472 artiest–albumcombinaties**, uit Master 1.13 met 3.646 unieke Spotify-opnamen. Daarnaast 15 aangrenzende onderzoekscases. Genres komen uit bestaande projectvelden; overwegend afgeleide artiesttaxonomie.

| Werkvoorraad | Aantal | Depotstatus |
|---|---:|---|
| Geregistreerd of bevestigd geëxposeerd | 410 | Geëxposeerd |
| Voorlopige Vergeten-Edelsteen-kandidaten | 63 | Onverkend |
| Historisch positief; geen gevonden gebruik | 1 | Onverkend |
| **Totaal** | **474** | **410 Geëxposeerd + 64 Onverkend** |

## Bronnen en correcties

De Master registreert 292 genreopnamen als gebruikt en 182 als niet gebruikt. Bij **118 van die 182** is aanvullend geregistreerd of bevestigd gebruik gevonden. De oorspronkelijke Master blijft ongewijzigd. [Registratieverschillen](Music-DNA-Depot-Registratieverschillen.json) staan apart.

De uitbreiding naar losse DNA-playlist-exports buiten de Codex-werkmappen bracht 94 extra genreopnamen met gebruiksregistratie aan het licht: 84 VE-kandidaten, acht positieve stroomgevallen en Jester plus Dirty White Boy. [Controle en wijzigingslijst](Music-DNA-Depot-Aanvullende-Exports.md).

De aanvullende controle van 11 archieven, met 829 CSV-leden, levert nog één extra gebruiksregistratie: The Last Vegas — Raw Dog in Hair Metal DNA. [Archiefcontrole](Music-DNA-Depot-Archiefcontrole.md).

Alle 63 resterende kandidaten hebben nu een ISRC in de gelezen bronexports. Er is geen gelijke code gevonden bij een andere geregistreerd geëxposeerde URI binnen de brondekking. Codes zijn bronmetadata; geen afwezigheid van expositie bewezen. Steeler heeft een expliciete koppeling naar een andere URI met afwijkende code en speelduur. [Opnamecodes](Music-DNA-Depot-Opnamecodes.md).

## Lees de actuele collectie

- [Volledige inventaris](Music-DNA-Depot-v1-Glam-Metal.md).
- [Kandidaatcollectie met ontbrekende controles](Music-DNA-Depot-Proefcollectie.md).
- [Gebruik per toepassing](Music-DNA-Depot-Gebruiksindex.md).
- [Collectiedata met bronregels en bewijs](Music-DNA-Depot-v1-Glam-Metal.json).

## Bewijskracht

Masterregistratie, opgeslagen DNA-playlist-export, lokale weekhistorie en live gecontroleerde publicatie blijven afzonderlijk herkenbaar. Het W40-museum bevat 21 exact gecontroleerde opnamelinks; Special 104 heeft 15/15 live gecontroleerde URI’s en volgorde. Historische CSV-exports zijn geen nieuwe livecontrole. Importers, algemene bronplaylists en likes worden niet automatisch als DNA-expositie behandeld.

De gebruiksindex telt 178 afzonderlijke toepassingsnamen en 1131 opname–toepassingcombinaties. Namen uit exportbestanden blijven herkenbaar als bestandsnamen; ze zijn niet zonder bewijs met andere titels samengevoegd. Alle 410 geëxposeerde genreopnamen zijn ontsloten. Categorieaantallen overlappen.

## Open onderzoek

63 kandidaten blijven Onverkend. Volledige historische expositiedekking, actuele reserve en trackstijl vragen nog bewijs. Kip Winger en medeartiesten — Limelight is de enige historisch positieve genreopname zonder gevonden gebruik. Oudere playlist-expositie bewijst geen actuele wekelijkse FIFO-afhandeling.

[Artiestonderzoek](Music-DNA-Depot-Artiestonderzoek.md) onderbouwt Invasion als Noors en LIVE WIRE als Colombiaans. Cyanide, Mafia Rock en Fat Nelly houden hun open herkomstvraag. [Jester en Dirty White Boy](Music-DNA-Depot-Genreambiguiteiten.md) hebben rock-/hardrockcontext en bewezen exportexpositie, maar hun trackstijl blijft open. [Versiecontrole](Music-DNA-Depot-Versiecontrole.md) onderbouwt Trixters live-context; Trixter is inmiddels geëxposeerd geregistreerd.

De nieuwste echte positieve-bankexport die binnen de Codex-werkmappen is gevonden dateert van 3 oktober. De [FIFO-broncontrole](Music-DNA-Depot-FIFO-Brongrens.md) beschrijft de toenmalige bewijsgrens; aanvullende oudere playlistregistraties veranderen die exportdatum niet.

## Statusregels

Actief in stroom/FIFO-reserve vereist positief oordeel én actuele reservepositie. Geëxposeerd vereist geregistreerde of bevestigde presentatie. Vergeten Edelsteen vereist historische Masterdeelname buiten de stroom en voldoende bewijs van geen eerdere expositie. Herontdekkingskandidaat vereist eerdere expositie plus een concrete nieuwe aanleiding. Onverkend geldt waar essentiële context ontbreekt. Stroomafwijking is uitsluitend een bewezen technische uitzondering.

Geen definitieve Vergeten Edelstenen, actuele FIFO-posities, herontdekkingskandidaten of technische stroomafwijkingen zijn bewezen. Bronjaren zijn geen onafhankelijk vastgestelde opnamejaren. Playlist-toevoegdatums zijn geen bewezen toetredings- of FIFO-datums.

## Eerste luisterproef

[15 opnamen beluisteren](/Users/benvanbelzen/Documents/Codex/2026-10-07/referenced-chatgpt-conversation-this-is-an/outputs/Music-DNA-Depot-Luisterproef.md) · [Alle 63 kandidaten geordend](/Users/benvanbelzen/Documents/Codex/2026-10-07/referenced-chatgpt-conversation-this-is-an/outputs/Music-DNA-Depot-Kandidatenordening.md). Onderzoeksindeling en luisterselectie wijzigen geen depotstatus.
