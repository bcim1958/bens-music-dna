# Music DNA Depot — eerste Glam Metal-proefcollectie

Stand 7 oktober 2026. Deze collectie bevat alle **63 voorlopige Vergeten-Edelsteen-kandidaten** uit de onderzochte Master. Hun depotstatus blijft **Onverkend**. Geen gevonden gebruik is geen bewijs dat een opname nooit is geëxposeerd. Het aantoonbaar positieve stroomgeval is uitgesloten van deze kandidaatcollectie.

Bij **15 kandidaten** bevat de bestaande track- of albumtitel een concrete aanwijzing voor versie-, uitgave- of presentatiecontext. Dit zijn tekstsignalen voor controle, geen vastgestelde uitvoeringen. Een Live-woord kan ook gewoon onderdeel van een titel zijn. Ontbreken van zo’n woord bewijst geen standaard- of studio-opname.

## Versie- en albumcontext eerst controleren

| Artiest — track | Album | Aanwijzing uit bestaande titel |
|---|---|---|
| Bret Michaels — Nothin' But A Good Time - Re-Recorded | 100 Rock Power Tracks from the '70s, '80s & '90s | Versieaanduiding in titel/album; Verzamel-/archiefcontext in albumtitel |
| Dead Addiction — Live at the Scene of the Crime | ...of Vice and Men | Live-woord in titel/album; uitvoering nog controleren |
| EyeBolt — Her Legs - Demo | Her Legs (Demo) | Versieaanduiding in titel/album |
| Fifth Angel — Resist the Tyrant - Single Edit | Resist the Tyrant | Versieaanduiding in titel/album |
| Giuntini;Tony Martin — Anno Mundi | Great Lefty: Live Forever! (Tribute to Tony Iommi Godfather Of Metal) | Tribute-/covercontext in titel/album; Live-woord in titel/album; uitvoering nog controleren |
| Heaven — In the beginning | Heaven - Digitally Remastered | Versieaanduiding in titel/album |
| Jizzy Pearl — Sweet Child O' Mine | This is Metal's Most Covered Moments of the '80s | Tribute-/covercontext in titel/album |
| Kenny McCafferty — Passion (Dirty Blonde 2020 remaster) - Remaster | Passion (Dirty Blonde 2020 remaster) [Remaster] | Versieaanduiding in titel/album |
| Mickey Ratt — You Think You're Tough | Ratt Era - the Best Of | Verzamel-/archiefcontext in albumtitel |
| Only Child — I Believe in You | Only Child (Deluxe Version) | Uitgebreide uitgave in albumtitel |
| Richard Kendrick;Ron Keel — Lick It Up (as made famous by KISS) | Hair Metal In Covers Vol. 2 | Tribute-/covercontext in titel/album |
| Sacred Warrior — Master's Command | Master's Command (Remastered) | Versieaanduiding in titel/album |
| Seduce — Crash Landing - 2020 Remaster | Too Much Ain't Enough (2020 Remaster) | Versieaanduiding in titel/album |
| Sweet Savage — Do Ya | Archives | Verzamel-/archiefcontext in albumtitel |
| Zodiac Mindwarp — Prime Mover (Exclusive Version) | 100 Hair Metal Anthems | Versieaanduiding in titel/album; Verzamel-/archiefcontext in albumtitel |

## Alle 63 kandidaatopnamen

Alfabetisch, zonder muzikale rangschikking. Bronjaren zijn geen onafhankelijk bevestigde opnamejaren. Alle rijen: geen gebruik gevonden, huidige FIFO-positie niet vastgesteld, definitieve VE-status open. De gekoppelde gegevens bevatten per opname de controles en exacte Masterbronregel.

| Artiest | Opname | Album | Bronjaar | Contextcontrole |
|---|---|---|---:|---|
| 80's Bush | [Sleazy Dirty Rock n Roll](https://open.spotify.com/track/0KZaCw93RIPJTveUh4ja8Z) | Sleazy Dirty Rock n Roll | 2021 | Trackstijl, gebruik en reserve |
| A.Z.R.O. | [99 Miles](https://open.spotify.com/track/45HvpmIR38by9GDwRm93rT) | Rock in a Hard Place | 2022 | Trackstijl, gebruik en reserve |
| Alleycatz | [Do It For The Rock N' Roll](https://open.spotify.com/track/2LxLBJX6mtdtZEXeiJulGC) | Private Vices, Public Pleasures | 2023 | Trackstijl, gebruik en reserve |
| Babylon Shakes | [Scarlet Sins](https://open.spotify.com/track/0OtfqVWR3F1shHMjiO2tyU) | Scarlet Sins | 2025 | Trackstijl, gebruik en reserve |
| Barren Cross | [Imaginary Music](https://open.spotify.com/track/6y3HND8DFOvNLhxiomrGjG) | Atomic Arena | 1988 | Trackstijl, gebruik en reserve |
| Bitch | [Heavy Metal Breakdown](https://open.spotify.com/track/5qQDHVgXD7xSiSPjLhyfwg) | Be My Slave / Damnation Alley | 1983 | Trackstijl, gebruik en reserve |
| Bloodgood | [Lamb of God](https://open.spotify.com/track/0FzrGsKte8AAmjcSFyoGJF) | Dangerously Close | 2013 | Trackstijl, gebruik en reserve |
| Bret Michaels | [Nothin' But A Good Time - Re-Recorded](https://open.spotify.com/track/4kMA2MXV8GgF6MwbMD3nD0) | 100 Rock Power Tracks from the '70s, '80s & '90s | 2010 | Versieaanduiding in titel/album; Verzamel-/archiefcontext in albumtitel |
| Brian Durbin | [Don't Let Go](https://open.spotify.com/track/5FE9utEvC5FeHl554QYRkH) | Only Jams | 2023 | Trackstijl, gebruik en reserve |
| Cry Wolf | [No One Cares](https://open.spotify.com/track/6JYpcrdsUaWVBkRAfduHET) | Disaster | 2010 | Trackstijl, gebruik en reserve |
| Cyanide | [Nikki Sixx in Disguise](https://open.spotify.com/track/6NBbDMw691g08HeKa8EjyG) | Lethal Dose | 2015 | Trackstijl, gebruik en reserve |
| Dagger | [Not Afraid of the Night](https://open.spotify.com/track/5TKndAhkYfz3tT9NUn5ren) | Not Afraid of the Night | 1985 | Trackstijl, gebruik en reserve |
| Dave Niederberger | [Crazy Things](https://open.spotify.com/track/5cPms3094HBXRUkzF4Btq7) | Crazy Things | 2024 | Trackstijl, gebruik en reserve |
| Dead Addiction | [Live at the Scene of the Crime](https://open.spotify.com/track/2D8fS2IWBQICqYjvTmrb6O) | ...of Vice and Men | 2023 | Live-woord in titel/album; uitvoering nog controleren |
| Dizzy Fox | [Over the Top](https://open.spotify.com/track/0e9LFPolYhPbVWJkR8u2wa) | First Bite | 2018 | Trackstijl, gebruik en reserve |
| EyeBolt | [Her Legs - Demo](https://open.spotify.com/track/4jgLDkpd4Og9l8HC8pbHPP) | Her Legs (Demo) | 2023 | Versieaanduiding in titel/album |
| Fabri Kiareli's F.E.A.S.T. | [Love Renegade](https://open.spotify.com/track/2ykr24AgNGfWA4RuXFNTW7) | Rise | 2010 | Trackstijl, gebruik en reserve |
| Famous Underground | [Like an Animal](https://open.spotify.com/track/2byTL4KtY1cu40UM44hYy1) | Like an Animal | 2021 | Trackstijl, gebruik en reserve |
| FerreTT | [Farmer Vincent's Fritters](https://open.spotify.com/track/7GhBJmicg1GoLxfHx6x8F7) | Glamdemic | 2024 | Trackstijl, gebruik en reserve |
| Fifth Angel | [Resist the Tyrant - Single Edit](https://open.spotify.com/track/7G6aaRnkZIDVBFIJfjA17w) | Resist the Tyrant | 2023 | Versieaanduiding in titel/album |
| Frehley's Comet | [Insane](https://open.spotify.com/track/0m1J2zlyqWduzS6lkjslzs) | Second Sighting | 1988 | Trackstijl, gebruik en reserve |
| Giuntini;Tony Martin | [Anno Mundi](https://open.spotify.com/track/67J9Ur1aQRkYC8jHrEH6W0) | Great Lefty: Live Forever! (Tribute to Tony Iommi Godfather Of Metal) | 2015 | Tribute-/covercontext in titel/album; Live-woord in titel/album; uitvoering nog controleren |
| Gotham Saints | [Hang Em High](https://open.spotify.com/track/7rmFq5YOuh1VWpA0akknQp) | Hang Em High | 2013 | Trackstijl, gebruik en reserve |
| Gypsy Rose | [If Your Love Is Gone](https://open.spotify.com/track/1iGvPUw50XQuIRftlGRFcw) | Poisoned By Love | 2012 | Trackstijl, gebruik en reserve |
| Hairbangers Ball | [All Aboard The Bang Train](https://open.spotify.com/track/1FWb3ule3UGucIBKuoYOFJ) | All Aboard The Bang Train | 2021 | Trackstijl, gebruik en reserve |
| HALLOWEEN | [Tales From The Crypt](https://open.spotify.com/track/4uxXeaqhXlj2sm8sp42Mq1) | Don't Metal With Evil | 1985 | Trackstijl, gebruik en reserve |
| Heaven | [In the beginning](https://open.spotify.com/track/2GzjKk2l5Cwkc5FyQgQODQ) | Heaven - Digitally Remastered | 2021 | Versieaanduiding in titel/album |
| Hysteria | [Rock Police](https://open.spotify.com/track/74wGbxcUBJNJdE9qkFHDtO) | Rock Police | 2020 | Trackstijl, gebruik en reserve |
| Invasion | [All For All](https://open.spotify.com/track/5CZvaGIMgByckotMvygDj7) | All For All | 2024 | Trackstijl, gebruik en reserve |
| Jizzy Pearl | [Sweet Child O' Mine](https://open.spotify.com/track/0pRYZ20PxnscwJJ07SQQ4l) | This is Metal's Most Covered Moments of the '80s | 2006 | Tribute-/covercontext in titel/album |
| Joshua Perahia | [Surrender Love](https://open.spotify.com/track/3MsijRMGrZmCB5sLh6xiQU) | Surrender | 2008 | Trackstijl, gebruik en reserve |
| Junkyard | [Hollywood](https://open.spotify.com/track/5sxXZgse0xqjhJZucmT3RZ) | Hollywood | 2007 | Trackstijl, gebruik en reserve |
| Kenny McCafferty | [Passion (Dirty Blonde 2020 remaster) - Remaster](https://open.spotify.com/track/5aTrUOL4sAmwB83P76rgoz) | Passion (Dirty Blonde 2020 remaster) [Remaster] | 2020 | Versieaanduiding in titel/album |
| Kk Wilde | [Boys Night Out](https://open.spotify.com/track/29eWgiABnhXJuh6ANvwrUq) | Rock n Roll | 2022 | Trackstijl, gebruik en reserve |
| L.A. Knights | [Sure Fire](https://open.spotify.com/track/5WQw9h936PgkNFSm0XmwWX) | Rubber City Meltdown | 2013 | Trackstijl, gebruik en reserve |
| LIVE WIRE | [Nobody Beats Me](https://open.spotify.com/track/277NHPZ7qAtTTWGP2QiIN8) | Nobody Beats Me | 2021 | Trackstijl, gebruik en reserve |
| Lynam;Tom Keifer;Hinder | [Enemy](https://open.spotify.com/track/19X8ebFSLDivwXZBtWbxNq) | Tragic City Symphony | 2008 | Trackstijl, gebruik en reserve |
| Mass | [Nine Tonight](https://open.spotify.com/track/4eXOOnNRylfaqrflcCupHK) | Voices in the Night | 1989 | Trackstijl, gebruik en reserve |
| Mickey Ratt | [You Think You're Tough](https://open.spotify.com/track/6TvG7Ox8TUbvC6bxsJ0BjU) | Ratt Era - the Best Of | 2006 | Verzamel-/archiefcontext in albumtitel |
| Nine | [Too Late](https://open.spotify.com/track/6A9PYXxwzpvHhz4QoyWS5o) | Nine | 2021 | Trackstijl, gebruik en reserve |
| Only Child | [I Believe in You](https://open.spotify.com/track/5wBkIktn6E3NMn9Jqfjnv0) | Only Child (Deluxe Version) | 2012 | Uitgebreide uitgave in albumtitel |
| Rage of Angels | [Reason to Rock](https://open.spotify.com/track/7iGP8FwUY3ysL5mGpnpNok) | Rage of Angels | 1989 | Trackstijl, gebruik en reserve |
| Richard Kendrick;Ron Keel | [Lick It Up (as made famous by KISS)](https://open.spotify.com/track/25tghtkj7oGnWfrQi3GKdn) | Hair Metal In Covers Vol. 2 | 2008 | Tribute-/covercontext in titel/album |
| Roxanne | [Cherry Bay](https://open.spotify.com/track/3gtmYnsRjZzSQCsHucAOZu) | Roxanne | 2009 | Trackstijl, gebruik en reserve |
| Sacred Warrior | [Master's Command](https://open.spotify.com/track/2xzhR5xwGC15vYv8xFaZw4) | Master's Command (Remastered) | 1989 | Versieaanduiding in titel/album |
| Scarlet Rose | [Rise From The Ashes](https://open.spotify.com/track/0ScOzceqW0cTq7pR81VNcz) | Rise From The Ashes | 2023 | Trackstijl, gebruik en reserve |
| Seduce | [Crash Landing - 2020 Remaster](https://open.spotify.com/track/3yMifzVTvJBRxnol8Oup32) | Too Much Ain't Enough (2020 Remaster) | 1988 | Versieaanduiding in titel/album |
| Sex 'N' Roll | [Roadrock](https://open.spotify.com/track/2zDE6qxdVk6Pnp46JIWxic) | Sex 'n' Roll | 2019 | Trackstijl, gebruik en reserve |
| Shameless | [Shout It Out](https://open.spotify.com/track/35e0IxHYP3kaIExi79rys1) | So Good, You Should... | 2022 | Trackstijl, gebruik en reserve |
| Shok Paris | [Marseilles de Sade](https://open.spotify.com/track/44R1xxUm8yvnrvWmpFwmmK) | Go for the Throat | 2010 | Trackstijl, gebruik en reserve |
| Shotgun Symphony | [What Happens to Love](https://open.spotify.com/track/5cLyIdJZFilgfQpXIs4ngn) | Shotgun Symphony | 2010 | Trackstijl, gebruik en reserve |
| SirGibson | [Johnny B. Goode](https://open.spotify.com/track/07nOcZbIGANYkXjSwlmwBn) | Johnny B. Goode | 2024 | Trackstijl, gebruik en reserve |
| Skärlet | [Skärlet](https://open.spotify.com/track/3VpU9RYbcPQMPv7QQ6SIFI) | Skärlet | 2016 | Trackstijl, gebruik en reserve |
| Station | [Close My Eyes](https://open.spotify.com/track/04dxCbrdlJGukHY9L5E6r1) | And Time Goes On | 2023 | Trackstijl, gebruik en reserve |
| Steeler | [Cold Day in Hell](https://open.spotify.com/track/2IMrWWsHaEm9jXei3N7mfc) | Hollywood Rocks! | 2007 | Trackstijl, gebruik en reserve |
| Steve Plunkett | [Too Hot To Stop (as heard on Criminal Minds)](https://open.spotify.com/track/7xaXDiXjcVH8eZJS5R4KAu) | Big Networks, Big Music Volume 10 | 2009 | Trackstijl, gebruik en reserve |
| Sweet Savage | [Do Ya](https://open.spotify.com/track/7lJGsla1h64PelZ53d4YgZ) | Archives | 2004 | Verzamel-/archiefcontext in albumtitel |
| Tobruk | [Wild On The Run](https://open.spotify.com/track/0dprIaAzqac62p66lvfNQt) | Wild On The Run | 2004 | Trackstijl, gebruik en reserve |
| Tokyo Blade | [Night Of The Blade](https://open.spotify.com/track/5zsiVdb0xIZaShQj6klzBA) | Night Of The Blade | 1984 | Trackstijl, gebruik en reserve |
| Vision | [6049](https://open.spotify.com/track/3gvfSvKcstBSFv8OdMPV5T) | 6049 | 2023 | Trackstijl, gebruik en reserve |
| White Tyger | [Runaway Bride](https://open.spotify.com/track/6Cekxm6doN7rC5IYjSkcYy) | Runaway Bride | 2024 | Trackstijl, gebruik en reserve |
| Xenon | [Holding On](https://open.spotify.com/track/0BOLXa4KczJUhdKToxJ6Ne) | America's New Design | 1989 | Trackstijl, gebruik en reserve |
| Zodiac Mindwarp | [Prime Mover (Exclusive Version)](https://open.spotify.com/track/0ABF2qe6bYNwUZ40aJgBTH) | 100 Hair Metal Anthems | 2008 | Versieaanduiding in titel/album; Verzamel-/archiefcontext in albumtitel |

## Positieve stroom apart

Deze opname heeft positieve-bankbewijs uit 3 oktober. Zonder actuele reservegegevens worden zij niet als vergeten aangemerkt.

| Artiest | Track | Album | Vastgelegd oordeel |
|---|---|---|---|
| Kip Winger;Andreas Kisser;Vinnie Moore;Stu Hamm;Mike Mangini;Robert Berry;Jeff Feldman;Trent Gardner | Limelight | New World Man | RAAK |

## Grenzen van de proefcollectie

- De complete genrefilterinventaris telt 474 opnamen: 410 Geëxposeerd en 64 Onverkend. Deze kandidaatcollectie is een werkselectie van 63 uit die 64.
- Jester en Dirty White Boy zijn nu Geëxposeerd via DNA-exportregistratie; hun stijlvragen blijven apart bewaard.
- Vijftien aangrenzende onderzoekscases vallen buiten het genretotaal.
- Er zijn geen nieuwe definitieve VE-statussen, actuele FIFO-statussen, herontdekkingskandidaten of technische stroomafwijkingen toegekend.
- Alleen bestaande opname- en albumtitels zijn doorzocht. Er is geen luisterbeoordeling uitgevoerd.

[Actuele volledige inventaris](Music-DNA-Depot-v1-Overzicht.md) · [Gegevens en controles per kandidaat](Music-DNA-Depot-Proefcollectie.json)
