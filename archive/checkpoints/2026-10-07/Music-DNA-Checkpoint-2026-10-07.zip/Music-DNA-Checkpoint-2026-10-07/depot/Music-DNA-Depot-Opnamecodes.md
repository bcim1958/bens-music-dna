# Depot — opnamecodes en alternatieve URI’s

Actuele controle 7 oktober 2026, v1.18. De 63 resterende voorlopige VE-kandidaten zijn onderzocht met de losse CSV-bronnen en aanvullende Spotify-exportarchieven.

## ISRC-dekking

**Alle 63 kandidaten hebben nu een geldige ISRC in bestaande bronexports.** Er zijn geen conflicterende broncodes gevonden. Codes zijn voor vergelijking naar hoofdletters genormaliseerd en niet onafhankelijk bij de registratiehouder geverifieerd.

De referentie omvat 3.523 URI’s met gebruiksregistratie: gebruikte Masterrecords over alle genres, DNA-playlist-exports en Depot-expositieregistraties. Geen kandidaat heeft een gelijke bron-ISRC bij een andere geregistreerd geëxposeerde URI binnen deze brondekking. Alleen referentieopnamen met beschikbare broncodes kunnen matchen. Dit is geen bewijs van nooit geëxposeerd.

| Artiest | Opname | Bron-ISRC |
|---|---|---|
| Barren Cross | Imaginary Music | USRS73777001 |
| Bitch | Heavy Metal Breakdown | USMBR0501245 |
| Bloodgood | Lamb of God | QMEU31302210 |
| Bret Michaels | Nothin' But A Good Time - Re-Recorded | USA371109906 |
| Joshua Perahia | Surrender Love | USY280762743 |
| Junkyard | Hollywood | USA560635045 |
| Steeler | Cold Day in Hell | USA560659466 |
| Steve Plunkett | Too Hot To Stop (as heard on Criminal Minds) | USZXT0818110 |
| Tokyo Blade | Night Of The Blade | USL4R0783055 |
| Sacred Warrior | Master's Command | USACX1002558 |
| Tobruk | Wild On The Run | GBKYA0703285 |
| Frehley's Comet | Insane | USAT20622419 |
| Shok Paris | Marseilles de Sade | USHM81091045 |
| Nine | Too Late | USHM92134321 |
| Fifth Angel | Resist the Tyrant - Single Edit | DED832200657 |
| Station | Close My Eyes | QZWHN2307007 |
| Cry Wolf | No One Cares | FR59R2016356 |
| HALLOWEEN | Tales From The Crypt | QZHN92165945 |
| Lynam;Tom Keifer;Hinder | Enemy | TCACE1502941 |
| Only Child | I Believe in You | GBKPL1510728 |
| Kenny McCafferty | Passion (Dirty Blonde 2020 remaster) - Remaster | QZNWZ2094768 |
| Zodiac Mindwarp | Prime Mover (Exclusive Version) | USA560874005 |
| Shameless | Shout It Out | DEUJ62200035 |
| Shotgun Symphony | What Happens to Love | USA561043239 |
| Cyanide | Nikki Sixx in Disguise | USX9P1444557 |
| Gypsy Rose | If Your Love Is Gone | USHM91250703 |
| Heaven | In the beginning | GBRKQ2116255 |
| Dave Niederberger | Crazy Things | QZWFR2411836 |
| Scarlet Rose | Rise From The Ashes | QZDA52399165 |
| Seduce | Crash Landing - 2020 Remaster | QM4TW2041901 |
| L.A. Knights | Sure Fire | USHM21310363 |
| Sweet Savage | Do Ya | USY280759122 |
| Giuntini;Tony Martin | Anno Mundi | ITP441500015 |
| Invasion | All For All | QZHN92452496 |
| Mickey Ratt | You Think You're Tough | USA370575241 |
| A.Z.R.O. | 99 Miles | USASN2200375 |
| EyeBolt | Her Legs - Demo | QZHN82377851 |
| Dagger | Not Afraid of the Night | CAU118508938 |
| Mass | Nine Tonight | USQY51085195 |
| Rage of Angels | Reason to Rock | TCAEB1954870 |
| Roxanne | Cherry Bay | USCGH0974693 |
| Xenon | Holding On | USHM80894970 |
| White Tyger | Runaway Bride | QZFYX2450673 |
| Hairbangers Ball | All Aboard The Bang Train | QZDA62187266 |
| Jizzy Pearl | Sweet Child O' Mine | USA370675252 |
| Richard Kendrick;Ron Keel | Lick It Up (as made famous by KISS) | USA370915764 |
| Dizzy Fox | Over the Top | USHM21883448 |
| SirGibson | Johnny B. Goode | DEAR42440222 |
| LIVE WIRE | Nobody Beats Me | ESA012354173 |
| Dead Addiction | Live at the Scene of the Crime | QZPJ32265703 |
| FerreTT | Farmer Vincent's Fritters | USGE32490609 |
| 80's Bush | Sleazy Dirty Rock n Roll | QM9AA2088652 |
| Sex 'N' Roll | Roadrock | QZGLM1904217 |
| Fabri Kiareli's F.E.A.S.T. | Love Renegade | DEMK91100070 |
| Gotham Saints | Hang Em High | USHM21307451 |
| Alleycatz | Do It For The Rock N' Roll | QZHNA2327058 |
| Brian Durbin | Don't Let Go | QZK6F2121423 |
| Hysteria | Rock Police | CH5972000022 |
| Skärlet | Skärlet | AUPAI1600001 |
| Babylon Shakes | Scarlet Sins | TCAJG2550685 |
| Kk Wilde | Boys Night Out | USHM22335705 |
| Famous Underground | Like an Animal | GX3Q92182506 |
| Vision | 6049 | QZDA62314732 |

## Steeler — Cold Day in Hell


| Kenmerk | Depot-opname | Oudere bronplaylist-opname |
|---|---|---|
| Spotify-URI | spotify:track:2IMrWWsHaEm9jXei3N7mfc | spotify:track:6cH97BCrMrVOMwFa8ycyKq |
| Album | Hollywood Rocks! | Steeler |
| Getoond catalogusjaar | 2007 | 1983 |
| Duur in bronexport | 253.533 ms | 257.506 ms |
| Getoonde duur | 4:13 | 4:17 |
| Bron-ISRC | USA560659466 | QM7281532717 |

Beide [Depot-opname](https://open.spotify.com/track/2IMrWWsHaEm9jXei3N7mfc) en [oudere variant](https://open.spotify.com/track/6cH97BCrMrVOMwFa8ycyKq) verwijzen live naar Spotify-artiest-ID `0Bok9cwEPeFS6vv7iVrkDj`. De andere URI staat in de bestaande Exportify-bronplaylist Ben’s Top 100 Glam Metal Bands, CSV-regel 59. De aanwezige Added At-waarde is geen datum van DNA-expositie.

De verschillende ISRC’s, albums en speelduur worden afzonderlijk bewaard. Verschillende codes bewijzen op zichzelf geen verschillende oorspronkelijke uitvoering; hetzelfde artiestprofiel bewijst geen opname-equivalentie. Er wordt daarom niets samengevoegd en geen expositiestatus overgenomen.


## Depotuitkomst

De actuele stand is **410 Geëxposeerd, 64 Onverkend en 63 voorlopige VE-kandidaten**. Alle 63 kandidaten hebben broncodes en bijbehorende bronregels. Steeler heeft vaste artiest-/albumkoppelingen en een expliciet versieonderzoek. De oorspronkelijke Master is ongewijzigd.

[ISRC-brongegevens](Music-DNA-Depot-ISRC-Controle.json) · [Steeler-vergelijking](Music-DNA-Depot-Steeler-Versiekoppeling.json) · [Actueel overzicht](Music-DNA-Depot-v1-Overzicht.md)
