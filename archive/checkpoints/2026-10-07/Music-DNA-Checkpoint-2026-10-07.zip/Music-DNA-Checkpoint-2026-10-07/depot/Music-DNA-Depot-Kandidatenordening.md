# Music DNA Depot — ordening van alle 63 kandidaten

Alle kandidaten blijven Onverkend. Deze onderzoeksindeling is geen nieuwe depotstatus en rangschikt geen muzikale kwaliteit. De eerste luisterproef bevat 15; de overige 48 blijven hieronder zichtbaar.

De indeling gebruikt bestaande genrevelden, titel-/albumcontext en eerdere onderzoeksbevindingen. Versievragen krijgen voorrang boven gemengde genrelabels. Bij SirGibson blijft Johnny B. Goode een titelvraag: de titel alleen bewijst geen cover. Bij Steve Plunkett vraagt de titel een expliciete media-/verzamelcontextcontrole.


## Geen specifieke waarschuwing in onderzochte velden — 36

| Artiest — opname | Album | Genrelabels uit project | Vervolg / selectie |
|---|---|---|---|
| 80's Bush — [Sleazy Dirty Rock n Roll](https://open.spotify.com/track/0KZaCw93RIPJTveUh4ja8Z) | Sleazy Dirty Rock n Roll | glam-metal | Luisterproef #8. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| A.Z.R.O. — [99 Miles](https://open.spotify.com/track/45HvpmIR38by9GDwRm93rT) | Rock in a Hard Place | glam-metal,aor | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Alleycatz — [Do It For The Rock N' Roll](https://open.spotify.com/track/2LxLBJX6mtdtZEXeiJulGC) | Private Vices, Public Pleasures | glam-metal | Luisterproef #10. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Babylon Shakes — [Scarlet Sins](https://open.spotify.com/track/0OtfqVWR3F1shHMjiO2tyU) | Scarlet Sins | glam-metal | Luisterproef #15. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Barren Cross — [Imaginary Music](https://open.spotify.com/track/6y3HND8DFOvNLhxiomrGjG) | Atomic Arena | christelijke rock,glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Bloodgood — [Lamb of God](https://open.spotify.com/track/0FzrGsKte8AAmjcSFyoGJF) | Dangerously Close | christelijke rock,glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Brian Durbin — [Don't Let Go](https://open.spotify.com/track/5FE9utEvC5FeHl554QYRkH) | Only Jams | glam-metal,arena rock,aor | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Cry Wolf — [No One Cares](https://open.spotify.com/track/6JYpcrdsUaWVBkRAfduHET) | Disaster | glam-metal,aor | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Dagger — [Not Afraid of the Night](https://open.spotify.com/track/5TKndAhkYfz3tT9NUn5ren) | Not Afraid of the Night | glam-metal,glamrock,aor | Luisterproef #1. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Dave Niederberger — [Crazy Things](https://open.spotify.com/track/5cPms3094HBXRUkzF4Btq7) | Crazy Things | arena rock,glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Dizzy Fox — [Over the Top](https://open.spotify.com/track/0e9LFPolYhPbVWJkR8u2wa) | First Bite | glam-metal | Luisterproef #9. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Fabri Kiareli's F.E.A.S.T. — [Love Renegade](https://open.spotify.com/track/2ykr24AgNGfWA4RuXFNTW7) | Rise | glam-metal,aor | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Famous Underground — [Like an Animal](https://open.spotify.com/track/2byTL4KtY1cu40UM44hYy1) | Like an Animal | glam-metal | Luisterproef #11. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| FerreTT — [Farmer Vincent's Fritters](https://open.spotify.com/track/7GhBJmicg1GoLxfHx6x8F7) | Glamdemic | glam-metal | Luisterproef #14. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Frehley's Comet — [Insane](https://open.spotify.com/track/0m1J2zlyqWduzS6lkjslzs) | Second Sighting | glam-metal,aor | Luisterproef #2. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Gotham Saints — [Hang Em High](https://open.spotify.com/track/7rmFq5YOuh1VWpA0akknQp) | Hang Em High | aor,glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Gypsy Rose — [If Your Love Is Gone](https://open.spotify.com/track/1iGvPUw50XQuIRftlGRFcw) | Poisoned By Love | glam-metal,arena rock,aor | Luisterproef #6. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Hairbangers Ball — [All Aboard The Bang Train](https://open.spotify.com/track/1FWb3ule3UGucIBKuoYOFJ) | All Aboard The Bang Train | glam-metal | Luisterproef #12. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Hysteria — [Rock Police](https://open.spotify.com/track/74wGbxcUBJNJdE9qkFHDtO) | Rock Police | glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Joshua Perahia — [Surrender Love](https://open.spotify.com/track/3MsijRMGrZmCB5sLh6xiQU) | Surrender | aor,christelijke rock,arena rock,glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Junkyard — [Hollywood](https://open.spotify.com/track/5sxXZgse0xqjhJZucmT3RZ) | Hollywood | glam-metal,glamrock | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Kk Wilde — [Boys Night Out](https://open.spotify.com/track/29eWgiABnhXJuh6ANvwrUq) | Rock n Roll | glam-metal,aor | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| L.A. Knights — [Sure Fire](https://open.spotify.com/track/5WQw9h936PgkNFSm0XmwWX) | Rubber City Meltdown | glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Nine — [Too Late](https://open.spotify.com/track/6A9PYXxwzpvHhz4QoyWS5o) | Nine | glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Rage of Angels — [Reason to Rock](https://open.spotify.com/track/7iGP8FwUY3ysL5mGpnpNok) | Rage of Angels | christelijke rock,arena rock,aor,glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Roxanne — [Cherry Bay](https://open.spotify.com/track/3gtmYnsRjZzSQCsHucAOZu) | Roxanne | aor,arena rock,glam-metal | Luisterproef #4. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Scarlet Rose — [Rise From The Ashes](https://open.spotify.com/track/0ScOzceqW0cTq7pR81VNcz) | Rise From The Ashes | glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Sex 'N' Roll — [Roadrock](https://open.spotify.com/track/2zDE6qxdVk6Pnp46JIWxic) | Sex 'n' Roll | glam-metal | Luisterproef #13. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Shameless — [Shout It Out](https://open.spotify.com/track/35e0IxHYP3kaIExi79rys1) | So Good, You Should... | glam-metal,aor | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Shotgun Symphony — [What Happens to Love](https://open.spotify.com/track/5cLyIdJZFilgfQpXIs4ngn) | Shotgun Symphony | arena rock,aor,glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Skärlet — [Skärlet](https://open.spotify.com/track/3VpU9RYbcPQMPv7QQ6SIFI) | Skärlet | glam-metal | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Station — [Close My Eyes](https://open.spotify.com/track/04dxCbrdlJGukHY9L5E6r1) | And Time Goes On | arena rock,aor,glam-metal | Luisterproef #7. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Tobruk — [Wild On The Run](https://open.spotify.com/track/0dprIaAzqac62p66lvfNQt) | Wild On The Run | aor,arena rock,glam-metal | Luisterproef #5. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Vision — [6049](https://open.spotify.com/track/3gvfSvKcstBSFv8OdMPV5T) | 6049 | glam-metal,glamrock | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| White Tyger — [Runaway Bride](https://open.spotify.com/track/6Cekxm6doN7rC5IYjSkcYy) | Runaway Bride | aor,glam-metal,arena rock | Vervolgvoorraad. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |
| Xenon — [Holding On](https://open.spotify.com/track/0BOLXa4KczJUhdKToxJ6Ne) | America's New Design | glam-metal,aor,arena rock | Luisterproef #3. Trackstijl en bruikbaarheid beluisteren; ontbreken van waarschuwingen is geen onafhankelijke verificatie. |

## Gemengde genrelabels: grensgeval beluisteren — 6

| Artiest — opname | Album | Genrelabels uit project | Vervolg / selectie |
|---|---|---|---|
| Bitch — [Heavy Metal Breakdown](https://open.spotify.com/track/5qQDHVgXD7xSiSPjLhyfwg) | Be My Slave / Damnation Alley | speedmetal,glam-metal,heavy metal | Vervolgvoorraad. Glam Metal-aansluiting beluisteren naast de overige bronlabels. |
| HALLOWEEN — [Tales From The Crypt](https://open.spotify.com/track/4uxXeaqhXlj2sm8sp42Mq1) | Don't Metal With Evil | speedmetal,heavy metal,glam-metal | Vervolgvoorraad. Glam Metal-aansluiting beluisteren naast de overige bronlabels. |
| Lynam;Tom Keifer;Hinder — [Enemy](https://open.spotify.com/track/19X8ebFSLDivwXZBtWbxNq) | Tragic City Symphony | glam-metal,glamrock,post-grunge | Vervolgvoorraad. Glam Metal-aansluiting beluisteren naast de overige bronlabels. |
| Mass — [Nine Tonight](https://open.spotify.com/track/4eXOOnNRylfaqrflcCupHK) | Voices in the Night | glam-metal,glamrock,speedmetal | Vervolgvoorraad. Glam Metal-aansluiting beluisteren naast de overige bronlabels. |
| Shok Paris — [Marseilles de Sade](https://open.spotify.com/track/44R1xxUm8yvnrvWmpFwmmK) | Go for the Throat | speedmetal,heavy metal,powermetal,glam-metal | Vervolgvoorraad. Glam Metal-aansluiting beluisteren naast de overige bronlabels. |
| Tokyo Blade — [Night Of The Blade](https://open.spotify.com/track/5zsiVdb0xIZaShQj6klzBA) | Night Of The Blade | speedmetal,heavy metal,glam-metal | Vervolgvoorraad. Glam Metal-aansluiting beluisteren naast de overige bronlabels. |

## Versie / titelcontext eerst beoordelen — 18

| Artiest — opname | Album | Genrelabels uit project | Vervolg / selectie |
|---|---|---|---|
| Bret Michaels — [Nothin' But A Good Time - Re-Recorded](https://open.spotify.com/track/4kMA2MXV8GgF6MwbMD3nD0) | 100 Rock Power Tracks from the '70s, '80s & '90s | glam-metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Versieaanduiding in titel/album; Verzamel-/archiefcontext in albumtitel |
| Dead Addiction — [Live at the Scene of the Crime](https://open.spotify.com/track/2D8fS2IWBQICqYjvTmrb6O) | ...of Vice and Men | glam-metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Live-woord in titel/album; uitvoering nog controleren |
| EyeBolt — [Her Legs - Demo](https://open.spotify.com/track/4jgLDkpd4Og9l8HC8pbHPP) | Her Legs (Demo) | glam-metal,glamrock | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Versieaanduiding in titel/album |
| Fifth Angel — [Resist the Tyrant - Single Edit](https://open.spotify.com/track/7G6aaRnkZIDVBFIJfjA17w) | Resist the Tyrant | glam-metal,powermetal,heavy metal,aor | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Versieaanduiding in titel/album |
| Giuntini;Tony Martin — [Anno Mundi](https://open.spotify.com/track/67J9Ur1aQRkYC8jHrEH6W0) | Great Lefty: Live Forever! (Tribute to Tony Iommi Godfather Of Metal) | glam-metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Tribute-/covercontext in titel/album; Live-woord in titel/album; uitvoering nog controleren |
| Heaven — [In the beginning](https://open.spotify.com/track/2GzjKk2l5Cwkc5FyQgQODQ) | Heaven - Digitally Remastered | glam-metal,aor | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Versieaanduiding in titel/album |
| Jizzy Pearl — [Sweet Child O' Mine](https://open.spotify.com/track/0pRYZ20PxnscwJJ07SQQ4l) | This is Metal's Most Covered Moments of the '80s | glam-metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Tribute-/covercontext in titel/album |
| Kenny McCafferty — [Passion (Dirty Blonde 2020 remaster) - Remaster](https://open.spotify.com/track/5aTrUOL4sAmwB83P76rgoz) | Passion (Dirty Blonde 2020 remaster) [Remaster] | glam-metal,aor | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Versieaanduiding in titel/album |
| Mickey Ratt — [You Think You're Tough](https://open.spotify.com/track/6TvG7Ox8TUbvC6bxsJ0BjU) | Ratt Era - the Best Of | glam-metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Verzamel-/archiefcontext in albumtitel |
| Only Child — [I Believe in You](https://open.spotify.com/track/5wBkIktn6E3NMn9Jqfjnv0) | Only Child (Deluxe Version) | aor,arena rock,glam-metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Uitgebreide uitgave in albumtitel |
| Richard Kendrick;Ron Keel — [Lick It Up (as made famous by KISS)](https://open.spotify.com/track/25tghtkj7oGnWfrQi3GKdn) | Hair Metal In Covers Vol. 2 | glam-metal,aor,arena rock | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Tribute-/covercontext in titel/album |
| Sacred Warrior — [Master's Command](https://open.spotify.com/track/2xzhR5xwGC15vYv8xFaZw4) | Master's Command (Remastered) | christelijke rock,glam-metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Versieaanduiding in titel/album |
| Seduce — [Crash Landing - 2020 Remaster](https://open.spotify.com/track/3yMifzVTvJBRxnol8Oup32) | Too Much Ain't Enough (2020 Remaster) | glam-metal,speedmetal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Versieaanduiding in titel/album |
| SirGibson — [Johnny B. Goode](https://open.spotify.com/track/07nOcZbIGANYkXjSwlmwBn) | Johnny B. Goode | glam-metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. |
| Steeler — [Cold Day in Hell](https://open.spotify.com/track/2IMrWWsHaEm9jXei3N7mfc) | Hollywood Rocks! | glam-metal,glamrock,heavy metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. |
| Steve Plunkett — [Too Hot To Stop (as heard on Criminal Minds)](https://open.spotify.com/track/7xaXDiXjcVH8eZJS5R4KAu) | Big Networks, Big Music Volume 10 | aor,arena rock,glam-metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. |
| Sweet Savage — [Do Ya](https://open.spotify.com/track/7lJGsla1h64PelZ53d4YgZ) | Archives | glam-metal,glamrock | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Verzamel-/archiefcontext in albumtitel |
| Zodiac Mindwarp — [Prime Mover (Exclusive Version)](https://open.spotify.com/track/0ABF2qe6bYNwUZ40aJgBTH) | 100 Hair Metal Anthems | glam-metal | Vervolgvoorraad. Aangeduide versie of titelcontext controleren vóór presentatie; geen versie-equivalentie veronderstellen. Versieaanduiding in titel/album; Verzamel-/archiefcontext in albumtitel |

## Identiteit / herkomst nader duiden — 3

| Artiest — opname | Album | Genrelabels uit project | Vervolg / selectie |
|---|---|---|---|
| Cyanide — [Nikki Sixx in Disguise](https://open.spotify.com/track/6NBbDMw691g08HeKa8EjyG) | Lethal Dose | glam-metal | Vervolgvoorraad. Herkomst-/artiestcontrole raadplegen; Glam Metal op deze opname beluisteren. |
| Invasion — [All For All](https://open.spotify.com/track/5CZvaGIMgByckotMvygDj7) | All For All | aor,arena rock,glam-metal | Vervolgvoorraad. Herkomst-/artiestcontrole raadplegen; Glam Metal op deze opname beluisteren. |
| LIVE WIRE — [Nobody Beats Me](https://open.spotify.com/track/277NHPZ7qAtTTWGP2QiIN8) | Nobody Beats Me | glam-metal,aor | Vervolgvoorraad. Herkomst-/artiestcontrole raadplegen; Glam Metal op deze opname beluisteren. |

## Gemeenschappelijke bewijsgrens

Voor alle 63: geen expositie gevonden binnen de gecontroleerde bronnen; nooit geëxposeerd niet bewezen; actuele FIFO-reserve niet vastgesteld; ISRC beschikbaar uit bronexport. Identieke broncodes bij andere geëxposeerde URI’s zijn binnen de beschikbare codedekking niet gevonden. Dit sluit ontbrekende historie of andere versies niet uit.

Kip Winger en medeartiesten — Limelight blijft apart als historisch positieve stroomcase; deze opname behoort niet tot de 63 kandidaten.

Brongegevens: [Music-DNA-Depot-Proefcollectie.json](/Users/benvanbelzen/Documents/Codex/2026-10-07/referenced-chatgpt-conversation-this-is-an/outputs/Music-DNA-Depot-Proefcollectie.json). Luisterselectie: [Music-DNA-Depot-Luisterproef.md](/Users/benvanbelzen/Documents/Codex/2026-10-07/referenced-chatgpt-conversation-this-is-an/outputs/Music-DNA-Depot-Luisterproef.md).
