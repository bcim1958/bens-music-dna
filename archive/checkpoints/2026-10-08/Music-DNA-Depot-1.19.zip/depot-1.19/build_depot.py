import json,csv,io,zipfile,pathlib,re,hashlib,collections
B=pathlib.Path('repo/data/master-1.14.1'); O=pathlib.Path('repo/data/depot-1.19');O.mkdir(parents=True,exist_ok=True)
m=json.load(open(B/'MASTER_ACTUEEL.json')); evidence=json.load(open(B/'GEBRUIKSBEWIJS.json'))
old=json.load(open('checkpoint/Music-DNA-Checkpoint-2026-10-07/depot/Music-DNA-Depot-v1-Glam-Metal.json'))
historyix={r['spotify_uri']:r for r in old['records']}; gix={r['spotify_uri']:r for r in old['records'] if r.get('scope')=='Glam/Hair Metal-filter'}; z=zipfile.ZipFile('upload/spotify_playlists-2 kopie.zip')
exports=collections.defaultdict(list); parsed=0; excluded=[]
for name in z.namelist():
    if not name.lower().endswith('.csv') or '__MACOSX' in name:continue
    # Only actual DNA presentation exports count, not source favorites/importers/audits.
    if not re.search(r'(^|/)(?:Ontdek-DNA|DNA_(?:SPECIAL|JAARBOEK|BONUS)|.*(?:_DNA(?:_|\.|$)|DNA\.csv))',name,re.I):
        excluded.append(name);continue
    rows=list(csv.DictReader(io.StringIO(z.read(name).decode('utf-8-sig')))); parsed+=1
    if 'Track URI' not in (rows[0] if rows else {}):continue
    for pos,r in enumerate(rows,1):
        uri=r.get('Track URI')
        if uri:exports[uri].append({'member':name,'row_1based':pos+1,'sha256':hashlib.sha256(z.read(name)).hexdigest(),'kind':'DNA-playlist-export','exact_spotify_uri':uri})
records=[];albums={};artists={};indices={k:collections.defaultdict(list) for k in ['genre_style','year','decade','country','artist','status']}
for r in m:
    uri=r['Track URI'];prior=historyix.get(uri,{}); apps=[x for x in (r.get('DNA Playlist(s)') or '').split('; ') if x]
    ev=evidence.get(uri,[]); ex=exports.get(uri,[]); used=r.get('DNA Gebruikt')=='Ja'; exposed=used or bool(ev) or bool(ex)
    positive=bool(prior.get('positive_bank_evidence') or prior.get('ratings_evidence'))
    status='Geëxposeerd' if exposed else 'Onverkend'
    group='Geëxposeerd' if exposed else ('Historisch positief; actuele FIFO open' if positive else 'Voorlopige depotkandidaat')
    styles=list(dict.fromkeys(s.strip() for s in str(r.get('AllMusic stijlen') or '').split(';') if s.strip()))
    spotifygenres=[s.strip() for s in str(r.get('Genres') or '').split(',') if s.strip()]
    year=r.get('DNA Uitgiftejaar uitvoering'); country=r.get('Land van herkomst');album=r.get('Album Name');artist=r.get('Artist Name(s)')
    research=[]
    for k,v in [('album',album),('year',year),('country',country),('genre',r.get('AllMusic hoofdstructuur'))]:
        if not v:research.append(k+' ontbreekt')
    if not exposed:research+=['geen expositie gevonden binnen beschikbare dekking','actuele volledige FIFO-snapshot ontbreekt','nooit geëxposeerd niet bewezen']
    if styles or spotifygenres:research.append('artiest-/bronlabels; geen onafhankelijke trackclassificatie')
    obj={'object_id':'spotify:'+uri.split(':')[-1],'spotify_uri':uri,'artist':artist,'track':r['Track Name'],'album':album,'year_source':year,'release_date_source':r.get('Release Date'),'country_source':country,'region_source':r.get('DNA Regio'),'genre_source':r.get('AllMusic hoofdstructuur'),'styles_source':styles,'spotify_artist_genres':spotifygenres,'master_version':'1.14.1','master_used':used,'applications':apps,'depot_status':status,'inventory_group':group,'exposure_basis':'gebruikregistratie/archiefbewijs' if exposed else None,'evidence':ev,'additional_export_evidence':ex,'fifo_current':'onbekend; nieuwste aangetoonde volledige bron 2026-10-03','historical_positive_evidence':prior.get('positive_bank_evidence',[]),'ratings_evidence':prior.get('ratings_evidence',[]),'forgotten_gem_candidate':not exposed and not positive,'forgotten_gem_confirmed':False,'research':research,'research_stage':'Onverkend' if research else 'Voorlopig geduid','original_recording_year_verified':False,'listening_dna':None}
    records.append(obj)
    if artist:
        aid='artist-credit:'+hashlib.sha256(artist.encode()).hexdigest()[:20];artists.setdefault(aid,{'id':aid,'credit':artist,'identity_basis':'exacte gecrediteerde naam; Spotify-artiest-ID nog niet bevestigd','tracks':[]})['tracks'].append(obj['object_id'])
    if artist and album:
        key=artist+'\0'+album;aid='album-source:'+hashlib.sha256(key.encode()).hexdigest()[:20];a=albums.setdefault(aid,{'id':aid,'artist_credit':artist,'album':album,'identity_basis':'exacte artiest-/albumbronstring; geen Spotify-album-ID','tracks':[],'exposed_tracks':[],'unexposed_tracks':[],'applications':set()});a['tracks'].append(obj['object_id']);a['exposed_tracks' if exposed else 'unexposed_tracks'].append(obj['object_id']);a['applications'].update(apps)
    for k,values in [('genre_style',[r.get('AllMusic hoofdstructuur')]+styles+spotifygenres),('year',[year]),('decade',[r.get('DNA Decennium uitvoering')]),('country',[country]),('artist',[artist]),('status',[status,group])]:
        for v in set(x for x in values if x):indices[k][str(v)].append(obj['object_id'])
for a in albums.values():a['applications']=sorted(a['applications'])
glam=[r for r in records if r['spotify_uri'] in gix]
newglam=[r for r in records if r['spotify_uri'] not in gix and any('glam' in s.lower() or 'hair metal' in s.lower() for s in r['styles_source']+r['spotify_artist_genres'])]
summary={'as_of':'2026-10-08','revision':'1.19','master_version':'1.14.1','records':len(records),'status_counts':dict(collections.Counter(r['depot_status'] for r in records)),'inventory_counts':dict(collections.Counter(r['inventory_group'] for r in records)),'artist_credit_records':len(artists),'album_source_records':len(albums),'original_glam_scope':len(glam),'original_glam_status_counts':dict(collections.Counter(r['depot_status'] for r in glam)),'original_glam_candidates':sum(r['forgotten_gem_candidate'] for r in glam),'new_glam_label_records':len(newglam),'new_exposure_from_upload_on_registered_unused':sum(not r['master_used'] and bool(r['additional_export_evidence']) for r in records),'confirmed_forgotten_gems':0,'current_fifo_proven_records':0,'dna_csv_exports_parsed':parsed,'excluded_csv_members':excluded,'master_changed':False,'runtime_changed':False,'w41_endToEndProven':False}
assert len(records)==3877 and len({r['object_id'] for r in records})==3877
assert len(glam)==474 and all(not r['forgotten_gem_confirmed'] for r in records)
def save(name,d):(O/name).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
save('OBJECTEN.json',records);save('GLAM_PROEF.json',{'original_scope':glam,'new_label_candidates':newglam});save('ALBUMS.json',list(albums.values()));save('ARTIESTEN.json',list(artists.values()));save('THEMATISCHE_INDEX.json',indices);save('CONTROLE.json',summary)
save('EXPOSITIEVERSCHILLEN_MASTER.json',[{'uri':r['spotify_uri'],'artist':r['artist'],'track':r['track'],'evidence':r['additional_export_evidence']} for r in records if not r['master_used'] and r['additional_export_evidence']])
print(json.dumps(summary,ensure_ascii=False,indent=2))
