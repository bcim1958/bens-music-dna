import json, csv, pathlib, re, copy, hashlib, collections
B=pathlib.Path('checkpoint/Music-DNA-Checkpoint-2026-10-07')
O=pathlib.Path('repo/data/master-1.14'); O.mkdir(parents=True,exist_ok=True)
def read(p): return json.load(open(B/p))
def dump(p,d): (O/p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
original=read('master-1.13/MASTER_ACTUEEL.json')
master=copy.deepcopy(original); ix={r['Track URI']:r for r in master}
assert len(ix)==len(master)
sources=collections.defaultdict(list); exceptions=[]; aliases=[]
def canonical(label):
    label=re.sub(r'\s*\[exportbestandsnaam\]\s*','',label).strip()
    label=re.sub(r'\s+',' ',label)
    s=re.search(r'DNA[ _-]*SPECIAL[ _-]*(\d+)',label,re.I)
    if s:
        # Known live naming conflict: do not silently decide Los Angeles/Liverpool.
        if int(s[1])==65 and 'liverpool' in label.lower():
            return 'DNA SPECIAL 65 [historische Liverpool-bron, identiteit open]'
        return f'DNA SPECIAL {int(s[1]):02d}'
    y=re.search(r'DNA[ _-]*JAARBOEK[ _-]*(\d{4})',label,re.I)
    if y: return 'DNA JAARBOEK '+y[1]
    if re.search(r'W40',label,re.I): return 'Ontdek DNA W40 [museumexpositie]'
    return label
apps={}
for r in master:
    raw=r.get('DNA Playlist(s)') or ''
    old=[x.strip() for x in str(raw).split(';') if x.strip()]
    apps[r['Track URI']]=set(canonical(x) for x in old)
    if len(apps[r['Track URI']])!=len(old): aliases.append({'uri':r['Track URI'],'before':old,'after':sorted(apps[r['Track URI']])})
def ensure(uri,artist,track,record=None):
    if uri in ix: return
    r={k:None for k in original[0]}
    if record: r.update(record)
    r.update({'Track URI':uri,'Artist Name(s)':artist,'Track Name':track,'DNA Gebruikt':'Nee','DNA Playlist(s)':None,'DNA Aantal toepassingen':0})
    if not record:
        r.update({'Herkomstcontrole':'onverkend','Classificatiestatus':'onverkend; toegevoegd uit Specials-bronregister','DNA Jaarstatus':'onbekend; bronjaar ontbreekt','DNA Jaarzekerheid':'Onbekend','DNA Tijdactie':'Onderzoeken','DNA Plaatszekerheid':'Onbekend','DNA Plaatsactie':'Onderzoeken'})
    ix[uri]=r; master.append(r); apps[uri]=set()
def add(uri,label,evidence):
    if uri not in ix:
        exceptions.append({'kind':'expositie zonder Masterrecord','uri':uri,'label':label,'evidence':evidence}); return
    if label: apps[uri].add(canonical(label))
    sources[uri].append(evidence)
# Preserve source-level evidence; identical exports contribute one application.
for r in read('depot/Music-DNA-Depot-Expositieregister.json'):
    uri=r['spotify_uri_source']
    for e in r['evidence']:
        if e.get('kind')=='Mastergebruiksregistratie': continue
        eu=e.get('exact_spotify_uri')
        # Only accept explicit exact URI identity for historical export joins.
        if eu==uri: add(uri,e.get('label'),e)
for e in read('depot/Music-DNA-Depot-Archiefcontrole.json')['dna_export_evidence']:
    add(e['exact_spotify_uri'],e.get('label'),e)
# Historical Specials source is an aggregated corpus. Preserve missing number as unknown.
specials=read('special-103/SPECIALS_BRONRECORDS.json')
for pos,r in enumerate(specials,1):
    uri=r['Track URI']; artist=r.get('Artist Name(s)',r.get('Artist')); track=r.get('Track Name',r.get('Track'))
    ensure(uri,artist,track)
    label=f"DNA SPECIAL {int(r['Special']):02d}" if r.get('Special') else None
    if r.get('Special') and int(r['Special'])==65:
        label='DNA SPECIAL 65 [historische Liverpool-bron, identiteit open]'
    add(uri,label,{'kind':'gearchiveerd Specials-bronregister','source':'special-103/SPECIALS_BRONRECORDS.json','row_1based':pos,'special':r.get('Special'),'exact_spotify_uri':uri,'number_unknown':not bool(r.get('Special'))})
# Definitive yearbook canon supersedes historical yearbook memberships.
yearbooks=read('jaarboeken/CANONIEK_1970_2025.json')
year_uri=collections.defaultdict(set)
for r in yearbooks: year_uri[r['year']].add(r['spotify_uri'])
removed=[]
for uri,ls in apps.items():
    for label in list(ls):
        match=re.fullmatch(r'DNA JAARBOEK (\d{4})',label)
        if match and int(match[1]) in year_uri and uri not in year_uri[int(match[1])]:
            ls.remove(label); removed.append({'uri':uri,'application':label,'reason':'niet in definitieve Jaarboekcanon'})
for pos,r in enumerate(yearbooks,1):
    add(r['spotify_uri'],f"DNA JAARBOEK {r['year']}",{'kind':'definitieve Jaarboekcanon','source':'jaarboeken/CANONIEK_1970_2025.json','row_1based':pos,'year':r['year'],'position':r['position'],'exact_spotify_uri':r['spotify_uri']})
for n,p in [(101,'SELECTIE.json'),(102,'SELECTIE_15.json'),(103,'SELECTIE_DEFINITIEF.json')]:
    d=read(f'special-{n}/{p}')
    if isinstance(d,dict):
        d=d.get('tracks',d.get('selection',d.get('records',[])))
    for r in d:
        uri=r.get('spotify_uri',r.get('uri',r.get('Track URI')))
        if uri: add(uri,f'DNA SPECIAL {n}',{'kind':'gearchiveerde definitieve Specialselectie; publicatie bevestigd in checkpoint','source':f'special-{n}/{p}','exact_spotify_uri':uri})
live=read('depot/Music-DNA-Depot-Special104-Live-URI-Bewijs.json')
for r in live['tracks']: add(r['spotify_uri'],'DNA SPECIAL 104',{'kind':'live teruglezing 7 oktober','source':'depot/Music-DNA-Depot-Special104-Live-URI-Bewijs.json','position':r['position'],'exact_spotify_uri':r['spotify_uri']})
w40=read('depot/Music-DNA-Depot-W40-Expositiebewijs.json')
for pos,id in enumerate(w40['ordered_track_ids'],1): add('spotify:track:'+id,'Ontdek DNA W40 [museumexpositie]',{'kind':'museumexpositie; geen bezorgbewijs','source':'depot/Music-DNA-Depot-W40-Expositiebewijs.json','position':pos,'exact_spotify_uri':'spotify:track:'+id})
csvpath=pathlib.Path('upload/DNA_SPECIAL_105_Geloof_naast_de_versterker.csv')
s105=list(csv.DictReader(csvpath.open(encoding='utf-8-sig')))
assert len(s105)==15 and len({r['Track URI'] for r in s105})==15
for pos,r in enumerate(s105,1):
    ensure(r['Track URI'],r['Artist Name(s)'],r['Track Name'],r)
    add(r['Track URI'],'DNA SPECIAL 105',{'kind':'gebruikersoverdracht Spotify-export','source':csvpath.name,'sha256':hashlib.sha256(csvpath.read_bytes()).hexdigest(),'position':pos,'exact_spotify_uri':r['Track URI'],'added_at':r['Added At'],'live_readback':False})
# Unknown metadata must remain explicit for the new Stryper record.
newstry=ix['spotify:track:07Rzb7ehY4pyOXIu5L7Rgs']
if newstry['Track URI'] not in {r['Track URI'] for r in original}:
    newstry.update({'Herkomstcontrole':'onverkend','Classificatiestatus':'Spotify-artiestlabels; tracktaxonomie nog te controleren','DNA Jaarstatus':'Spotify-brondatum; oorspronkelijk opnamejaar niet onafhankelijk gecontroleerd','DNA Jaarzekerheid':'Onbekend','DNA Tijdactie':'Oorspronkelijk opnamejaar controleren','DNA Plaatszekerheid':'Onbekend','DNA Plaatsactie':'Herkomst onderzoeken'})
changes=[]; unknown_numbers=[]
before={r['Track URI']:r for r in original}
for r in master:
    uri=r['Track URI']; evidence=sources.get(uri,[]); ls=sorted(apps[uri])
    used=bool(ls or evidence or r.get('DNA Gebruikt')=='Ja')
    unnumbered=any(e.get('number_unknown') for e in evidence)
    if unnumbered and not any(x.startswith('DNA SPECIAL') for x in ls):
        unknown_numbers.append({'uri':uri,'artist':r['Artist Name(s)'],'track':r['Track Name'],'reason':'Speciallidmaatschap bewezen in aggregaat; exact nummer ontbreekt'})
    r['DNA Gebruikt']='Ja' if used else 'Nee'
    r['DNA Playlist(s)']='; '.join(ls) or None
    r['DNA Aantal toepassingen']=len(ls)
    # This number counts identified applications, not unknown Special memberships.
    r['DNA Toepassingen compleet']=not (unnumbered and not any(x.startswith('DNA SPECIAL') for x in ls))
    r['DNA Registratiebron']='Master 1.14 reconciliatie 2026-10-08; zie GEBRUIKSBEWIJS.json'
    old=before.get(uri)
    fields=['DNA Gebruikt','DNA Playlist(s)','DNA Aantal toepassingen']
    if old is None or any(old.get(k)!=r.get(k) for k in fields):
        changes.append({'uri':uri,'artist':r['Artist Name(s)'],'track':r['Track Name'],'kind':'toegevoegd' if old is None else 'gebruik bijgewerkt','before':{k:old.get(k) for k in fields} if old else None,'after':{k:r.get(k) for k in fields},'evidence_count':len(evidence)})
# Verify preservation of all non-usage data in all existing records.
usagefields={'DNA Gebruikt','DNA Playlist(s)','DNA Aantal toepassingen'}
for old in original:
    for k,v in old.items():
        if k not in usagefields: assert ix[old['Track URI']][k]==v,(old['Track URI'],k)
assert len(master)==len({r['Track URI'] for r in master})
assert all(ix[r['spotify_uri']]['DNA Gebruikt']=='Ja' for r in yearbooks)
assert all(ix[r['spotify_uri']]['DNA Gebruikt']=='Ja' for r in live['tracks'])
assert all('DNA SPECIAL 105' in apps[r['Track URI']] for r in s105)
# Full Special corpus comparison using known IDs and the unnumbered aggregate.
olduris={r['Track URI'] for r in specials}
over105=[r for r in s105 if r['Track URI'] in olduris or any('DNA SPECIAL' in x and x!='DNA SPECIAL 105' for x in apps[r['Track URI']])]
summary={'as_of':'2026-10-08','version':'1.14 reconciliatie','previous_version':'1.13 Japan','records_before':len(original),'records_after':len(master),'added_records':len(master)-len(original),'used_before':sum(r.get('DNA Gebruikt')=='Ja' for r in original),'used_after':sum(r.get('DNA Gebruikt')=='Ja' for r in master),'unused_after':sum(r.get('DNA Gebruikt')!='Ja' for r in master),'changed_existing_records':sum(x['kind']!='toegevoegd' for x in changes),'changed_unused_to_used':sum(bool(x['before']) and x['before']['DNA Gebruikt']!='Ja' and x['after']['DNA Gebruikt']=='Ja' for x in changes),'identified_application_memberships':sum(len(v) for v in apps.values()),'unknown_special_number_records':len(unknown_numbers),'removed_superseded_yearbook_links':len(removed),'special105_exact_uri_overlap_with_available_prior_specials':len(over105),'exceptions_without_master':len({e['uri'] for e in exceptions}),'metadata_preservation_verified':True,'unique_uri_verified':True,'coverage':'Beschikbare checkpointbronnen: volledige Master en Jaarboekcanon, Specials-bronregister, Glam-expositiebewijs, W40-museum en Special105-export. Geen volledige nieuwe live export van alle playlists.','definitive_actual_usage_percent':None,'registered_used_percent_after':100*sum(r.get('DNA Gebruikt')=='Ja' for r in master)/len(master),'fifo_changed':False,'w41_endToEndProven':False}
dump('MASTER_ACTUEEL.json',master); dump('WIJZIGINGEN.json',changes)
dump('GEBRUIKSBEWIJS.json',dict(sources)); dump('CONTROLE.json',summary)
dump('OPEN_PUNTEN.json',{'unknown_special_numbers':unknown_numbers,'unmatched_exposure':exceptions,'special65_identity':'Live Special65 Los Angeles versus historisch Liverpool; historische bron apart gehouden','special105_overlaps':over105,'superseded_yearbook_links_removed':removed,'label_deduplication':aliases,'metadata_missing_new_records':'230 historische bronrecords bevatten slechts identiteit; nieuwe Stryper bevat Spotify-exportmetadata, aanvullende taxonomie/herkomst nog onverkend'})
columns=list(dict.fromkeys(k for r in master for k in r))
with (O/'MASTER_ACTUEEL.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=columns); w.writeheader(); w.writerows(master)
print(json.dumps(summary,ensure_ascii=False,indent=2))
